-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 22-03-2011 a las 15:35:18
-- Versión del servidor: 5.1.36
-- Versión de PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `umbeuc`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Alert`
--

CREATE TABLE IF NOT EXISTS `Alert` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Alert') CHARACTER SET utf8 DEFAULT 'Alert',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Description` mediumtext CHARACTER SET utf8,
  `Title` mediumtext CHARACTER SET utf8,
  `Link` mediumtext CHARACTER SET utf8,
  `EdicionID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `EdicionID` (`EdicionID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `Alert`
--

INSERT INTO `Alert` (`ID`, `ClassName`, `Created`, `LastEdited`, `Description`, `Title`, `Link`, `EdicionID`) VALUES
(1, 'Alert', '2011-03-07 19:02:14', '2011-03-07 19:02:14', 'Rituximab no fue superior a Ciclofosfamida en el tratamiento de vasculitis ANCA(+).', 'New England Journal of Medicine, 15 de Julio 2010', 'http://dx.doi.org/10.1056/NEJMoa0909169', 33),
(2, 'Alert', '2011-03-07 19:03:09', '2011-03-10 14:04:22', 'Uso de una herramienta computacional interactiva, adaptable a cada paciente, redujo repercusión de los síntomas y necesidad de soporte en pacientes oncológicos.', 'Journal of the American Medical Informatics Association, Julio 2010', 'http://dx.doi.org/10.1136/jamia.2010.005660', 33),
(3, 'Alert', '2011-03-07 19:04:09', '2011-03-10 14:04:11', 'Inicio precoz de terapia antiretroviral (CD4 200-350) disminuyó mortalidad en pacientes con VIH.', 'New England Journal of Medicine, 15 de Julio 2010', 'http://dx.doi.org/10.1056/NEJMoa0910370', 33),
(5, 'Alert', '2011-03-11 21:36:03', '2011-03-11 21:36:03', 'Uso de una herramienta computacional interactiva, adaptable a cada paciente, redujo repercusión de los síntomas y necesidad de soporte en pacientes oncológicos.', 'Journal of the American Medical Informatics Association, Julio 2010', 'http://asdasd.com', 38),
(6, 'Alert', '2011-03-11 21:36:36', '2011-03-11 21:36:36', 'Revisión sistemática: Polietilenglicol es más efectivo que lactulosa en adultos y niños con constipación crónica.', 'Journal of the American Medical Informatics Association, Julio 2010', 'http://zxczxc.com', 38),
(7, 'Alert', '2011-03-11 21:37:26', '2011-03-11 21:37:26', 'Intercambio de emails entre médicos y pacientes se asoció con mejor control de patologías crónicas.', 'Health Affairs, Julio 2010', 'Reactivo.cl', 38),
(8, 'Alert', '2011-03-11 21:38:32', '2011-03-11 21:38:32', 'Revisión sistemática: Hipotermia profiláctiva es efectiva en el traumatismo encefálico grave.', 'Canadian Journal of Emergency Medicine, Julio 2010', 'http://hola.com', 38),
(9, 'Alert', '2011-03-11 21:39:07', '2011-03-11 21:39:07', 'Acido Eicosapentaenoico disminuyó el número y el tamaño de los pólipos en la Poliposis adenomatosa familiar.', 'GUT, Julio 2010', 'http://dx.doi.org/10.1136/gut.2009.200642', 38);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `AlertCategory`
--

CREATE TABLE IF NOT EXISTS `AlertCategory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('AlertCategory') CHARACTER SET utf8 DEFAULT 'AlertCategory',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `AlertCategory`
--

INSERT INTO `AlertCategory` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`) VALUES
(2, 'AlertCategory', '2011-03-07 20:09:09', '2011-03-07 20:09:09', 'Una categoria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `AlertPage`
--

CREATE TABLE IF NOT EXISTS `AlertPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Volcar la base de datos para la tabla `AlertPage`
--

INSERT INTO `AlertPage` (`ID`, `Description`) VALUES
(28, 'Una alerta es algo demasiado Mainstream para explicarlo en un sistema Hipster como el que vivimos'),
(57, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `AlertPage_Live`
--

CREATE TABLE IF NOT EXISTS `AlertPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Volcar la base de datos para la tabla `AlertPage_Live`
--

INSERT INTO `AlertPage_Live` (`ID`, `Description`) VALUES
(28, 'Una alerta es algo demasiado Mainstream para explicarlo en un sistema Hipster como el que vivimos'),
(57, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `AlertPage_versions`
--

CREATE TABLE IF NOT EXISTS `AlertPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `AlertPage_versions`
--

INSERT INTO `AlertPage_versions` (`ID`, `RecordID`, `Version`, `Description`) VALUES
(1, 28, 3, NULL),
(2, 28, 6, NULL),
(3, 28, 7, 'Una alerta es algo demasiado Mainstream para explicarlo en un sistema Hipster como el que vivimos'),
(4, 32, 1, NULL),
(5, 34, 1, NULL),
(6, 51, 1, NULL),
(7, 55, 1, NULL),
(8, 57, 1, NULL),
(9, 57, 2, NULL),
(10, 65, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Alert_Categories`
--

CREATE TABLE IF NOT EXISTS `Alert_Categories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AlertID` int(11) NOT NULL DEFAULT '0',
  `AlertCategoryID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `AlertID` (`AlertID`),
  KEY `AlertCategoryID` (`AlertCategoryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `Alert_Categories`
--

INSERT INTO `Alert_Categories` (`ID`, `AlertID`, `AlertCategoryID`) VALUES
(1, 3, 2),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Alert_Magazines`
--

CREATE TABLE IF NOT EXISTS `Alert_Magazines` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AlertID` int(11) NOT NULL DEFAULT '0',
  `MagazineID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `AlertID` (`AlertID`),
  KEY `MagazineID` (`MagazineID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Alert_Magazines`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `CursosPage`
--

CREATE TABLE IF NOT EXISTS `CursosPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Bajada` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Volcar la base de datos para la tabla `CursosPage`
--

INSERT INTO `CursosPage` (`ID`, `Bajada`) VALUES
(50, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.'),
(52, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `CursosPage_Live`
--

CREATE TABLE IF NOT EXISTS `CursosPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Bajada` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Volcar la base de datos para la tabla `CursosPage_Live`
--

INSERT INTO `CursosPage_Live` (`ID`, `Bajada`) VALUES
(50, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.'),
(52, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `CursosPage_versions`
--

CREATE TABLE IF NOT EXISTS `CursosPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Bajada` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `CursosPage_versions`
--

INSERT INTO `CursosPage_versions` (`ID`, `RecordID`, `Version`, `Bajada`) VALUES
(1, 50, 4, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.'),
(2, 52, 4, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.'),
(3, 50, 5, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.'),
(4, 52, 5, 'Duis hendrerit tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem ipsum, vel tempor justo. Integer viverra consequat est vel dapibus. Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eclipse`
--

CREATE TABLE IF NOT EXISTS `Eclipse` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date DEFAULT NULL,
  `Parent` mediumtext CHARACTER SET utf8,
  `ParentURL` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Volcar la base de datos para la tabla `Eclipse`
--

INSERT INTO `Eclipse` (`ID`, `Date`, `Parent`, `ParentURL`) VALUES
(60, '2011-03-15', NULL, 'eclipses'),
(61, '2011-03-15', NULL, 'eclipses'),
(63, '2011-03-16', NULL, 'resumenes-support');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EclipseMulti`
--

CREATE TABLE IF NOT EXISTS `EclipseMulti` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TitleEn` mediumtext CHARACTER SET utf8,
  `ContentEn` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Volcar la base de datos para la tabla `EclipseMulti`
--

INSERT INTO `EclipseMulti` (`ID`, `TitleEn`, `ContentEn`) VALUES
(63, 'Hi, i''m an Eclipse', '<p>Text in English</p>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EclipseMulti_Live`
--

CREATE TABLE IF NOT EXISTS `EclipseMulti_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TitleEn` mediumtext CHARACTER SET utf8,
  `ContentEn` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Volcar la base de datos para la tabla `EclipseMulti_Live`
--

INSERT INTO `EclipseMulti_Live` (`ID`, `TitleEn`, `ContentEn`) VALUES
(63, 'Hi, i''m an Eclipse', '<p>Text in English</p>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EclipseMulti_versions`
--

CREATE TABLE IF NOT EXISTS `EclipseMulti_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `TitleEn` mediumtext CHARACTER SET utf8,
  `ContentEn` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `EclipseMulti_versions`
--

INSERT INTO `EclipseMulti_versions` (`ID`, `RecordID`, `Version`, `TitleEn`, `ContentEn`) VALUES
(1, 63, 4, 'Hi, i''m an Eclipse', '<p>Text in English</p>');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eclipse_Categories`
--

CREATE TABLE IF NOT EXISTS `Eclipse_Categories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EclipseID` int(11) NOT NULL DEFAULT '0',
  `AlertCategoryID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `EclipseID` (`EclipseID`),
  KEY `AlertCategoryID` (`AlertCategoryID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Eclipse_Categories`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eclipse_Live`
--

CREATE TABLE IF NOT EXISTS `Eclipse_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Date` date DEFAULT NULL,
  `Parent` mediumtext CHARACTER SET utf8,
  `ParentURL` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Volcar la base de datos para la tabla `Eclipse_Live`
--

INSERT INTO `Eclipse_Live` (`ID`, `Date`, `Parent`, `ParentURL`) VALUES
(60, '2011-03-15', NULL, 'eclipses'),
(61, '2011-03-15', NULL, 'eclipses'),
(63, '2011-03-16', NULL, 'resumenes-support');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eclipse_Magazines`
--

CREATE TABLE IF NOT EXISTS `Eclipse_Magazines` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EclipseID` int(11) NOT NULL DEFAULT '0',
  `MagazineID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `EclipseID` (`EclipseID`),
  KEY `MagazineID` (`MagazineID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Eclipse_Magazines`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Eclipse_versions`
--

CREATE TABLE IF NOT EXISTS `Eclipse_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Date` date DEFAULT NULL,
  `Parent` mediumtext CHARACTER SET utf8,
  `ParentURL` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `Eclipse_versions`
--

INSERT INTO `Eclipse_versions` (`ID`, `RecordID`, `Version`, `Date`, `Parent`, `ParentURL`) VALUES
(1, 60, 2, NULL, NULL, NULL),
(2, 60, 3, '2011-03-15', NULL, NULL),
(3, 60, 4, '2011-03-15', NULL, NULL),
(4, 61, 2, '2011-03-15', NULL, NULL),
(5, 61, 3, '2011-03-15', NULL, NULL),
(6, 63, 1, NULL, NULL, NULL),
(7, 63, 2, '2011-03-16', NULL, NULL),
(8, 63, 3, '2011-03-16', NULL, NULL),
(9, 63, 4, '2011-03-16', NULL, NULL),
(10, 60, 5, '2011-03-15', NULL, NULL),
(11, 60, 6, '2011-03-15', NULL, NULL),
(12, 60, 7, '2011-03-15', NULL, NULL),
(13, 60, 8, '2011-03-15', NULL, NULL),
(14, 60, 9, '2011-03-15', NULL, NULL),
(15, 60, 10, '2011-03-15', NULL, 'eclipses');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Edicion`
--

CREATE TABLE IF NOT EXISTS `Edicion` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Volcar la base de datos para la tabla `Edicion`
--

INSERT INTO `Edicion` (`ID`, `Description`) VALUES
(33, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(35, 'Hola soy una bajada de título'),
(38, NULL),
(39, NULL),
(40, NULL),
(41, NULL),
(58, NULL),
(59, NULL),
(62, NULL),
(57, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Edicion_Live`
--

CREATE TABLE IF NOT EXISTS `Edicion_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Volcar la base de datos para la tabla `Edicion_Live`
--

INSERT INTO `Edicion_Live` (`ID`, `Description`) VALUES
(33, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(35, 'Hola soy una bajada de título'),
(38, NULL),
(39, NULL),
(40, NULL),
(41, NULL),
(58, NULL),
(59, NULL),
(62, NULL),
(57, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Edicion_versions`
--

CREATE TABLE IF NOT EXISTS `Edicion_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Volcar la base de datos para la tabla `Edicion_versions`
--

INSERT INTO `Edicion_versions` (`ID`, `RecordID`, `Version`, `Description`) VALUES
(1, 33, 1, NULL),
(2, 33, 2, NULL),
(3, 33, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(4, 35, 1, NULL),
(5, 35, 2, 'Hola soy una bajada de título'),
(6, 36, 1, NULL),
(7, 37, 1, NULL),
(8, 38, 1, NULL),
(9, 39, 1, NULL),
(10, 39, 2, NULL),
(11, 40, 1, NULL),
(12, 40, 2, NULL),
(13, 41, 1, NULL),
(14, 41, 2, NULL),
(15, 41, 3, NULL),
(16, 41, 4, NULL),
(17, 41, 5, NULL),
(18, 38, 2, NULL),
(19, 38, 3, NULL),
(20, 33, 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(21, 33, 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(22, 33, 6, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(23, 33, 7, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(24, 33, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(25, 33, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(26, 33, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(27, 33, 11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luc pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec v risus. Donec tempor bibendum elit ac pellentesque.'),
(28, 58, 1, NULL),
(29, 59, 1, NULL),
(30, 62, 1, NULL),
(31, 57, 3, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Email_BounceRecord`
--

CREATE TABLE IF NOT EXISTS `Email_BounceRecord` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Email_BounceRecord') CHARACTER SET utf8 DEFAULT 'Email_BounceRecord',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `BounceEmail` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BounceTime` datetime DEFAULT NULL,
  `BounceMessage` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Email_BounceRecord`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Enlace`
--

CREATE TABLE IF NOT EXISTS `Enlace` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Enlace') CHARACTER SET utf8 DEFAULT 'Enlace',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `TextoAlternativo` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `EnlacesPageID` int(11) NOT NULL DEFAULT '0',
  `ImagenID` int(11) NOT NULL DEFAULT '0',
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `EnlacesPageID` (`EnlacesPageID`),
  KEY `ImagenID` (`ImagenID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `Enlace`
--

INSERT INTO `Enlace` (`ID`, `ClassName`, `Created`, `LastEdited`, `TextoAlternativo`, `Link`, `EnlacesPageID`, `ImagenID`, `Title`) VALUES
(1, 'Enlace', '2011-03-11 16:07:20', '2011-03-11 16:07:20', NULL, 'http://www.reactivo.cl', 16, 0, 'Reactivo'),
(2, 'Enlace', '2011-03-11 16:07:46', '2011-03-11 16:07:46', NULL, 'http://www.dospuntocero.cl', 16, 0, 'Dospuntocero'),
(3, 'Enlace', '2011-03-11 16:07:56', '2011-03-11 16:07:56', NULL, 'http://www.terra.cl', 16, 0, 'Terra'),
(4, 'Enlace', '2011-03-11 16:08:07', '2011-03-11 16:08:07', NULL, 'http://www.unbeuc.cl', 16, 0, 'UmbeUC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EnlacesPage`
--

CREATE TABLE IF NOT EXISTS `EnlacesPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `EnlacesPage`
--

INSERT INTO `EnlacesPage` (`ID`, `Description`) VALUES
(16, 'Praesent cursus, massa quis tristique bibendum, justo ante facilisis erat, eget tincidunt lacus est a ante. Proin fermentum arcu nec risus adipiscing congue. Quisque lobortis tortor ut leo fringilla mattis. Duis sit amet augue eu lectus bibendum cursus quis id dolor. Vestibulum hendrerit nunc quis velit volutpat eu scelerisque mauris ullamcorper. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla vitae suscipit lectus. Etiam odio leo, sodales et viverra vitae, gravida at quam. Duis non volutpat est. Etiam at nisi id dolor adipiscing ultricies. ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EnlacesPage_Live`
--

CREATE TABLE IF NOT EXISTS `EnlacesPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `EnlacesPage_Live`
--

INSERT INTO `EnlacesPage_Live` (`ID`, `Description`) VALUES
(16, 'Praesent cursus, massa quis tristique bibendum, justo ante facilisis erat, eget tincidunt lacus est a ante. Proin fermentum arcu nec risus adipiscing congue. Quisque lobortis tortor ut leo fringilla mattis. Duis sit amet augue eu lectus bibendum cursus quis id dolor. Vestibulum hendrerit nunc quis velit volutpat eu scelerisque mauris ullamcorper. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla vitae suscipit lectus. Etiam odio leo, sodales et viverra vitae, gravida at quam. Duis non volutpat est. Etiam at nisi id dolor adipiscing ultricies. ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `EnlacesPage_versions`
--

CREATE TABLE IF NOT EXISTS `EnlacesPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Description` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `EnlacesPage_versions`
--

INSERT INTO `EnlacesPage_versions` (`ID`, `RecordID`, `Version`, `Description`) VALUES
(1, 16, 5, 'Praesent cursus, massa quis tristique bibendum, justo ante facilisis erat, eget tincidunt lacus est a ante. Proin fermentum arcu nec risus adipiscing congue. Quisque lobortis tortor ut leo fringilla mattis. Duis sit amet augue eu lectus bibendum cursus quis id dolor. Vestibulum hendrerit nunc quis velit volutpat eu scelerisque mauris ullamcorper. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla vitae suscipit lectus. Etiam odio leo, sodales et viverra vitae, gravida at quam. Duis non volutpat est. Etiam at nisi id dolor adipiscing ultricies. ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ErrorPage`
--

CREATE TABLE IF NOT EXISTS `ErrorPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Volcar la base de datos para la tabla `ErrorPage`
--

INSERT INTO `ErrorPage` (`ID`, `ErrorCode`) VALUES
(5, 404),
(6, 500),
(26, 404),
(27, 500);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ErrorPage_Live`
--

CREATE TABLE IF NOT EXISTS `ErrorPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Volcar la base de datos para la tabla `ErrorPage_Live`
--

INSERT INTO `ErrorPage_Live` (`ID`, `ErrorCode`) VALUES
(5, 404),
(6, 500),
(26, 404),
(27, 500);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ErrorPage_versions`
--

CREATE TABLE IF NOT EXISTS `ErrorPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ErrorCode` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `ErrorPage_versions`
--

INSERT INTO `ErrorPage_versions` (`ID`, `RecordID`, `Version`, `ErrorCode`) VALUES
(1, 5, 1, 404),
(2, 6, 1, 500),
(3, 26, 1, 404),
(4, 27, 1, 500);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `File`
--

CREATE TABLE IF NOT EXISTS `File` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('File','NewsFile','FLV','MP3','Image','Folder','NewsPhoto','Image_Cached') CHARACTER SET utf8 DEFAULT 'File',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Filename` mediumtext CHARACTER SET utf8,
  `Content` mediumtext CHARACTER SET utf8,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `OwnerID` (`OwnerID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Volcar la base de datos para la tabla `File`
--

INSERT INTO `File` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Filename`, `Content`, `Sort`, `SortOrder`, `ParentID`, `OwnerID`) VALUES
(1, 'Folder', '2011-03-04 19:37:14', '2011-03-04 19:37:14', 'Uploads', 'Uploads', 'assets/Uploads/', NULL, 0, 0, 0, 0),
(2, 'NewsPhoto', '2011-03-04 21:09:27', '2011-03-11 19:07:05', '1200507.jpg', '1200507', 'assets/Uploads/1200507.jpg', NULL, 0, 0, 1, 0),
(3, 'Image', '2011-03-07 14:25:30', '2011-03-07 14:25:30', 'fotovitrina.png', 'fotovitrina', 'assets/Uploads/fotovitrina.png', NULL, 0, 2, 1, 0),
(4, 'Image', '2011-03-07 14:29:23', '2011-03-07 14:29:23', 'fotovitrina2.png', 'fotovitrina2', 'assets/Uploads/fotovitrina2.png', NULL, 0, 3, 1, 0),
(5, 'Image', '2011-03-07 13:00:15', '2011-03-07 13:00:15', 'medicos.jpeg', 'medicos.jpeg', 'assets/medicos.jpeg', NULL, 0, 0, 0, 1),
(6, 'Image', '2011-03-11 15:24:53', '2011-03-11 15:24:53', 'novedades50diplomadoweb2-500x355.jpg', 'novedades50diplomadoweb2-500x355.jpg', 'assets/novedades50diplomadoweb2-500x355.jpg', NULL, 0, 0, 0, 1),
(7, 'NewsPhoto', '2011-03-11 19:00:55', '2011-03-21 15:01:08', 'F882892japon6190k.jpg', 'F882892japon6190k', 'assets/Uploads/F882892japon6190k.jpg', NULL, 0, 6, 1, 0),
(8, 'NewsPhoto', '2011-03-11 19:05:30', '2011-03-11 19:07:31', 'F881862ja619.jpg', 'F881862ja619', 'assets/Uploads/F881862ja619.jpg', NULL, 0, 7, 1, 0),
(9, 'Image', '2011-03-14 15:37:19', '2011-03-14 15:37:19', 'PerfilSalzburg.jpg', 'PerfilSalzburg', 'assets/Uploads/PerfilSalzburg.jpg', NULL, 0, 8, 1, 0),
(10, 'Image', '2011-03-14 16:16:02', '2011-03-14 16:16:02', 'PerfilSalzburg2.jpg', 'PerfilSalzburg2', 'assets/Uploads/PerfilSalzburg2.jpg', NULL, 0, 9, 1, 0),
(11, 'Image', '2011-03-16 20:45:27', '2011-03-16 20:45:27', 'quienessomos.jpg', 'quienessomos', 'assets/Uploads/quienessomos.jpg', NULL, 0, 10, 1, 0),
(12, 'NewsPhoto', '2011-03-21 15:00:22', '2011-03-21 15:01:08', 'foreveralonebyprojectendo-d2z3pbc.jpg', 'foreveralonebyprojectendo d2z3pbc', 'assets/Uploads/foreveralonebyprojectendo-d2z3pbc.jpg', NULL, 0, 11, 1, 0),
(13, 'Image', '2011-03-22 14:50:49', '2011-03-22 14:50:49', 'doctor.jpg', 'doctor', 'assets/Uploads/doctor.jpg', NULL, 0, 12, 1, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Group`
--

CREATE TABLE IF NOT EXISTS `Group` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Group') CHARACTER SET utf8 DEFAULT 'Group',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Description` mediumtext CHARACTER SET utf8,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `IPRestrictions` mediumtext CHARACTER SET utf8,
  `HtmlEditorConfig` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `Group`
--

INSERT INTO `Group` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Description`, `Code`, `Locked`, `Sort`, `IPRestrictions`, `HtmlEditorConfig`, `ParentID`) VALUES
(1, 'Group', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'Content Authors', NULL, 'content-authors', 0, 1, NULL, NULL, 0),
(2, 'Group', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'Administrators', NULL, 'administrators', 0, 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Group_Members`
--

CREATE TABLE IF NOT EXISTS `Group_Members` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `MemberID` (`MemberID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `Group_Members`
--

INSERT INTO `Group_Members` (`ID`, `GroupID`, `MemberID`) VALUES
(1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Group_Roles`
--

CREATE TABLE IF NOT EXISTS `Group_Roles` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `PermissionRoleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `PermissionRoleID` (`PermissionRoleID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Group_Roles`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `HomePage`
--

CREATE TABLE IF NOT EXISTS `HomePage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HomeText` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Volcar la base de datos para la tabla `HomePage`
--

INSERT INTO `HomePage` (`ID`, `HomeText`, `ImageID`) VALUES
(7, 'Bienvenido al sitio de la Unidad de Medicina Basada en EvidenciaUC', 3),
(29, NULL, 0),
(30, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `HomePage_Live`
--

CREATE TABLE IF NOT EXISTS `HomePage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `HomeText` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `HomePage_Live`
--

INSERT INTO `HomePage_Live` (`ID`, `HomeText`, `ImageID`) VALUES
(7, 'Bienvenido al sitio de la Unidad de Medicina Basada en EvidenciaUC', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `HomePage_versions`
--

CREATE TABLE IF NOT EXISTS `HomePage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `HomeText` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `ImageID` (`ImageID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `HomePage_versions`
--

INSERT INTO `HomePage_versions` (`ID`, `RecordID`, `Version`, `HomeText`, `ImageID`) VALUES
(1, 7, 5, 'Bienvenido al sitio de la Unidad de Medicina Basada en EvidenciaUC', 3),
(2, 7, 6, 'Bienvenido al sitio de la Unidad de Medicina Basada en EvidenciaUC', 3),
(3, 29, 1, NULL, 0),
(4, 30, 1, NULL, 0),
(5, 7, 7, 'Bienvenido al sitio de la Unidad de Medicina Basada en EvidenciaUC', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `LoginAttempt`
--

CREATE TABLE IF NOT EXISTS `LoginAttempt` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('LoginAttempt') CHARACTER SET utf8 DEFAULT 'LoginAttempt',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Status` enum('Success','Failure') CHARACTER SET utf8 DEFAULT 'Success',
  `IP` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `LoginAttempt`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Magazine`
--

CREATE TABLE IF NOT EXISTS `Magazine` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Magazine') CHARACTER SET utf8 DEFAULT 'Magazine',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `HolderID` int(11) NOT NULL DEFAULT '0',
  `Country` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CountryName` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`),
  KEY `HolderID` (`HolderID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `Magazine`
--

INSERT INTO `Magazine` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Link`, `HolderID`, `Country`, `CountryName`) VALUES
(1, 'Magazine', '2011-03-08 16:09:45', '2011-03-10 14:45:35', 'Condorito', 'http://alegale.tk', 31, '13', 'Austria'),
(2, 'Magazine', '2011-03-08 16:10:03', '2011-03-10 14:45:06', 'ReactivoMagazine', 'http://reactivo.cl', 31, '3', 'Andorra'),
(3, 'Magazine', '2011-03-08 16:10:21', '2011-03-10 14:45:27', 'Yasmineitor', 'http://asdasdasd.com', 31, '15', 'Bahamas'),
(4, 'Magazine', '2011-03-10 14:40:58', '2011-03-10 14:44:35', 'Nueva revista', 'http://hola.com', 31, '38', 'Chile');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Member`
--

CREATE TABLE IF NOT EXISTS `Member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Member') CHARACTER SET utf8 DEFAULT 'Member',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `FirstName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Surname` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Email` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `RememberLoginToken` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `NumVisit` int(11) NOT NULL DEFAULT '0',
  `LastVisited` datetime DEFAULT NULL,
  `Bounced` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AutoLoginHash` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `AutoLoginExpired` datetime DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordExpiry` date DEFAULT NULL,
  `LockedOutUntil` datetime DEFAULT NULL,
  `Locale` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `FailedLoginCount` int(11) NOT NULL DEFAULT '0',
  `DateFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `TimeFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Email` (`Email`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `Member`
--

INSERT INTO `Member` (`ID`, `ClassName`, `Created`, `LastEdited`, `FirstName`, `Surname`, `Email`, `Password`, `RememberLoginToken`, `NumVisit`, `LastVisited`, `Bounced`, `AutoLoginHash`, `AutoLoginExpired`, `PasswordEncryption`, `Salt`, `PasswordExpiry`, `LockedOutUntil`, `Locale`, `FailedLoginCount`, `DateFormat`, `TimeFormat`) VALUES
(1, 'Member', '2011-03-04 18:52:39', '2011-03-22 14:50:26', 'Default Admin', NULL, NULL, NULL, NULL, 16, '2011-03-22 11:10:25', 0, NULL, NULL, NULL, NULL, NULL, NULL, 'es_ES', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MemberPage`
--

CREATE TABLE IF NOT EXISTS `MemberPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Apellido` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Celular` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Twitter` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Facebook` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Youtube` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Flickr` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Cargo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `FormacionAcademica` mediumtext CHARACTER SET utf8,
  `CurriculumPDFID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CurriculumPDFID` (`CurriculumPDFID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Volcar la base de datos para la tabla `MemberPage`
--

INSERT INTO `MemberPage` (`ID`, `Email`, `Nombre`, `Apellido`, `Celular`, `Twitter`, `Facebook`, `Youtube`, `Flickr`, `Cargo`, `FormacionAcademica`, `CurriculumPDFID`) VALUES
(20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(53, 'gabriel.rada@dasd.com', 'Gabriel', 'Rada', '8089908', NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MemberPage_Live`
--

CREATE TABLE IF NOT EXISTS `MemberPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Apellido` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Celular` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Twitter` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Facebook` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Youtube` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Flickr` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Cargo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `FormacionAcademica` mediumtext CHARACTER SET utf8,
  `CurriculumPDFID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CurriculumPDFID` (`CurriculumPDFID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Volcar la base de datos para la tabla `MemberPage_Live`
--

INSERT INTO `MemberPage_Live` (`ID`, `Email`, `Nombre`, `Apellido`, `Celular`, `Twitter`, `Facebook`, `Youtube`, `Flickr`, `Cargo`, `FormacionAcademica`, `CurriculumPDFID`) VALUES
(20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(53, 'gabriel.rada@dasd.com', 'Gabriel', 'Rada', '8089908', NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MemberPage_versions`
--

CREATE TABLE IF NOT EXISTS `MemberPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Nombre` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Apellido` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Celular` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Twitter` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Facebook` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Youtube` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Flickr` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Cargo` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `FormacionAcademica` mediumtext CHARACTER SET utf8,
  `CurriculumPDFID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `CurriculumPDFID` (`CurriculumPDFID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `MemberPage_versions`
--

INSERT INTO `MemberPage_versions` (`ID`, `RecordID`, `Version`, `Email`, `Nombre`, `Apellido`, `Celular`, `Twitter`, `Facebook`, `Youtube`, `Flickr`, `Cargo`, `FormacionAcademica`, `CurriculumPDFID`) VALUES
(1, 20, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(2, 53, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(3, 53, 2, NULL, 'Gabriel', 'Rada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(4, 53, 3, NULL, 'Gabriel', 'Rada', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(5, 53, 4, 'gabriel.rada@dasd.com', 'Gabriel', 'Rada', '8089908', NULL, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MemberPassword`
--

CREATE TABLE IF NOT EXISTS `MemberPassword` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('MemberPassword') CHARACTER SET utf8 DEFAULT 'MemberPassword',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Password` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberID` (`MemberID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `MemberPassword`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MetaField`
--

CREATE TABLE IF NOT EXISTS `MetaField` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('MetaField','MetaFieldMulti') CHARACTER SET utf8 DEFAULT 'MetaField',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `AlertPageID` int(11) NOT NULL DEFAULT '0',
  `EclipseID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `AlertPageID` (`AlertPageID`),
  KEY `ClassName` (`ClassName`),
  KEY `EclipseID` (`EclipseID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `MetaField`
--

INSERT INTO `MetaField` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Content`, `AlertPageID`, `EclipseID`) VALUES
(1, 'MetaField', '2011-03-07 15:26:59', '2011-03-07 15:27:24', 'Autores', 'Daniela Ahumada, Cristián Navarrete', 28, 0),
(2, 'MetaField', '2011-03-07 15:27:55', '2011-03-07 15:27:55', 'Revisor Principal', 'Dr. Juan Carlos Claro', 28, 0),
(3, 'MetaField', '2011-03-07 15:28:23', '2011-03-07 15:28:23', 'Fecha de publicación', '10 de diciembre 2011', 28, 0),
(4, 'MetaField', '2011-03-07 15:28:42', '2011-03-07 15:28:42', 'Especialidad', 'Oncología', 28, 0),
(5, 'MetaField', '2011-03-15 19:31:58', '2011-03-15 19:31:58', 'Autores', 'Romina Parraguirre, Cristobal Riffo', 0, 60),
(6, 'MetaField', '2011-03-15 19:37:06', '2011-03-15 19:37:06', 'Comedor oficial', 'Rodrigo Arandanos', 0, 60),
(7, 'MetaFieldMulti', '2011-03-16 16:16:56', '2011-03-16 16:16:56', 'Author', 'Condorito', 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `MetaFieldMulti`
--

CREATE TABLE IF NOT EXISTS `MetaFieldMulti` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EclipseMultiID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `EclipseMultiID` (`EclipseMultiID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `MetaFieldMulti`
--

INSERT INTO `MetaFieldMulti` (`ID`, `EclipseMultiID`) VALUES
(7, 63);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsArticle`
--

CREATE TABLE IF NOT EXISTS `NewsArticle` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('NewsArticle') CHARACTER SET utf8 DEFAULT 'NewsArticle',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `Excerpt` mediumtext CHARACTER SET utf8,
  `Date` date DEFAULT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `MetaLink` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `NewsHolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `NewsHolderID` (`NewsHolderID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `NewsArticle`
--

INSERT INTO `NewsArticle` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Content`, `Excerpt`, `Date`, `Featured`, `MetaLink`, `URLSegment`, `NewsHolderID`) VALUES
(1, 'NewsArticle', '2011-03-04 21:09:31', '2011-03-11 19:07:05', 'Casi 50 mil policías y cuatro helicópteros resguardarán Carnaval de Río', '<p>Tres mil veh&iacute;culos policiales, <strong>49.700 polic&iacute;as y cuatro helic&oacute;pteros</strong>, uno de ellos blindado, resguardar&aacute;n la seguridad del<strong> carnaval de R&iacute;o de Janeiro</strong>.  Si bien este a&ntilde;o hay mil efectivo menos, las autoridades indicaron que  habr&aacute; mayor protecci&oacute;n debido a las ocupaciones policiales de 16  favelas, especialmente las ubicadas en la regi&oacute;n vecina al "Samb&oacute;dromo",  el escenario del monumental desfile de las "escuelas de samba" del  domingo y del lunes pr&oacute;ximos. <br /><br />All&iacute;, la vigilancia ser&aacute; reforzada  tambi&eacute;n en forma virtual, mediante c&aacute;maras de video que enviar&aacute;n  im&aacute;genes instant&aacute;neas a un centro de operaciones inaugurado este a&ntilde;o, lo  que permitir&aacute; una r&aacute;pida reacci&oacute;n policial en caso de que se produzca  alg&uacute;n incidente. As&iacute;, la gobernaci&oacute;n podr&aacute; reducir el efectivo de  agentes en el "<strong>Samb&oacute;dromo</strong>" y destinar a otras &aacute;reas de la ciudad.<br />&nbsp;<br />"El  efectivo ser&aacute; menor, pero habr&aacute; mucha m&aacute;s seguridad", asever&oacute; el  portavoz de la polic&iacute;a militarizada, el coronel Lima Castro.<br /><br />Para los <strong>520 mil habitantes de las favelas pacificadas</strong> -entre ellas las que forman parte del Complejo del Alemao, que era una  de las comunidades m&aacute;s violentas de R&iacute;o y fue ocupado en noviembre del  a&ntilde;o pasado- &eacute;ste ser&aacute; el primer Carnaval sin miedo. <br /><br />El mes  pasado, una de las principales "escolas" de samba, Imperatriz  Leopoldinense, eligi&oacute; el lugar para realizar un ensayo previo al desfile  en el Samb&oacute;dromo, y festej&oacute; la oportunidad de brindar la comunidad con  una noche de m&uacute;sica, ritmo y alegr&iacute;a entonando una de sus canciones m&aacute;s  conocidas, cuya letra dice "Libertad, libertad, abre tus alas sobre  nosotros". <br /><br />&nbsp;"Esta es una samba importante para la historia de  nuestro gremio, y tambi&eacute;n por las cosas que han pasado ac&aacute; en el  Complejo de Alemao", dijo el cantante del club, Dominguinhos do Estacio.  <br /><br />El programa tambi&eacute;n fue festejado por los habitantes de los  barrios vecinos a las comunidades ocupadas. En el &uacute;ltimo fin de semana,  uno de los "blocos" (comparsas carnavalescas) m&aacute;s populares de R&iacute;o,  "Simpat&iacute;a es casi Amor", incluy&oacute; un paso por la favela de Cantagalo en  su presentaci&oacute;n por las calles del elegante barrio Ipanema. <br /><br />Seg&uacute;n  uno de los m&uacute;sicos del grupo, Fabio Palazzo, ha sido la primera vez en  27 a&ntilde;os que el "bloco" pudo ingresar en la favela sin temer los tiroteos  de las guerras entre narcos y polic&iacute;as o entre bandas rivales de  delincuentes. <br /><br />&nbsp;"Nuestra cercan&iacute;a (con la comunidad que vive en  la favela) fue interrumpida por el narcotr&aacute;fico. Pero ahora somos libres  para visitar a cualquiera", expres&oacute; Palazzo, en declaraciones que  publica hoy el diario "O Globo".</p>', NULL, '2011-03-04', 0, 'casi-50-mil-policias-y-cuatro-helicopteros-resguardaran-carnaval-de-rio', 'casi-50-mil-polic', 25),
(2, 'NewsArticle', '2011-03-11 19:01:37', '2011-03-21 15:01:08', 'Sismólogos afirman que terremoto de Japón fue magnitud 9', '<p>LOS &Aacute;NGELES.- Cient&iacute;ficos del Servicio Geol&oacute;gico de Estados Unidos (USGS), en Menlo Park, California, afirmaron que el <a href="http://wm.terra.cl/wikipedia/terremoto" target="blank_">terremoto</a> de Jap&oacute;n tuvo una magnitud de 9 en la escala <a href="http://wm.terra.cl/wikipedia/Richter" target="blank_">Richter</a>, y es uno de m&aacute;s poderosos registrados en la historia.</p>\r\n<p>Harold  Tobin de la Universidad de Wisconsin-Madison, dijo a la revista New  Scientist que esta cifra probablemente se vuelva a cambiar. "Esto es  t&iacute;pico en las primeras horas despu&eacute;s de un <a href="http://wm.terra.cl/wikipedia/sismo" target="blank_">sismo</a> grande, a medida que m&aacute;s informaci&oacute;n est&aacute; disponible", dijo.</p>\r\n<p>Tobin  agreg&oacute; que en los pr&oacute;ximos d&iacute;as, los sism&oacute;logos estar&aacute;n trabajando  febrilmente para llegar a un nuevo conjunto de c&aacute;lculos, que se conocen  como "inversi&oacute;n", para determinar en qu&eacute; &aacute;rea de la falla se produjo el <a href="http://wm.terra.cl/wikipedia/sismo" target="blank_">sismo</a> y cu&aacute;n grande es el deslizamiento de placas.</p>\r\n<p>"Es probable que hayan sido varios metros por un <a href="http://wm.terra.cl/wikipedia/terremoto" target="blank_">terremoto</a> de esta magnitud", dijo.</p>', NULL, '2011-03-11', 0, 'sismologos-afirman-que-terremoto-de-japon-fue-magnitud-9', 'sismologos-afirman-que-terremoto-de-japon-fue-magnitud-9', 25),
(3, 'NewsArticle', '2011-03-11 19:05:34', '2011-03-11 19:07:31', 'Deportes » Fútbol nacional  Jorge Segovia y personero de Colo Colo le entregan su apoyo a Jadue en la ANFP', '<p>SANTIAGO.- El pr&oacute;ximo martes 15 de marzo se anuncia Consejo de Presidentes en la <a href="http://wm.terra.cl/wikipedia/ANFP" target="blank_">ANFP</a>, en una cita que marcar&aacute; el futuro del organismo, ya que el timonel <strong>Sergio Jadue</strong> nombrar&iacute;a a los reemplazantes de los renunciados dirigentes.</p>\r\n<div id="SearchKey_Text1">\r\n<p>Esta jornada y en la antesala del encuentro, el mandam&aacute;s de Quil&iacute;n recibi&oacute; la visita de <strong>Jorge Segovia</strong> y el m&aacute;ximo accionista de <a href="http://wm.terra.cl/wikipedia/Colo%20Colo" target="blank_">Colo Colo</a>, <strong>Hern&aacute;n Levy</strong>, quienes le dieron su respaldo a la gesti&oacute;n realizada.</p>\r\n<p>El  primero en reunirse con Jadue fue el inhabilitado ex presidente de  Uni&oacute;n Espa&ntilde;ola y, tras varias horas, vino el turno del representante del  Cacique.</p>\r\n<p>Tras los encuentros, ninguno de los personeros entreg&oacute; declaraciones de los temas abordados.</p>\r\n</div>', NULL, '2011-03-11', 0, 'deportes-futbol-nacional-jorge-segovia-y-personero-de-colo-colo-le-entregan-su-apoyo-a-jadue-en-la-anfp', 'deportes-', 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsArticle_Categories`
--

CREATE TABLE IF NOT EXISTS `NewsArticle_Categories` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NewsArticleID` int(11) NOT NULL DEFAULT '0',
  `NewsCategoryID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `NewsArticleID` (`NewsArticleID`),
  KEY `NewsCategoryID` (`NewsCategoryID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `NewsArticle_Categories`
--

INSERT INTO `NewsArticle_Categories` (`ID`, `NewsArticleID`, `NewsCategoryID`) VALUES
(1, 1, 3),
(2, 2, 2),
(3, 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsArticle_Tags`
--

CREATE TABLE IF NOT EXISTS `NewsArticle_Tags` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NewsArticleID` int(11) NOT NULL DEFAULT '0',
  `NewsTagID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `NewsArticleID` (`NewsArticleID`),
  KEY `NewsTagID` (`NewsTagID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `NewsArticle_Tags`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsCategory`
--

CREATE TABLE IF NOT EXISTS `NewsCategory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('NewsCategory') CHARACTER SET utf8 DEFAULT 'NewsCategory',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `NewsCategory`
--

INSERT INTO `NewsCategory` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `URLSegment`) VALUES
(1, 'NewsCategory', '2011-03-11 19:06:43', '2011-03-11 19:06:43', 'Deportes', 'deportes'),
(2, 'NewsCategory', '2011-03-11 19:06:49', '2011-03-11 19:06:49', 'Terremotos', 'terremotos'),
(3, 'NewsCategory', '2011-03-11 19:06:54', '2011-03-11 19:06:54', 'Variedades', 'variedades');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsFile`
--

CREATE TABLE IF NOT EXISTS `NewsFile` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NewsArticleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `NewsArticleID` (`NewsArticleID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `NewsFile`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsPhoto`
--

CREATE TABLE IF NOT EXISTS `NewsPhoto` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ArticleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ArticleID` (`ArticleID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `NewsPhoto`
--

INSERT INTO `NewsPhoto` (`ID`, `ArticleID`) VALUES
(2, 1),
(7, 2),
(8, 3),
(12, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `NewsTag`
--

CREATE TABLE IF NOT EXISTS `NewsTag` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('NewsTag') CHARACTER SET utf8 DEFAULT 'NewsTag',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `NewsTag`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Page`
--

CREATE TABLE IF NOT EXISTS `Page` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ShowInHeaderMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInFooterMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `PhotoID` (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Volcar la base de datos para la tabla `Page`
--

INSERT INTO `Page` (`ID`, `ShowInHeaderMenu`, `ShowInFooterMenu`, `PhotoID`) VALUES
(1, 0, 0, 0),
(2, 0, 0, 0),
(3, 0, 0, 0),
(4, 0, 0, 0),
(5, 0, 0, 0),
(6, 0, 0, 0),
(7, 0, 0, 13),
(8, 0, 0, 0),
(9, 0, 0, 0),
(10, 0, 0, 0),
(11, 0, 0, 0),
(12, 0, 0, 0),
(13, 0, 0, 0),
(14, 0, 0, 0),
(15, 0, 0, 0),
(16, 0, 0, 0),
(17, 0, 0, 0),
(18, 0, 0, 0),
(19, 0, 0, 0),
(20, 0, 0, 0),
(21, 0, 0, 11),
(22, 0, 0, 0),
(23, 0, 0, 0),
(28, 0, 0, 0),
(25, 0, 0, 0),
(26, 0, 0, 0),
(27, 0, 0, 0),
(29, 0, 0, 0),
(30, 0, 0, 0),
(31, 0, 0, 0),
(33, 0, 0, 0),
(35, 0, 0, 0),
(38, 0, 0, 0),
(39, 0, 0, 0),
(40, 0, 0, 0),
(41, 0, 0, 0),
(42, 0, 0, 0),
(43, 0, 0, 0),
(44, 0, 0, 0),
(45, 0, 0, 0),
(46, 0, 0, 0),
(47, 0, 0, 0),
(48, 0, 0, 0),
(49, 0, 0, 0),
(50, 0, 0, 0),
(52, 0, 0, 0),
(53, 0, 0, 10),
(54, 0, 0, 0),
(56, 0, 0, 0),
(57, 0, 0, 0),
(58, 0, 0, 0),
(59, 0, 0, 0),
(60, 0, 0, 0),
(61, 0, 0, 0),
(62, 0, 0, 0),
(63, 0, 0, 0),
(64, 0, 0, 0),
(66, 0, 0, 0),
(67, 0, 0, 0),
(68, 0, 0, 0),
(69, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PageComment`
--

CREATE TABLE IF NOT EXISTS `PageComment` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PageComment') CHARACTER SET utf8 DEFAULT 'PageComment',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Comment` mediumtext CHARACTER SET utf8,
  `IsSpam` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `NeedsModeration` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `CommenterURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SessionID` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `AuthorID` (`AuthorID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `PageComment`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Page_Live`
--

CREATE TABLE IF NOT EXISTS `Page_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ShowInHeaderMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInFooterMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `PhotoID` (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Volcar la base de datos para la tabla `Page_Live`
--

INSERT INTO `Page_Live` (`ID`, `ShowInHeaderMenu`, `ShowInFooterMenu`, `PhotoID`) VALUES
(1, 0, 0, 0),
(2, 0, 0, 0),
(3, 0, 0, 0),
(4, 0, 0, 0),
(5, 0, 0, 0),
(6, 0, 0, 0),
(7, 0, 0, 13),
(8, 0, 0, 0),
(9, 0, 0, 0),
(10, 0, 0, 0),
(11, 0, 0, 0),
(12, 0, 0, 0),
(13, 0, 0, 0),
(14, 0, 0, 0),
(15, 0, 0, 0),
(16, 0, 0, 0),
(17, 0, 0, 0),
(18, 0, 0, 0),
(19, 0, 0, 0),
(20, 0, 0, 0),
(21, 0, 0, 11),
(22, 0, 0, 0),
(23, 0, 0, 0),
(28, 0, 0, 0),
(25, 0, 0, 0),
(26, 0, 0, 0),
(27, 0, 0, 0),
(29, 0, 0, 0),
(30, 0, 0, 0),
(31, 0, 0, 0),
(33, 0, 0, 0),
(35, 0, 0, 0),
(38, 0, 0, 0),
(39, 0, 0, 0),
(40, 0, 0, 0),
(41, 0, 0, 0),
(42, 0, 0, 0),
(43, 0, 0, 0),
(44, 0, 0, 0),
(45, 0, 0, 0),
(46, 0, 0, 0),
(47, 0, 0, 0),
(48, 0, 0, 0),
(49, 0, 0, 0),
(50, 0, 0, 0),
(52, 0, 0, 0),
(53, 0, 0, 10),
(54, 0, 0, 0),
(56, 0, 0, 0),
(57, 0, 0, 0),
(58, 0, 0, 0),
(59, 0, 0, 0),
(60, 0, 0, 0),
(61, 0, 0, 0),
(62, 0, 0, 0),
(63, 0, 0, 0),
(64, 0, 0, 0),
(66, 0, 0, 0),
(67, 0, 0, 0),
(68, 0, 0, 0),
(69, 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Page_versions`
--

CREATE TABLE IF NOT EXISTS `Page_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ShowInHeaderMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInFooterMenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `PhotoID` (`PhotoID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=201 ;

--
-- Volcar la base de datos para la tabla `Page_versions`
--

INSERT INTO `Page_versions` (`ID`, `RecordID`, `Version`, `ShowInHeaderMenu`, `ShowInFooterMenu`, `PhotoID`) VALUES
(1, 1, 1, 0, 0, 0),
(2, 2, 1, 0, 0, 0),
(3, 3, 1, 0, 0, 0),
(4, 4, 1, 0, 0, 0),
(5, 5, 1, 0, 0, 0),
(6, 6, 1, 0, 0, 0),
(7, 7, 1, 0, 0, 0),
(8, 7, 2, 0, 0, 0),
(9, 8, 1, 0, 0, 0),
(10, 9, 1, 0, 0, 0),
(11, 9, 2, 0, 0, 0),
(12, 10, 1, 0, 0, 0),
(13, 11, 1, 0, 0, 0),
(14, 12, 1, 0, 0, 0),
(15, 13, 1, 0, 0, 0),
(16, 14, 1, 0, 0, 0),
(17, 15, 1, 0, 0, 0),
(18, 16, 1, 0, 0, 0),
(19, 16, 2, 0, 0, 0),
(20, 17, 1, 0, 0, 0),
(21, 18, 1, 0, 0, 0),
(22, 19, 1, 0, 0, 0),
(23, 20, 1, 0, 0, 0),
(24, 20, 2, 0, 0, 0),
(25, 21, 1, 0, 0, 0),
(26, 22, 1, 0, 0, 0),
(27, 23, 1, 0, 0, 0),
(28, 7, 3, 0, 0, 0),
(29, 24, 1, 0, 0, 0),
(30, 25, 1, 0, 0, 0),
(31, 26, 1, 0, 0, 0),
(32, 27, 1, 0, 0, 0),
(33, 7, 4, 0, 0, 0),
(34, 10, 2, 0, 0, 0),
(35, 12, 2, 0, 0, 0),
(36, 7, 5, 0, 0, 0),
(37, 7, 6, 0, 0, 4),
(38, 28, 1, 0, 0, 0),
(39, 28, 2, 0, 0, 0),
(40, 29, 1, 0, 0, 0),
(41, 30, 1, 0, 0, 0),
(42, 29, 2, 0, 0, 0),
(43, 30, 2, 0, 0, 0),
(44, 29, 3, 0, 0, 0),
(45, 30, 3, 0, 0, 0),
(46, 31, 1, 0, 0, 0),
(47, 31, 2, 0, 0, 0),
(48, 9, 3, 0, 0, 0),
(49, 8, 2, 0, 0, 0),
(50, 8, 3, 0, 0, 0),
(51, 9, 4, 0, 0, 0),
(52, 9, 5, 0, 0, 0),
(53, 28, 3, 0, 0, 0),
(54, 28, 4, 0, 0, 0),
(55, 28, 5, 0, 0, 0),
(56, 28, 6, 0, 0, 0),
(57, 28, 7, 0, 0, 0),
(58, 30, 4, 0, 0, 0),
(59, 32, 1, 0, 0, 0),
(60, 33, 1, 0, 0, 0),
(61, 34, 1, 0, 0, 0),
(62, 33, 2, 0, 0, 0),
(63, 33, 3, 0, 0, 0),
(64, 35, 1, 0, 0, 0),
(65, 30, 5, 0, 0, 0),
(66, 35, 2, 0, 0, 0),
(67, 36, 1, 0, 0, 0),
(68, 37, 1, 0, 0, 0),
(69, 38, 1, 0, 0, 0),
(70, 39, 1, 0, 0, 0),
(71, 39, 2, 0, 0, 0),
(72, 40, 1, 0, 0, 0),
(73, 40, 2, 0, 0, 0),
(74, 41, 1, 0, 0, 0),
(75, 41, 2, 0, 0, 0),
(76, 41, 3, 0, 0, 0),
(77, 41, 4, 0, 0, 0),
(78, 41, 5, 0, 0, 0),
(79, 31, 3, 0, 0, 0),
(80, 31, 4, 0, 0, 0),
(81, 30, 6, 0, 0, 0),
(82, 31, 5, 0, 0, 0),
(83, 29, 4, 0, 0, 0),
(84, 13, 2, 0, 0, 0),
(85, 42, 1, 0, 0, 0),
(86, 42, 2, 0, 0, 0),
(87, 43, 1, 0, 0, 0),
(88, 42, 3, 0, 0, 0),
(89, 43, 2, 0, 0, 0),
(90, 43, 3, 0, 0, 0),
(91, 43, 4, 0, 0, 0),
(92, 44, 1, 0, 0, 0),
(93, 44, 2, 0, 0, 0),
(94, 45, 1, 0, 0, 0),
(95, 45, 2, 0, 0, 0),
(96, 13, 3, 0, 0, 0),
(97, 13, 4, 0, 0, 0),
(98, 44, 3, 0, 0, 0),
(99, 45, 3, 0, 0, 0),
(100, 46, 1, 0, 0, 0),
(101, 46, 2, 0, 0, 0),
(102, 47, 1, 0, 0, 0),
(103, 48, 1, 0, 0, 0),
(104, 49, 1, 0, 0, 0),
(105, 47, 2, 0, 0, 0),
(106, 47, 3, 0, 0, 0),
(107, 48, 2, 0, 0, 0),
(108, 49, 2, 0, 0, 0),
(109, 18, 2, 0, 0, 0),
(110, 16, 3, 0, 0, 0),
(111, 16, 4, 0, 0, 0),
(112, 16, 5, 0, 0, 0),
(113, 14, 2, 0, 0, 0),
(114, 50, 1, 0, 0, 0),
(115, 51, 1, 0, 0, 0),
(116, 52, 1, 0, 0, 0),
(117, 50, 2, 0, 0, 0),
(118, 52, 2, 0, 0, 0),
(119, 52, 3, 0, 0, 0),
(120, 50, 3, 0, 0, 0),
(121, 50, 4, 0, 0, 0),
(122, 52, 4, 0, 0, 0),
(123, 50, 5, 0, 0, 0),
(124, 52, 5, 0, 0, 0),
(125, 38, 2, 0, 0, 0),
(126, 38, 3, 0, 0, 0),
(127, 33, 4, 0, 0, 0),
(128, 33, 5, 0, 0, 0),
(129, 33, 6, 0, 0, 0),
(130, 33, 7, 0, 0, 0),
(131, 33, 8, 0, 0, 0),
(132, 33, 9, 0, 0, 0),
(133, 33, 10, 0, 0, 0),
(134, 33, 11, 0, 0, 0),
(135, 20, 3, 0, 0, 0),
(136, 20, 4, 0, 0, 0),
(137, 20, 5, 0, 0, 0),
(138, 53, 1, 0, 0, 0),
(139, 53, 2, 0, 0, 0),
(140, 53, 3, 0, 0, 10),
(141, 53, 4, 0, 0, 10),
(142, 20, 6, 0, 0, 0),
(143, 19, 2, 0, 0, 0),
(144, 19, 3, 0, 0, 0),
(145, 54, 1, 0, 0, 0),
(146, 54, 2, 0, 0, 0),
(147, 55, 1, 0, 0, 0),
(148, 56, 1, 0, 0, 0),
(149, 56, 2, 0, 0, 0),
(150, 57, 1, 0, 0, 0),
(151, 57, 2, 0, 0, 0),
(152, 58, 1, 0, 0, 0),
(153, 59, 1, 0, 0, 0),
(154, 60, 1, 0, 0, 0),
(155, 61, 1, 0, 0, 0),
(156, 60, 2, 0, 0, 0),
(157, 60, 3, 0, 0, 0),
(158, 60, 4, 0, 0, 0),
(159, 61, 2, 0, 0, 0),
(160, 61, 3, 0, 0, 0),
(161, 10, 3, 0, 0, 0),
(162, 10, 4, 0, 0, 0),
(163, 54, 3, 0, 0, 0),
(164, 56, 3, 0, 0, 0),
(165, 62, 1, 0, 0, 0),
(166, 63, 1, 0, 0, 0),
(167, 63, 2, 0, 0, 0),
(168, 63, 3, 0, 0, 0),
(169, 63, 4, 0, 0, 0),
(170, 12, 3, 0, 0, 0),
(171, 21, 2, 0, 0, 11),
(172, 21, 3, 0, 0, 11),
(173, 60, 5, 0, 0, 0),
(174, 60, 6, 0, 0, 0),
(175, 60, 7, 0, 0, 0),
(176, 60, 8, 0, 0, 0),
(177, 60, 9, 0, 0, 0),
(178, 60, 10, 0, 0, 0),
(179, 57, 3, 0, 0, 0),
(180, 57, 4, 0, 0, 0),
(181, 15, 2, 0, 0, 0),
(182, 15, 3, 0, 0, 0),
(183, 64, 1, 0, 0, 0),
(184, 65, 1, 0, 0, 0),
(185, 66, 1, 0, 0, 0),
(186, 66, 2, 0, 0, 0),
(187, 66, 3, 0, 0, 0),
(188, 67, 1, 0, 0, 0),
(189, 67, 2, 0, 0, 0),
(190, 67, 3, 0, 0, 0),
(191, 68, 1, 0, 0, 0),
(192, 69, 1, 0, 0, 0),
(193, 64, 2, 0, 0, 0),
(194, 66, 4, 0, 0, 0),
(195, 67, 4, 0, 0, 0),
(196, 68, 2, 0, 0, 0),
(197, 69, 2, 0, 0, 0),
(198, 11, 2, 0, 0, 0),
(199, 11, 3, 0, 0, 0),
(200, 7, 7, 0, 0, 13);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Permission`
--

CREATE TABLE IF NOT EXISTS `Permission` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Permission') CHARACTER SET utf8 DEFAULT 'Permission',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Arg` int(11) NOT NULL DEFAULT '0',
  `Type` int(11) NOT NULL DEFAULT '1',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GroupID` (`GroupID`),
  KEY `Code` (`Code`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `Permission`
--

INSERT INTO `Permission` (`ID`, `ClassName`, `Created`, `LastEdited`, `Code`, `Arg`, `Type`, `GroupID`) VALUES
(1, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'CMS_ACCESS_CMSMain', 0, 1, 1),
(2, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'CMS_ACCESS_AssetAdmin', 0, 1, 1),
(3, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'CMS_ACCESS_CommentAdmin', 0, 1, 1),
(4, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'CMS_ACCESS_ReportAdmin', 0, 1, 1),
(5, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'SITETREE_REORGANISE', 0, 1, 1),
(6, 'Permission', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'ADMIN', 0, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PermissionRole`
--

CREATE TABLE IF NOT EXISTS `PermissionRole` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PermissionRole') CHARACTER SET utf8 DEFAULT 'PermissionRole',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnlyAdminCanApply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `PermissionRole`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PermissionRoleCode`
--

CREATE TABLE IF NOT EXISTS `PermissionRoleCode` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PermissionRoleCode') CHARACTER SET utf8 DEFAULT 'PermissionRoleCode',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `RoleID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RoleID` (`RoleID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `PermissionRoleCode`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto`
--

CREATE TABLE IF NOT EXISTS `Proyecto` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Proyecto') CHARACTER SET utf8 DEFAULT 'Proyecto',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `ProyectoCat` enum('Proyectos con financiamiento interno','Proyectos con financiamiento externo') CHARACTER SET utf8 DEFAULT 'Proyectos con financiamiento interno',
  `Nombre` mediumtext CHARACTER SET utf8,
  `Programa` mediumtext CHARACTER SET utf8,
  `Year` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Visibility` enum('Publico','Oculto') CHARACTER SET utf8 DEFAULT 'Publico',
  `MemberPageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberPageID` (`MemberPageID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `Proyecto`
--

INSERT INTO `Proyecto` (`ID`, `ClassName`, `Created`, `LastEdited`, `ProyectoCat`, `Nombre`, `Programa`, `Year`, `Visibility`, `MemberPageID`) VALUES
(1, 'Proyecto', '2011-03-14 15:46:25', '2011-03-14 15:46:25', 'Proyectos con financiamiento interno', 'Un proyecto muy interesante', 'No se que es esto', '2009', 'Publico', 53);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyectos`
--

CREATE TABLE IF NOT EXISTS `Proyectos` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Proyectos') CHARACTER SET utf8 DEFAULT 'Proyectos',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` mediumtext CHARACTER SET utf8,
  `Description` mediumtext CHARACTER SET utf8,
  `Responsable` mediumtext CHARACTER SET utf8,
  `Duracion` mediumtext CHARACTER SET utf8,
  `Financiador` mediumtext CHARACTER SET utf8,
  `HolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `HolderID` (`HolderID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Proyectos`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `PublicacionFuente`
--

CREATE TABLE IF NOT EXISTS `PublicacionFuente` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('PublicacionFuente') CHARACTER SET utf8 DEFAULT 'PublicacionFuente',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `ArticleName` mediumtext CHARACTER SET utf8,
  `SourceName` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Year` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Pages` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Visibility` enum('Publico','Oculto') CHARACTER SET utf8 DEFAULT 'Publico',
  `City` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Publisher` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Category` enum('','Publicaciones en revistas','Libros y capítulos de libros','Publicaciones de documentos técnicos','Presentaciones a congresos') CHARACTER SET utf8 DEFAULT '',
  `MemberPageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberPageID` (`MemberPageID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `PublicacionFuente`
--

INSERT INTO `PublicacionFuente` (`ID`, `ClassName`, `Created`, `LastEdited`, `Author`, `ArticleName`, `SourceName`, `Year`, `Pages`, `Visibility`, `City`, `Publisher`, `Category`, `MemberPageID`) VALUES
(1, 'PublicacionFuente', '2011-03-14 15:40:02', '2011-03-14 15:40:02', 'Gabriel Rada', 'Investigación sobre algo', 'Fuente Alemana', '2010', '23-45', 'Publico', 'Viña del Mar', 'Salo', 'Publicaciones en revistas', 53);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `QueuedEmail`
--

CREATE TABLE IF NOT EXISTS `QueuedEmail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('QueuedEmail') CHARACTER SET utf8 DEFAULT 'QueuedEmail',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Send` datetime DEFAULT NULL,
  `Subject` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `From` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `ToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ToID` (`ToID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `QueuedEmail`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `RedirectorPage`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Volcar la base de datos para la tabla `RedirectorPage`
--

INSERT INTO `RedirectorPage` (`ID`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(8, 'Internal', NULL, 9),
(9, 'Internal', NULL, 28),
(13, 'Internal', NULL, 0),
(19, 'Internal', NULL, 20),
(10, 'Internal', NULL, 54),
(15, 'Internal', NULL, 16),
(11, 'Internal', NULL, 64);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `RedirectorPage_Live`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Volcar la base de datos para la tabla `RedirectorPage_Live`
--

INSERT INTO `RedirectorPage_Live` (`ID`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(8, 'Internal', NULL, 9),
(9, 'Internal', NULL, 28),
(13, 'Internal', NULL, 0),
(19, 'Internal', NULL, 20),
(10, 'Internal', NULL, 54),
(15, 'Internal', NULL, 16),
(11, 'Internal', NULL, 64);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `RedirectorPage_versions`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `LinkToID` (`LinkToID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Volcar la base de datos para la tabla `RedirectorPage_versions`
--

INSERT INTO `RedirectorPage_versions` (`ID`, `RecordID`, `Version`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(1, 8, 2, 'Internal', NULL, 0),
(2, 8, 3, 'Internal', NULL, 9),
(3, 9, 4, 'Internal', NULL, 0),
(4, 9, 5, 'Internal', NULL, 28),
(5, 13, 3, 'Internal', NULL, 0),
(6, 19, 2, 'Internal', NULL, 0),
(7, 19, 3, 'Internal', NULL, 20),
(8, 10, 3, 'Internal', NULL, 0),
(9, 10, 4, 'Internal', NULL, 54),
(10, 15, 2, 'Internal', NULL, 0),
(11, 15, 3, 'Internal', NULL, 16),
(12, 11, 2, 'Internal', NULL, 0),
(13, 11, 3, 'Internal', NULL, 64);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ResumenDeEvidenciaAlert`
--

CREATE TABLE IF NOT EXISTS `ResumenDeEvidenciaAlert` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EdicionesID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `EdicionesID` (`EdicionesID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `ResumenDeEvidenciaAlert`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `S3File`
--

CREATE TABLE IF NOT EXISTS `S3File` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('S3File') CHARACTER SET utf8 DEFAULT 'S3File',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Bucket` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `URL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `OwnerID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `OwnerID` (`OwnerID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `S3File`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteConfig`
--

CREATE TABLE IF NOT EXISTS `SiteConfig` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('SiteConfig') CHARACTER SET utf8 DEFAULT 'SiteConfig',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Tagline` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Theme` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'Anyone',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `CanCreateTopLevelType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `ChooseYourJSFlavor` enum('Fancybox','Colorbox') CHARACTER SET utf8 DEFAULT 'Fancybox',
  `TitleShow` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TransitionIn` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TransitionOut` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TitlePosition` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `EaseIn` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `EaseOut` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CSSType` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `DisqusApi` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `AllowTags` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Maintenance` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ContactInfo` mediumtext CHARACTER SET utf8,
  `GMapsApiKey` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `GAnalitycsApiKey` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Colofon` mediumtext CHARACTER SET utf8,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `SiteConfig`
--

INSERT INTO `SiteConfig` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Tagline`, `Theme`, `CanViewType`, `CanEditType`, `CanCreateTopLevelType`, `ChooseYourJSFlavor`, `TitleShow`, `TransitionIn`, `TransitionOut`, `TitlePosition`, `EaseIn`, `EaseOut`, `CSSType`, `DisqusApi`, `AllowTags`, `Maintenance`, `ContactInfo`, `GMapsApiKey`, `GAnalitycsApiKey`, `Colofon`) VALUES
(1, 'SiteConfig', '2011-03-04 18:52:39', '2011-03-17 15:51:13', 'UmbeUC', 'your tagline here', NULL, 'Anyone', 'LoggedInUsers', 'LoggedInUsers', 'Fancybox', 'false', 'TransitionIn', 'TransitionOut', 'inside', 'EaseIn', 'easeInQuad', 'example1', NULL, 0, 0, '<p>Telefono: (032) 56 65 89 87<br/>Correo: contacto@umbeuc.cl<br/>Dirección:</p>', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luctus pulvi-nar gravida. Etiam luctus leo sed orci porta ultricies nec vitae risus. Donec tempor bibendum elit ac pellentesque. ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteConfig_CreateTopLevelGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_CreateTopLevelGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteConfig_CreateTopLevelGroups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteConfig_EditorGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_EditorGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteConfig_EditorGroups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteConfig_ViewerGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_ViewerGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteConfigID` (`SiteConfigID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteConfig_ViewerGroups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree`
--

CREATE TABLE IF NOT EXISTS `SiteTree` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('SiteTree','Page','EnlacesPage','News','HomePage','TutorialPart','AlertPage','ArchivePage','CursosHolder','CursosPage','Eclipse','Edicion','EdicionesHolder','Glosary','MemberHolder','MemberPage','ProyectosUmbe','ResumenDeEvidencia','RevistasHolder','TutorialPage','TutorialesHolder','ErrorPage','RedirectorPage','VirtualPage','EclipseMulti','ResumenDeEvidenciaEdicion','ResumenDeEvidenciaEdicionMulti','ResumenDeEvidenciaMulti') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HomepageForDomain` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Status` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ToDo` mediumtext CHARACTER SET utf8,
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Volcar la base de datos para la tabla `SiteTree`
--

INSERT INTO `SiteTree` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `Version`, `ParentID`) VALUES
(7, 'HomePage', '2011-03-04 19:36:53', '2011-03-22 14:50:53', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 7, 0),
(8, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:35:47', 'nuestro-trabajo', 'Nuestro Trabajo', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(9, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:46:32', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 8),
(10, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-15 19:14:44', 'resumenes-de-evidencia', 'Resúmenes de evidencia', 'Resúmenes', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 8),
(11, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 21:22:22', 'publicaciones', 'Publicaciones', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 8),
(12, 'ProyectosUmbe', '2011-03-04 19:36:54', '2011-03-16 20:08:22', 'proyectos-umbeuc', 'Proyectos UmbeUC', 'Proyectos', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 8),
(13, 'TutorialesHolder', '2011-03-04 19:36:54', '2011-03-10 17:55:39', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 0),
(14, 'CursosHolder', '2011-03-04 19:36:54', '2011-03-11 18:20:27', 'cursos', 'Cursos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 0),
(15, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 16:12:40', 'herramientas', 'Herramientas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(16, 'EnlacesPage', '2011-03-04 19:36:54', '2011-03-11 17:56:07', 'enlaces', 'Enlaces', NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luctus pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec vitae. Donec tempor bibendum elit ac pellentesque.', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 15),
(17, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'calculadora', 'Calculadora', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 15),
(18, 'Glosary', '2011-03-04 19:36:54', '2011-03-10 21:23:31', 'glosario', 'Glosario', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 15),
(19, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-14 16:33:06', 'acerca-de', 'Acerca de', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(20, 'MemberHolder', '2011-03-04 19:36:54', '2011-03-14 16:21:21', 'quienes-somos', ' Quienes somos', 'Quienes somos', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>', ' Quienes somos', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 6, 19),
(21, 'Page', '2011-03-04 19:36:54', '2011-03-16 20:45:43', 'que-hacemos', 'Qué Hacemos', NULL, '<p>Lorem Ipsum</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 19),
(22, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'terminos', 'Términos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 19),
(23, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'redes-y-alianzas', 'Redes y alianzas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 19),
(31, 'RevistasHolder', '2011-03-07 14:51:43', '2011-03-08 18:21:18', 'revistas-revisadas', 'Revistas revisadas', 'Revistas', '<p>En esta sección veremos las revistas desde las cuales se obtiene la información que incorporamos en nuestras alertas.</p>', 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 9),
(28, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 16:08:21', 'que-es', '¿Qué son las alertas?', 'Qué es', '<h2><img class="left" src="assets/medicos.jpeg" width="520" height="390" alt="" title=""/></h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 7, 9),
(29, 'ArchivePage', '2011-03-07 14:50:32', '2011-03-08 19:35:13', 'archivo', 'Archivo', NULL, NULL, 'Archivo', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 9),
(30, 'EdicionesHolder', '2011-03-07 14:50:32', '2011-03-08 16:30:12', 'ultima-edicion', 'Última edición', NULL, NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 6, 9),
(25, 'News', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'noticias', 'Noticias', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 7, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(26, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'pagina-no-encontrada', 'Página no encontrada', NULL, '<p>Lo sentimos, parece que intentaste acceder a una página que no existe.</p><p>Por favor, comprueba que la URL que intentabas acceder está bien escrita e inténtalo de nuevo.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 8, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(27, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 9, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(35, 'Edicion', '2011-03-07 19:18:48', '2011-03-07 21:21:09', 'new-edicion', 'Enero 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 30),
(33, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:59', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 11, 30),
(39, 'Edicion', '2011-03-08 14:21:12', '2011-03-08 14:21:32', 'diciembre-2009', 'Diciembre 2009', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 2, 30),
(38, 'Edicion', '2011-03-07 21:42:59', '2011-03-11 21:09:55', 'mayo-2011', 'Mayo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 30),
(40, 'Edicion', '2011-03-08 14:22:02', '2011-03-08 14:22:17', 'marzo-2010', 'Marzo 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 2, 30),
(41, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:41', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 5, 30),
(42, 'TutorialPage', '2011-03-10 16:12:42', '2011-03-10 17:48:13', 'riesgo-de-sesgo-de-estudios-clinicos-randomizados', 'Riesgo de Sesgo de Estudios Clínicos Randomizados', NULL, NULL, 'Primer Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 13),
(43, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 18:29:46', 'randomizacion', 'Randomización', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin velit  nisi, aliquam vitae consectetur quis, ornare quis justo. Vestibulum  vehicula, quam vel accumsan vulputate, ipsum velit rhoncus mauris, eget  auctor leo sem a erat. Duis elit magna, hendrerit sit amet eleifend ut,  facilisis id turpis. In hac habitasse platea dictumst. Mauris tempor  adipiscing lorem ac placerat. Morbi quis libero tellus. Nullam eget  risus non velit pellentesque consequat ac eget neque. Donec a justo  aliquam libero hendrerit porttitor. Nulla facilisi. Donec odio dui,  fermentum id fringilla ac, rhoncus ut turpis. Phasellus dignissim,  libero tempus tincidunt luctus, felis eros auctor ante, hendrerit porta  ipsum leo a ante. Donec vehicula ornare sem, eget placerat nisi varius  nec. Suspendisse tristique laoreet sollicitudin. Morbi in sem quam.  Vestibulum pulvinar justo sem, at iaculis velit. Nulla mauris nibh,  rutrum quis pulvinar non, luctus vel lorem. Quisque ac interdum urna.  Mauris commodo lacus ut risus hendrerit mattis. Phasellus dapibus  euismod sodales.</p>\n<p>Cras imperdiet tellus vel turpis ullamcorper quis feugiat sapien  pretium. Praesent dapibus, dolor dictum pulvinar interdum, mi massa  faucibus metus, vel hendrerit sem tellus lacinia tellus. Sed tempus  gravida felis eget rutrum. Aliquam tempor dolor vitae libero condimentum  sed tincidunt velit semper. Nullam tempus lorem odio. Donec convallis  luctus ligula, id mattis nulla dictum ac. Proin neque arcu, imperdiet  nec eleifend quis, dignissim sit amet orci. Curabitur sit amet purus  nisl, ac mollis arcu. Fusce eget tortor tortor. Nunc neque ipsum,  hendrerit nec gravida sit amet, venenatis eget diam. Etiam a leo nisl.  Nam non fermentum purus. Suspendisse placerat elit vitae est tempor  dictum. Nunc eleifend volutpat fringilla. Proin nisi nisl, lacinia nec  lacinia consectetur, tincidunt ut leo. Vestibulum sollicitudin, eros nec  convallis venenatis, felis enim tristique erat, ac ornare nisi elit in  urna.</p>', 'Randomización', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 42),
(44, 'TutorialPart', '2011-03-10 17:50:09', '2011-03-10 18:28:03', 'ocultamiento', 'Ocultamiento', NULL, '<p>Hola soy un contenido</p>', 'Ocultamiento', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 42),
(45, 'TutorialPart', '2011-03-10 17:52:46', '2011-03-10 18:28:20', 'ciego', 'Ciego', NULL, '<p>SDADASDA ASDASD  dasdsa adasd ds adsa elfa dfedaer asdlr edr advfgl</p>', 'Ciego', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 42),
(46, 'TutorialPage', '2011-03-10 18:51:38', '2011-03-10 18:51:51', 'otro-tutorial', 'Otro Tutorial', NULL, NULL, 'Otro Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 13),
(47, 'TutorialPart', '2011-03-10 18:51:57', '2011-03-10 18:52:25', 'inicio', 'Inicio', NULL, NULL, 'Inicio', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 46),
(48, 'TutorialPart', '2011-03-10 18:52:05', '2011-03-10 18:52:34', 'medio', 'Medio', NULL, NULL, 'Medio', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 46),
(49, 'TutorialPart', '2011-03-10 18:52:09', '2011-03-10 18:52:46', 'final', 'Final', NULL, NULL, 'Final', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 46),
(50, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:40:13', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', 'Dip. de med. basada en evidencia', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 14),
(52, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:41:00', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', 'Dip. de rev. sist.', '<p><img class="left" src="assets/novedades50diplomadoweb2-500x355.jpg" width="500" height="355" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 14),
(53, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 16:16:38', 'gabriel-rada', 'Gabriel Rada', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 20),
(54, 'ResumenDeEvidencia', '2011-03-15 15:26:40', '2011-03-15 21:42:35', 'eclipses', 'Eclipses', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  vehicula tincidunt erat, eget imperdiet odio euismod nec. Nunc luctus mi  et nisi tincidunt condimentum sed non magna. Nulla eu lacus massa, eu  tincidunt purus. Ut cursus ipsum dolor, at varius lorem. Mauris mauris  arcu, pretium et aliquet eget, posuere egestas sapien. Quisque ut lacus  et leo hendrerit pharetra. Fusce posuere, turpis a pharetra sodales,  nisl diam condimentum elit, vitae egestas lectus nulla in augue. Cras  posuere metus ut est rhoncus sodales. Nam placerat nibh sed libero  semper vestibulum. Ut mauris dui, tristique vel semper non, ultrices ac  urna. Phasellus mattis varius odio eu tincidunt. Maecenas sagittis  turpis sed magna vulputate id rhoncus nisl hendrerit.</p>\n<p>Suspendisse quis tristique neque. Aliquam erat volutpat. Vestibulum  volutpat accumsan turpis, eget lacinia justo tempus in. In luctus turpis  velit, auctor dapibus leo. Sed nisl elit, tempus sed luctus nec, varius  sed urna. Sed blandit suscipit lorem, quis euismod quam ornare mollis.  Donec volutpat, dui vitae pretium porta, nibh augue iaculis risus, non  imperdiet velit sem eget ante. Suspendisse adipiscing, lorem suscipit  tempor malesuada, nibh felis malesuada tellus, nec porta urna eros ut  dolor. Quisque arcu est, molestie sed adipiscing nec, placerat vitae  massa. Praesent eu erat dui. Praesent congue pulvinar lacus, eu interdum  augue laoreet semper. Vestibulum ante ipsum primis in faucibus orci  luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. Aenean  in turpis orci, eu gravida orci. Nulla pharetra, augue non molestie  sollicitudin, neque quam luctus lectus, in facilisis purus lacus eu  felis. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Suspendisse potenti. Cras neque tellus, sagittis  sed malesuada quis, auctor quis sapien.</p>\n<p>Morbi nec orci sem. Nulla a diam eget dui adipiscing fringilla eu rutrum  lacus. Fusce rutrum placerat massa, eget vehicula nunc feugiat sit  amet. Curabitur a nisl nibh. Etiam at mauris quis nibh dignissim  molestie. Sed convallis lorem ipsum, a lobortis nulla. Morbi ipsum  magna, tempor sed sodales quis, elementum eget lorem. Nunc quam ante,  pharetra sed scelerisque ac, porta vel velit. Ut felis ante, laoreet  quis fermentum eu, tincidunt quis lacus. Fusce tristique ante quis  sapien feugiat sit amet vulputate tellus dictum. Donec commodo venenatis  diam, ac mollis ante faucibus in. Aenean ante nulla, dictum vitae  ultrices eu, sagittis sit amet enim. Etiam a quam quis libero fringilla  ultricies.</p>', 'Eclipses', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 10),
(56, 'ResumenDeEvidenciaMulti', '2011-03-15 15:27:11', '2011-03-16 15:32:15', 'resumenes-support', 'Resúmenes Support', NULL, NULL, 'Resúmenes Support', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 10),
(57, 'ResumenDeEvidencia', '2011-03-15 15:27:59', '2011-03-16 22:34:32', 'resumenes-sin-nombre', 'Resúmenes sin nombre', NULL, NULL, 'Resúmenes sin nombre', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 10),
(58, 'ResumenDeEvidenciaEdicion', '2011-03-15 15:35:55', '2011-03-16 21:20:54', 'febrero-2009', 'Febrero 2009', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 54),
(59, 'ResumenDeEvidenciaEdicion', '2011-03-15 16:32:22', '2011-03-15 16:32:31', 'marzo-2011', 'Marzo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 54),
(60, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:40:08', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 10, 59),
(61, 'Eclipse', '2011-03-15 17:01:13', '2011-03-16 21:40:23', 'vacunacion-con-virus-vivo-atenuado-seria-mas-efectiva-que-virus-inactivado-en-prevencion-de-influenza-en-ninos', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>En niños sin un episodio reciente          de enfermedad obstructiva o asma severa, </strong><strong>¿</strong><strong>es          la vacunación con virus vivo atenuado,            más efectiva que la vacunación con          virus inactivo, en prevenir la influenza?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Live attenuated versus inactivated influenza vaccine in infants and young          children. Belshe RB, Edwards KM, Vesikari T, Black SV, Walker RE, Hultquist          M, Kemble G, Connor EM; CAIV-T Comparative Efficacy Study Group. N Engl          J Med. 2007 Feb 15;356(7):685-96.<br/><a href="http://content.nejm.org/cgi/content/abstract/356/7/685" target="_blank">VER          ARTÍCULO EN SITIO ORIGINAL</a></p>\n<p><strong>Contexto:<br/></strong>La mejor manera de prevenir la influenza y sus complicaciones          es la vacunación. Diversos estudios controlados han demostrado          que la vacuna antiinfluenza es capaz de evitar episodios graves, hospitalización          y significativos costos económicos (1). En Chile desde el año          2006 se vacuna todos los años a los niños entre 6 y 23 meses          de edad (1). Las vacunas antiinfluenza disponibles actualmente en el mundo          contienen virus inactivado (de uso parenteral), virus vivo atenuado (de          uso nasal) o virosomas (de uso parenteral). La vacuna que contiene virus          vivo atenuado de uso nasal se cree que podría estimular una mayor          respuesta sistémica antigénica (2). En nuestro medio, se          encuentran disponibles vacunas inactivadas y virosomales, ambas de uso          parenteral. <strong><br/><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Estudio          clínico randomizado, realizado en 249 centros de atención          primaria, distribuidos en 16 países. Seguimiento a 219 días.</p>\n<table style="width: 90%; height: 227px;" border="2" align="center"><tbody><tr><td width="36%" height="219" valign="top">\n<p><strong>Los pacientes:</strong><br/> Niños entre 6 y 59 meses, con o sin vacunación previa                contra la influenza. Se excluyeron aquellos que presentaran episodios                de enfermedad respiratoria obstructiva o asma severas en los 42                días previos, hipersensibilidad a algún componente                de las vacunas, uso de aspirinas o salicilatos en los 30 días                previos, inmunosupresión, o fiebre &gt; 37,8ºC en los                3 días previos.</p>\n</td>\n<td width="32%" height="219" valign="top">\n<p><strong>Intervención<br/></strong><strong>n=3916</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días                28 y 42) de vacuna intranasal de virus vivo atenuado, más                placebo (inyección intramuscular de suero fisiológico).<br/><br/> CVP: Una dosis en día 0 de vacuna intranasal de virus vivo                atenuado, más placebo (inyección intramuscular de                suero fisiológico).</p>\n</td>\n<td width="32%" height="219" valign="top"><strong>Comparación<br/></strong> <strong>n=3936</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días 28              y 42) de vacuna intramuscular de virus inactivado, más placebo              (spray intranasal de suero fisiológico)\n<p>CVP: Una dosis en día 0 de vacuna intramuscular de virus                inactivado, más placebo (spray intranasal de suero fisiológico).</p>\n</td>\n</tr></tbody></table><p>SVP: sin vacunación previa , CVP: con vacunación        previa</p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 119px;" border="2" align="center"><tbody><tr><td width="50%" height="111" valign="top">\n<p>1- <strong>Randomizado.</strong> SI<br/><strong>    Secuencia de randomización                oculta. </strong>SI<br/> 2-<strong> Seguimiento. </strong>92,6%<br/> 3- <strong>Intención de tratar</strong>. NO<br/> 4- <strong>Grupos similares respecto a variables pronósticas                conocidas</strong>. SI <br/> 5- <strong>Interrumpido precozmente por beneficio.</strong> NO</p>\n</td>\n<td width="50%" height="111" valign="top">\n<p>6-<strong> Pacientes                ciegos a la intervención. </strong>SI<br/><strong>      Tratantes ciegos                a la intervención. </strong> SI<br/><strong>      Recolectores ciegos                a la intervención. </strong>SI<br/><strong>     Adjudicadores ciegos                a la intervención. </strong>SI<br/>     <strong>Analistas ciegos a la                intervención. </strong>SI<strong><br/></strong></p>\n</td>\n</tr></tbody></table><div align="left"><br/><br/><strong>Resultados: <br/></strong><br/><table style="width: 762px; height: 307px;" border="2" align="center"><tbody><tr><td width="210">\n<div align="center"><strong>Outcome<br/></strong></div>\n</td>\n<td width="168">\n<div align="center"><strong>Tasa de eventos en grupo                  virus atenuado</strong></div>\n</td>\n<td width="157">\n<div align="center"><strong>Tasa de eventos en grupo                  virus inactivado</strong></div>\n</td>\n<td width="100">\n<div align="center"><strong>RRR<br/> (95% IC)</strong></div>\n</td>\n<td width="91">\n<div align="center"><strong>NNT<br/> (95% IC) </strong></div>\n</td>\n</tr><tr><td height="57">\n<div align="left"><strong>Influenza (total)*</strong></div>\n</td>\n<td>\n<div align="center">3,9%</div>\n</td>\n<td>\n<div align="center">8,6%</div>\n</td>\n<td>\n<div align="center">55%<br/> (42 a 67)</div>\n</td>\n<td>\n<div align="center">21<br/> (17 a 28)</div>\n</td>\n</tr><tr><td height="49">\n<div align="left"><strong>Influenza A</strong></div>\n</td>\n<td>\n<div align="center">1%</div>\n</td>\n<td>\n<div align="center">5,2%</div>\n</td>\n<td>\n<div align="center">81%<br/> (66 a 95)</div>\n</td>\n<td>\n<div align="center">24 <br/> (20 a 29)</div>\n</td>\n</tr><tr><td height="49"><strong>Influenza B<br/></strong></td>\n<td>\n<div align="center">2,9%</div>\n</td>\n<td>\n<div align="center">3,5%</div>\n</td>\n<td>\n<div align="center">17%<br/> (-5 a 39)</div>\n</td>\n<td>\n<div align="center">168<br/> (73 a inf)</div>\n</td>\n</tr><tr><td height="50">\n<p><strong>Influenza total subgrupo SVP</strong></p>\n</td>\n<td>\n<div align="center">1,2%</div>\n</td>\n<td>\n<div align="center">2,1%</div>\n</td>\n<td>\n<div align="center">43%<br/> (12 a 74)</div>\n</td>\n<td>\n<div align="center">111<br/> (65 a 393)</div>\n</td>\n</tr><tr><td><strong>Influenza total subgrupo CVP</strong></td>\n<td>\n<div align="center">1,9%</div>\n</td>\n<td>\n<div align="center">3,1%</div>\n</td>\n<td>\n<div align="center">39<br/> (-7 a 84)</div>\n</td>\n<td>\n<div align="center">83<br/> (38 a inf)</div>\n</td>\n</tr></tbody></table></div>\n<div align="left">\n<p>RRR= Reducción            del riesgo relativo (RR), NNT= Número necesario para tratar,            IC= Intervalo de confianza, inf=infinito<br/> * Outcome influenza (total) se constató de acuerdo a clínica            sugerente más cultivos confirmatorios. Se realizó un promedio            de 2,4 cultivos por niño durante el seguimiento. <br/><br/><strong><br/></strong> <strong>Comentarios y aplicación práctica:            <br/></strong><em>• Comentarios acerca de la validez (riesgo de sesgo): </em><br/> - En cuanto a su validez, este estudio tiene una metodología            adecuada, sin embargo sus falencias radican en que no son rigurosos            respecto al porcentaje de seguimiento, ni a la intención de tratar.            No explicitan por qué de 8475 pacientes enrolados, se incluyeron            solamente a 8352, y finalmente sólo con 7852 pacientes se obtuvieron            los resultados. Claramente no hay intención de tratar, pues los            pacientes que abandonaron el tratamiento se excluyeron del denominador.            Respecto al seguimiento, siendo rigurosos, este seria de un 92,6%, pues            hay que considerarlo respecto a los pacientes inicialmente enrolados            en el estudio. <br/><em><br/></em> <em>• Comentarios acerca de los resultados: </em><br/> - El estudio demuestra que la intervención con vacuna de virus            atenuado intranasal, es más efectiva que la vacuna con virus            inactivado. Globalmente, incluyendo aquellos casos de Influenza A y            B, previamente vacunados o no, y sin estratificar por edad, el efecto            final apoya el uso de ésta.<em> </em>El número de pacientes            evaluados es adecuado, por lo que los resultados principales son muy            precisos.<em><br/></em>- Al analizar por separado su efecto sobre las diferentes cepas            de Influenza, se registra beneficio significativo de la vacuna intranasal            con virus vivo atenuado para la influenza A, sin embargo, no se demuestra            beneficio significativo para la prevención de la influenza B.<em> <br/></em>- Estratificando los resultados según presencia o ausencia            de vacunación previa, estos muestran que no habría beneficio            significativo para quienes hayan sido vacunados en los 42 días            previos. En cambio, sí se observa efecto significativo para aquellos            que no habían recibido vacunación en los 42 días            previos al estudio.</p>\n<p><em>• Aplicabilidad: </em><br/> - En cuanto a su aplicabilidad, dada la simplicidad de la intervención            y la amplitud de inclusión, estos resultados podrían ser            perfectamente aplicables a nuestro escenario. Además la inyección            intranasal resulta un procedimiento mejor tolerado por los niños            y que no necesita mayor entrenamiento de parte del personal de la salud.            Sin embargo, esta vacuna no está disponible actualmente en Chile,            por lo cual su aplicación inmediata es imposible. Como evaluación            para su aplicación futura, sería importante indagar en            la diferencia de costos entre una y otra, que podría ser otra            limitante en su aplicabilidad. <br/> - También se compararon respecto a sus efectos adversos, donde            fueron equivalentes, excepto en el segmento etario entre 6 y 11 meses,            donde la vacuna intranasal de virus vivo atenuado registró mayor            tasa de eventos adversos (en tasas de 6,4 versus 3,4 de efectos adversos            serios, y 6,1 versus 2,6 de hospitalizaciones por cualquier causa. Ninguno            de los dos grupos registró muertes relacionadas con el tratamiento).            Por lo tanto, una evaluación mas detallada de sus riesgos versus            sus beneficios, indican que su mayor indicación estaría            para el grupo entre 12 y 59 meses.</p>\n<p>- En resumen, este es un estudio con un riesgo de sesgo moderado, que            muestra un beneficio de importante magnitud sobre un outcome de gran            relevancia clínica.</p>\n</div>\n<p><strong> Información adicional:</strong></p>\n<p><strong>Referencias:</strong></p>\n<ol><li>Luis E. Vega-Briceño, Katia Abarca V. e Ignacio Sánchez            D. Flu vaccine in children: State of the art.Rev Chil Infect, 2006;            23 (2): 164, Santiago jun. 2006</li>\n<li> Harper S A, Fukuda K, Uyeki T M, Cox N J, Bridges C B; Centers for            Disease Control and Prevention (CDC). Advisory Committee on Immunization            Practices (ACIP). Prevention and control of influenza: Recommendations            of ACIP. MMWR Morbid Mortal Wkly Rep 2004; 53 (RR-6): 1-40, California            April 2006.</li>\n</ol>', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 59),
(62, 'ResumenDeEvidenciaEdicionMulti', '2011-03-16 15:37:20', '2011-03-16 15:37:34', 'abril-2003', 'Abril 2003', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 56);
INSERT INTO `SiteTree` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `Version`, `ParentID`) VALUES
(63, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 21:40:31', 'hola-soy-un-eclipse-en-espanol', 'Hola soy un eclipse en español', 'Hola soy un eclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al.  Bisphosphonates in multiple myeloma.  Chochrane database of systematic  reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos   randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma   múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos:  MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000),  LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda  manual  se realizó en los abstracts de congreso de las siguientes  sociedades  (1993 al 2000): ASH (american society of hematology), ASCO  (amercian  society for clinical oncology), EHA (european hematology  asociation).  Además se contactó con compañías farmacéuticas que  producen bifosfonatos  y con investigadores alrededor del mundo en USA,  Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se  revisaron las referencias de  los artículos incluidos, y se contactó a  los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó  123 estudios, de los cuales 11  cumplieron con los criterios de  inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de  médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los  estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que  responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples  bases de datos, múltiples idiomas, realizan búsqueda manual en   abstracts de congresos y contacto con compañías farmacéuticas y   expertos, en términos de reproducibilidad de la selección de los   estudios, al menos 2 revisores realizaron esa función y resolvieron las   discrepancias por consenso, y finalmente se evalúo la calidad   metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia   estadística en un outcome como mortalidad, sin embargo, sí se observa   beneficio significativo en la disminución de fracturas vertebrales y en   dolor. Estos outcomes son relevantes, ya que son motivo de consulta,   hospitalización y costos asociados a la patología, los que pueden ser   prevenidos por una intervención fácil, y eventualmente de un costo menor   al relacionado al manejo de las complicaciones antes mencionadas.<br/> -  El metaanálisis mostró una mayor tasa de eventos adversos pero  que no  alcanzó la significancia estadística, en el grupo intervención  (RR 1,28  con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser  individualizado, no parece ser un argumento para no usarlos, aunque  es  cierto que sólo  se habla de síntomas gastrointestinales, muy  variados.  <br/> -          Es importante destacar que respecto a la reducción del  dolor, no  queda claro el método de evaluación que usaron los  respectivos autores  de los diversos ECRs incluidos en este metanálisis,  por lo tanto, siendo  el dolor una variable subjetiva por excelencia  que se intenta objetivar  arbitrariamente, deben interpretarse los  resultados con cautela.<br/> - Los resultados comentados provienen de  ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a  tratamiento con  bifosfonato. Hubiese sido interesante hacer un  análisis de subgrupos  según etapa clínica, ya que parece interesante la  idea de que los  efectos que mostró el bifosfonato sean mayores en  etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a  la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de  bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en  nuestro país es el alendronato, droga no incluida en  ésta revisión,  pero dado el mecanismo de acción común, el clínico podría  extrapolar  éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos  estrictos con los hallazgos de la  revisión, los bifosfonatos que  demostraron claro beneficio fueron  pamidronato y clodronato, por lo  tanto deberían ser los únicos  utilizados para lograr los beneficios que  hemos comentado en nuestros  pacientes con mieloma múltiple.           Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que  debe ser considerado si se piensa utilizar alguno de ellos en  beneficio  de nuestros pacientes. En este sentido si aplicamos el mismo   fundamento de acción común esperaremos resultados similares.<br/> - El  número necesario a tratar (NNT) con esta droga es  prometedor para  nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el  uso de estas drogas en otras patologías que cursan con  complicaciones  similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias  que con frecuencias se complican con compromiso óseo,  dolor y fracturas  en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de  sumar a la terapia estándar, logrando disminuir motivos de  consulta  frecuentes como son las fracturas de hueso patológico o el  dolor. Aun  cuando el bifosfonato más disponible en Chile no se encuentra  en la  revisión nos parece adecuado extrapolar los beneficios  demostrados y  por lo tanto indicarlo en pacientes con mieloma múltiple.  En este  sentido si el paciente tuviera una preferencia por otro  bifosfonato,  como puede ser uno con vía de administración distinta,  podrían evaluar  en conjunto el clínico junto con el paciente, los costos  y beneficios,  llegando a la  decisión final.</p>', 'Adsd', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 62),
(64, 'Page', '2011-03-17 21:17:22', '2011-03-17 21:19:04', 'temas', 'Temas', NULL, NULL, 'Temas', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11),
(66, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:19:32', 'revisiones-sistematicas', 'Revisiones sistemáticas', NULL, NULL, 'Revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 11),
(67, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:19:54', 'estudios-metodicos', 'Estudios metódicos', NULL, NULL, 'Estudios metódicos', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 11),
(68, 'Page', '2011-03-17 21:18:29', '2011-03-17 21:20:17', 'analisis-critico', 'Análisis crítico', NULL, NULL, 'Análisis crítico', NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11),
(69, 'Page', '2011-03-17 21:18:44', '2011-03-17 21:20:43', 'opinion', 'Opinión', NULL, NULL, 'Opinión', NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_EditorGroups`
--

CREATE TABLE IF NOT EXISTS `SiteTree_EditorGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteTree_EditorGroups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_ImageTracking`
--

CREATE TABLE IF NOT EXISTS `SiteTree_ImageTracking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `FileID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `FileID` (`FileID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Volcar la base de datos para la tabla `SiteTree_ImageTracking`
--

INSERT INTO `SiteTree_ImageTracking` (`ID`, `SiteTreeID`, `FileID`, `FieldName`) VALUES
(14, 28, 5, 'Content'),
(28, 52, 6, 'Content');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_LinkTracking`
--

CREATE TABLE IF NOT EXISTS `SiteTree_LinkTracking` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `ChildID` (`ChildID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteTree_LinkTracking`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_Live`
--

CREATE TABLE IF NOT EXISTS `SiteTree_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('SiteTree','Page','EnlacesPage','News','HomePage','TutorialPart','AlertPage','ArchivePage','CursosHolder','CursosPage','Eclipse','Edicion','EdicionesHolder','Glosary','MemberHolder','MemberPage','ProyectosUmbe','ResumenDeEvidencia','RevistasHolder','TutorialPage','TutorialesHolder','ErrorPage','RedirectorPage','VirtualPage','EclipseMulti','ResumenDeEvidenciaEdicion','ResumenDeEvidenciaEdicionMulti','ResumenDeEvidenciaMulti') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HomepageForDomain` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Status` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ToDo` mediumtext CHARACTER SET utf8,
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Volcar la base de datos para la tabla `SiteTree_Live`
--

INSERT INTO `SiteTree_Live` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `Version`, `ParentID`) VALUES
(7, 'HomePage', '2011-03-04 19:36:53', '2011-03-22 14:50:53', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 7, 0),
(8, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:46:32', 'nuestro-trabajo', 'Nuestro Trabajo', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(9, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 16:08:21', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 8),
(10, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-15 21:42:35', 'resumenes-de-evidencia', 'Resúmenes de evidencia', 'Resúmenes', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 8),
(11, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 21:22:22', 'publicaciones', 'Publicaciones', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 8),
(12, 'ProyectosUmbe', '2011-03-04 19:36:54', '2011-03-16 20:08:22', 'proyectos-umbeuc', 'Proyectos UmbeUC', 'Proyectos', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 8),
(13, 'TutorialesHolder', '2011-03-04 19:36:54', '2011-03-10 17:55:39', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 0),
(14, 'CursosHolder', '2011-03-04 19:36:54', '2011-03-11 18:20:27', 'cursos', 'Cursos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 0),
(15, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 16:12:40', 'herramientas', 'Herramientas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(16, 'EnlacesPage', '2011-03-04 19:36:54', '2011-03-11 17:56:07', 'enlaces', 'Enlaces', NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luctus pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec vitae. Donec tempor bibendum elit ac pellentesque.', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 15),
(17, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'calculadora', 'Calculadora', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 15),
(18, 'Glosary', '2011-03-04 19:36:54', '2011-03-10 21:23:31', 'glosario', 'Glosario', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 15),
(19, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-14 16:33:06', 'acerca-de', 'Acerca de', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 0),
(20, 'MemberHolder', '2011-03-04 19:36:54', '2011-03-14 16:21:21', 'quienes-somos', ' Quienes somos', 'Quienes somos', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>', ' Quienes somos', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 6, 19),
(21, 'Page', '2011-03-04 19:36:54', '2011-03-16 20:45:43', 'que-hacemos', 'Qué Hacemos', NULL, '<p>Lorem Ipsum</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 19),
(22, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'terminos', 'Términos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 19),
(23, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'redes-y-alianzas', 'Redes y alianzas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 19),
(28, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 16:08:21', 'que-es', '¿Qué son las alertas?', 'Qué es', '<h2><img class="left" src="assets/medicos.jpeg" width="520" height="390" alt="" title=""/></h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 7, 9),
(29, 'ArchivePage', '2011-03-07 14:50:32', '2011-03-08 19:35:13', 'archivo', 'Archivo', NULL, NULL, 'Archivo', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 9),
(30, 'EdicionesHolder', '2011-03-07 14:50:32', '2011-03-08 16:30:12', 'ultima-edicion', 'Última edición', NULL, NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 6, 9),
(31, 'RevistasHolder', '2011-03-07 14:51:43', '2011-03-08 18:21:18', 'revistas-revisadas', 'Revistas revisadas', 'Revistas', '<p>En esta sección veremos las revistas desde las cuales se obtiene la información que incorporamos en nuestras alertas.</p>', 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 9),
(25, 'News', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'noticias', 'Noticias', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 7, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(26, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'pagina-no-encontrada', 'Página no encontrada', NULL, '<p>Lo sentimos, parece que intentaste acceder a una página que no existe.</p><p>Por favor, comprueba que la URL que intentabas acceder está bien escrita e inténtalo de nuevo.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 8, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(27, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 9, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 1, 0),
(33, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:59', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 11, 30),
(35, 'Edicion', '2011-03-07 19:18:48', '2011-03-07 21:21:09', 'new-edicion', 'Enero 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 30),
(38, 'Edicion', '2011-03-07 21:42:59', '2011-03-11 21:09:55', 'mayo-2011', 'Mayo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 30),
(39, 'Edicion', '2011-03-08 14:21:12', '2011-03-08 14:21:26', 'diciembre-2009', 'Diciembre 2009', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 30),
(40, 'Edicion', '2011-03-08 14:22:02', '2011-03-08 14:22:11', 'marzo-2010', 'Marzo 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 30),
(41, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:28', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 30),
(42, 'TutorialPage', '2011-03-10 16:12:42', '2011-03-10 17:48:13', 'riesgo-de-sesgo-de-estudios-clinicos-randomizados', 'Riesgo de Sesgo de Estudios Clínicos Randomizados', NULL, NULL, 'Primer Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 13),
(43, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 18:29:46', 'randomizacion', 'Randomización', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin velit  nisi, aliquam vitae consectetur quis, ornare quis justo. Vestibulum  vehicula, quam vel accumsan vulputate, ipsum velit rhoncus mauris, eget  auctor leo sem a erat. Duis elit magna, hendrerit sit amet eleifend ut,  facilisis id turpis. In hac habitasse platea dictumst. Mauris tempor  adipiscing lorem ac placerat. Morbi quis libero tellus. Nullam eget  risus non velit pellentesque consequat ac eget neque. Donec a justo  aliquam libero hendrerit porttitor. Nulla facilisi. Donec odio dui,  fermentum id fringilla ac, rhoncus ut turpis. Phasellus dignissim,  libero tempus tincidunt luctus, felis eros auctor ante, hendrerit porta  ipsum leo a ante. Donec vehicula ornare sem, eget placerat nisi varius  nec. Suspendisse tristique laoreet sollicitudin. Morbi in sem quam.  Vestibulum pulvinar justo sem, at iaculis velit. Nulla mauris nibh,  rutrum quis pulvinar non, luctus vel lorem. Quisque ac interdum urna.  Mauris commodo lacus ut risus hendrerit mattis. Phasellus dapibus  euismod sodales.</p>\n<p>Cras imperdiet tellus vel turpis ullamcorper quis feugiat sapien  pretium. Praesent dapibus, dolor dictum pulvinar interdum, mi massa  faucibus metus, vel hendrerit sem tellus lacinia tellus. Sed tempus  gravida felis eget rutrum. Aliquam tempor dolor vitae libero condimentum  sed tincidunt velit semper. Nullam tempus lorem odio. Donec convallis  luctus ligula, id mattis nulla dictum ac. Proin neque arcu, imperdiet  nec eleifend quis, dignissim sit amet orci. Curabitur sit amet purus  nisl, ac mollis arcu. Fusce eget tortor tortor. Nunc neque ipsum,  hendrerit nec gravida sit amet, venenatis eget diam. Etiam a leo nisl.  Nam non fermentum purus. Suspendisse placerat elit vitae est tempor  dictum. Nunc eleifend volutpat fringilla. Proin nisi nisl, lacinia nec  lacinia consectetur, tincidunt ut leo. Vestibulum sollicitudin, eros nec  convallis venenatis, felis enim tristique erat, ac ornare nisi elit in  urna.</p>', 'Randomización', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 42),
(44, 'TutorialPart', '2011-03-10 17:50:09', '2011-03-10 18:28:03', 'ocultamiento', 'Ocultamiento', NULL, '<p>Hola soy un contenido</p>', 'Ocultamiento', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 42),
(45, 'TutorialPart', '2011-03-10 17:52:46', '2011-03-10 18:28:20', 'ciego', 'Ciego', NULL, '<p>SDADASDA ASDASD  dasdsa adasd ds adsa elfa dfedaer asdlr edr advfgl</p>', 'Ciego', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 42),
(46, 'TutorialPage', '2011-03-10 18:51:38', '2011-03-10 18:51:51', 'otro-tutorial', 'Otro Tutorial', NULL, NULL, 'Otro Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 13),
(47, 'TutorialPart', '2011-03-10 18:51:57', '2011-03-10 18:52:25', 'inicio', 'Inicio', NULL, NULL, 'Inicio', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 46),
(48, 'TutorialPart', '2011-03-10 18:52:05', '2011-03-10 18:52:34', 'medio', 'Medio', NULL, NULL, 'Medio', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 46),
(49, 'TutorialPart', '2011-03-10 18:52:09', '2011-03-10 18:52:46', 'final', 'Final', NULL, NULL, 'Final', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 46),
(50, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:40:13', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', 'Dip. de med. basada en evidencia', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 14),
(52, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:41:00', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', 'Dip. de rev. sist.', '<p><img class="left" src="assets/novedades50diplomadoweb2-500x355.jpg" width="500" height="355" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 5, 14),
(53, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 16:16:38', 'gabriel-rada', 'Gabriel Rada', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 20),
(54, 'ResumenDeEvidencia', '2011-03-15 15:26:40', '2011-03-15 21:42:35', 'eclipses', 'Eclipses', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  vehicula tincidunt erat, eget imperdiet odio euismod nec. Nunc luctus mi  et nisi tincidunt condimentum sed non magna. Nulla eu lacus massa, eu  tincidunt purus. Ut cursus ipsum dolor, at varius lorem. Mauris mauris  arcu, pretium et aliquet eget, posuere egestas sapien. Quisque ut lacus  et leo hendrerit pharetra. Fusce posuere, turpis a pharetra sodales,  nisl diam condimentum elit, vitae egestas lectus nulla in augue. Cras  posuere metus ut est rhoncus sodales. Nam placerat nibh sed libero  semper vestibulum. Ut mauris dui, tristique vel semper non, ultrices ac  urna. Phasellus mattis varius odio eu tincidunt. Maecenas sagittis  turpis sed magna vulputate id rhoncus nisl hendrerit.</p>\n<p>Suspendisse quis tristique neque. Aliquam erat volutpat. Vestibulum  volutpat accumsan turpis, eget lacinia justo tempus in. In luctus turpis  velit, auctor dapibus leo. Sed nisl elit, tempus sed luctus nec, varius  sed urna. Sed blandit suscipit lorem, quis euismod quam ornare mollis.  Donec volutpat, dui vitae pretium porta, nibh augue iaculis risus, non  imperdiet velit sem eget ante. Suspendisse adipiscing, lorem suscipit  tempor malesuada, nibh felis malesuada tellus, nec porta urna eros ut  dolor. Quisque arcu est, molestie sed adipiscing nec, placerat vitae  massa. Praesent eu erat dui. Praesent congue pulvinar lacus, eu interdum  augue laoreet semper. Vestibulum ante ipsum primis in faucibus orci  luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. Aenean  in turpis orci, eu gravida orci. Nulla pharetra, augue non molestie  sollicitudin, neque quam luctus lectus, in facilisis purus lacus eu  felis. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Suspendisse potenti. Cras neque tellus, sagittis  sed malesuada quis, auctor quis sapien.</p>\n<p>Morbi nec orci sem. Nulla a diam eget dui adipiscing fringilla eu rutrum  lacus. Fusce rutrum placerat massa, eget vehicula nunc feugiat sit  amet. Curabitur a nisl nibh. Etiam at mauris quis nibh dignissim  molestie. Sed convallis lorem ipsum, a lobortis nulla. Morbi ipsum  magna, tempor sed sodales quis, elementum eget lorem. Nunc quam ante,  pharetra sed scelerisque ac, porta vel velit. Ut felis ante, laoreet  quis fermentum eu, tincidunt quis lacus. Fusce tristique ante quis  sapien feugiat sit amet vulputate tellus dictum. Donec commodo venenatis  diam, ac mollis ante faucibus in. Aenean ante nulla, dictum vitae  ultrices eu, sagittis sit amet enim. Etiam a quam quis libero fringilla  ultricies.</p>', 'Eclipses', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 10),
(56, 'ResumenDeEvidenciaMulti', '2011-03-15 15:27:11', '2011-03-16 15:32:15', 'resumenes-support', 'Resúmenes Support', NULL, NULL, 'Resúmenes Support', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 10),
(57, 'ResumenDeEvidencia', '2011-03-15 15:27:59', '2011-03-16 22:34:32', 'resumenes-sin-nombre', 'Resúmenes sin nombre', NULL, NULL, 'Resúmenes sin nombre', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 10),
(58, 'ResumenDeEvidenciaEdicion', '2011-03-15 15:35:55', '2011-03-16 21:20:54', 'febrero-2009', 'Febrero 2009', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 54),
(59, 'ResumenDeEvidenciaEdicion', '2011-03-15 16:32:22', '2011-03-15 16:32:31', 'marzo-2011', 'Marzo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 54),
(60, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:40:08', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 10, 59),
(61, 'Eclipse', '2011-03-15 17:01:13', '2011-03-16 21:40:23', 'vacunacion-con-virus-vivo-atenuado-seria-mas-efectiva-que-virus-inactivado-en-prevencion-de-influenza-en-ninos', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>En niños sin un episodio reciente          de enfermedad obstructiva o asma severa, </strong><strong>¿</strong><strong>es          la vacunación con virus vivo atenuado,            más efectiva que la vacunación con          virus inactivo, en prevenir la influenza?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Live attenuated versus inactivated influenza vaccine in infants and young          children. Belshe RB, Edwards KM, Vesikari T, Black SV, Walker RE, Hultquist          M, Kemble G, Connor EM; CAIV-T Comparative Efficacy Study Group. N Engl          J Med. 2007 Feb 15;356(7):685-96.<br/><a href="http://content.nejm.org/cgi/content/abstract/356/7/685" target="_blank">VER          ARTÍCULO EN SITIO ORIGINAL</a></p>\n<p><strong>Contexto:<br/></strong>La mejor manera de prevenir la influenza y sus complicaciones          es la vacunación. Diversos estudios controlados han demostrado          que la vacuna antiinfluenza es capaz de evitar episodios graves, hospitalización          y significativos costos económicos (1). En Chile desde el año          2006 se vacuna todos los años a los niños entre 6 y 23 meses          de edad (1). Las vacunas antiinfluenza disponibles actualmente en el mundo          contienen virus inactivado (de uso parenteral), virus vivo atenuado (de          uso nasal) o virosomas (de uso parenteral). La vacuna que contiene virus          vivo atenuado de uso nasal se cree que podría estimular una mayor          respuesta sistémica antigénica (2). En nuestro medio, se          encuentran disponibles vacunas inactivadas y virosomales, ambas de uso          parenteral. <strong><br/><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Estudio          clínico randomizado, realizado en 249 centros de atención          primaria, distribuidos en 16 países. Seguimiento a 219 días.</p>\n<table style="width: 90%; height: 227px;" border="2" align="center"><tbody><tr><td width="36%" height="219" valign="top">\n<p><strong>Los pacientes:</strong><br/> Niños entre 6 y 59 meses, con o sin vacunación previa                contra la influenza. Se excluyeron aquellos que presentaran episodios                de enfermedad respiratoria obstructiva o asma severas en los 42                días previos, hipersensibilidad a algún componente                de las vacunas, uso de aspirinas o salicilatos en los 30 días                previos, inmunosupresión, o fiebre &gt; 37,8ºC en los                3 días previos.</p>\n</td>\n<td width="32%" height="219" valign="top">\n<p><strong>Intervención<br/></strong><strong>n=3916</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días                28 y 42) de vacuna intranasal de virus vivo atenuado, más                placebo (inyección intramuscular de suero fisiológico).<br/><br/> CVP: Una dosis en día 0 de vacuna intranasal de virus vivo                atenuado, más placebo (inyección intramuscular de                suero fisiológico).</p>\n</td>\n<td width="32%" height="219" valign="top"><strong>Comparación<br/></strong> <strong>n=3936</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días 28              y 42) de vacuna intramuscular de virus inactivado, más placebo              (spray intranasal de suero fisiológico)\n<p>CVP: Una dosis en día 0 de vacuna intramuscular de virus                inactivado, más placebo (spray intranasal de suero fisiológico).</p>\n</td>\n</tr></tbody></table><p>SVP: sin vacunación previa , CVP: con vacunación        previa</p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 119px;" border="2" align="center"><tbody><tr><td width="50%" height="111" valign="top">\n<p>1- <strong>Randomizado.</strong> SI<br/><strong>    Secuencia de randomización                oculta. </strong>SI<br/> 2-<strong> Seguimiento. </strong>92,6%<br/> 3- <strong>Intención de tratar</strong>. NO<br/> 4- <strong>Grupos similares respecto a variables pronósticas                conocidas</strong>. SI <br/> 5- <strong>Interrumpido precozmente por beneficio.</strong> NO</p>\n</td>\n<td width="50%" height="111" valign="top">\n<p>6-<strong> Pacientes                ciegos a la intervención. </strong>SI<br/><strong>      Tratantes ciegos                a la intervención. </strong> SI<br/><strong>      Recolectores ciegos                a la intervención. </strong>SI<br/><strong>     Adjudicadores ciegos                a la intervención. </strong>SI<br/>     <strong>Analistas ciegos a la                intervención. </strong>SI<strong><br/></strong></p>\n</td>\n</tr></tbody></table><div align="left"><br/><br/><strong>Resultados: <br/></strong><br/><table style="width: 762px; height: 307px;" border="2" align="center"><tbody><tr><td width="210">\n<div align="center"><strong>Outcome<br/></strong></div>\n</td>\n<td width="168">\n<div align="center"><strong>Tasa de eventos en grupo                  virus atenuado</strong></div>\n</td>\n<td width="157">\n<div align="center"><strong>Tasa de eventos en grupo                  virus inactivado</strong></div>\n</td>\n<td width="100">\n<div align="center"><strong>RRR<br/> (95% IC)</strong></div>\n</td>\n<td width="91">\n<div align="center"><strong>NNT<br/> (95% IC) </strong></div>\n</td>\n</tr><tr><td height="57">\n<div align="left"><strong>Influenza (total)*</strong></div>\n</td>\n<td>\n<div align="center">3,9%</div>\n</td>\n<td>\n<div align="center">8,6%</div>\n</td>\n<td>\n<div align="center">55%<br/> (42 a 67)</div>\n</td>\n<td>\n<div align="center">21<br/> (17 a 28)</div>\n</td>\n</tr><tr><td height="49">\n<div align="left"><strong>Influenza A</strong></div>\n</td>\n<td>\n<div align="center">1%</div>\n</td>\n<td>\n<div align="center">5,2%</div>\n</td>\n<td>\n<div align="center">81%<br/> (66 a 95)</div>\n</td>\n<td>\n<div align="center">24 <br/> (20 a 29)</div>\n</td>\n</tr><tr><td height="49"><strong>Influenza B<br/></strong></td>\n<td>\n<div align="center">2,9%</div>\n</td>\n<td>\n<div align="center">3,5%</div>\n</td>\n<td>\n<div align="center">17%<br/> (-5 a 39)</div>\n</td>\n<td>\n<div align="center">168<br/> (73 a inf)</div>\n</td>\n</tr><tr><td height="50">\n<p><strong>Influenza total subgrupo SVP</strong></p>\n</td>\n<td>\n<div align="center">1,2%</div>\n</td>\n<td>\n<div align="center">2,1%</div>\n</td>\n<td>\n<div align="center">43%<br/> (12 a 74)</div>\n</td>\n<td>\n<div align="center">111<br/> (65 a 393)</div>\n</td>\n</tr><tr><td><strong>Influenza total subgrupo CVP</strong></td>\n<td>\n<div align="center">1,9%</div>\n</td>\n<td>\n<div align="center">3,1%</div>\n</td>\n<td>\n<div align="center">39<br/> (-7 a 84)</div>\n</td>\n<td>\n<div align="center">83<br/> (38 a inf)</div>\n</td>\n</tr></tbody></table></div>\n<div align="left">\n<p>RRR= Reducción            del riesgo relativo (RR), NNT= Número necesario para tratar,            IC= Intervalo de confianza, inf=infinito<br/> * Outcome influenza (total) se constató de acuerdo a clínica            sugerente más cultivos confirmatorios. Se realizó un promedio            de 2,4 cultivos por niño durante el seguimiento. <br/><br/><strong><br/></strong> <strong>Comentarios y aplicación práctica:            <br/></strong><em>• Comentarios acerca de la validez (riesgo de sesgo): </em><br/> - En cuanto a su validez, este estudio tiene una metodología            adecuada, sin embargo sus falencias radican en que no son rigurosos            respecto al porcentaje de seguimiento, ni a la intención de tratar.            No explicitan por qué de 8475 pacientes enrolados, se incluyeron            solamente a 8352, y finalmente sólo con 7852 pacientes se obtuvieron            los resultados. Claramente no hay intención de tratar, pues los            pacientes que abandonaron el tratamiento se excluyeron del denominador.            Respecto al seguimiento, siendo rigurosos, este seria de un 92,6%, pues            hay que considerarlo respecto a los pacientes inicialmente enrolados            en el estudio. <br/><em><br/></em> <em>• Comentarios acerca de los resultados: </em><br/> - El estudio demuestra que la intervención con vacuna de virus            atenuado intranasal, es más efectiva que la vacuna con virus            inactivado. Globalmente, incluyendo aquellos casos de Influenza A y            B, previamente vacunados o no, y sin estratificar por edad, el efecto            final apoya el uso de ésta.<em> </em>El número de pacientes            evaluados es adecuado, por lo que los resultados principales son muy            precisos.<em><br/></em>- Al analizar por separado su efecto sobre las diferentes cepas            de Influenza, se registra beneficio significativo de la vacuna intranasal            con virus vivo atenuado para la influenza A, sin embargo, no se demuestra            beneficio significativo para la prevención de la influenza B.<em> <br/></em>- Estratificando los resultados según presencia o ausencia            de vacunación previa, estos muestran que no habría beneficio            significativo para quienes hayan sido vacunados en los 42 días            previos. En cambio, sí se observa efecto significativo para aquellos            que no habían recibido vacunación en los 42 días            previos al estudio.</p>\n<p><em>• Aplicabilidad: </em><br/> - En cuanto a su aplicabilidad, dada la simplicidad de la intervención            y la amplitud de inclusión, estos resultados podrían ser            perfectamente aplicables a nuestro escenario. Además la inyección            intranasal resulta un procedimiento mejor tolerado por los niños            y que no necesita mayor entrenamiento de parte del personal de la salud.            Sin embargo, esta vacuna no está disponible actualmente en Chile,            por lo cual su aplicación inmediata es imposible. Como evaluación            para su aplicación futura, sería importante indagar en            la diferencia de costos entre una y otra, que podría ser otra            limitante en su aplicabilidad. <br/> - También se compararon respecto a sus efectos adversos, donde            fueron equivalentes, excepto en el segmento etario entre 6 y 11 meses,            donde la vacuna intranasal de virus vivo atenuado registró mayor            tasa de eventos adversos (en tasas de 6,4 versus 3,4 de efectos adversos            serios, y 6,1 versus 2,6 de hospitalizaciones por cualquier causa. Ninguno            de los dos grupos registró muertes relacionadas con el tratamiento).            Por lo tanto, una evaluación mas detallada de sus riesgos versus            sus beneficios, indican que su mayor indicación estaría            para el grupo entre 12 y 59 meses.</p>\n<p>- En resumen, este es un estudio con un riesgo de sesgo moderado, que            muestra un beneficio de importante magnitud sobre un outcome de gran            relevancia clínica.</p>\n</div>\n<p><strong> Información adicional:</strong></p>\n<p><strong>Referencias:</strong></p>\n<ol><li>Luis E. Vega-Briceño, Katia Abarca V. e Ignacio Sánchez            D. Flu vaccine in children: State of the art.Rev Chil Infect, 2006;            23 (2): 164, Santiago jun. 2006</li>\n<li> Harper S A, Fukuda K, Uyeki T M, Cox N J, Bridges C B; Centers for            Disease Control and Prevention (CDC). Advisory Committee on Immunization            Practices (ACIP). Prevention and control of influenza: Recommendations            of ACIP. MMWR Morbid Mortal Wkly Rep 2004; 53 (RR-6): 1-40, California            April 2006.</li>\n</ol>', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 3, 59),
(62, 'ResumenDeEvidenciaEdicionMulti', '2011-03-16 15:37:20', '2011-03-16 15:37:34', 'abril-2003', 'Abril 2003', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 1, 56);
INSERT INTO `SiteTree_Live` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `Version`, `ParentID`) VALUES
(63, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 21:40:31', 'hola-soy-un-eclipse-en-espanol', 'Hola soy un eclipse en español', 'Hola soy un eclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al.  Bisphosphonates in multiple myeloma.  Chochrane database of systematic  reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos   randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma   múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos:  MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000),  LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda  manual  se realizó en los abstracts de congreso de las siguientes  sociedades  (1993 al 2000): ASH (american society of hematology), ASCO  (amercian  society for clinical oncology), EHA (european hematology  asociation).  Además se contactó con compañías farmacéuticas que  producen bifosfonatos  y con investigadores alrededor del mundo en USA,  Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se  revisaron las referencias de  los artículos incluidos, y se contactó a  los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó  123 estudios, de los cuales 11  cumplieron con los criterios de  inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de  médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los  estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que  responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples  bases de datos, múltiples idiomas, realizan búsqueda manual en   abstracts de congresos y contacto con compañías farmacéuticas y   expertos, en términos de reproducibilidad de la selección de los   estudios, al menos 2 revisores realizaron esa función y resolvieron las   discrepancias por consenso, y finalmente se evalúo la calidad   metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia   estadística en un outcome como mortalidad, sin embargo, sí se observa   beneficio significativo en la disminución de fracturas vertebrales y en   dolor. Estos outcomes son relevantes, ya que son motivo de consulta,   hospitalización y costos asociados a la patología, los que pueden ser   prevenidos por una intervención fácil, y eventualmente de un costo menor   al relacionado al manejo de las complicaciones antes mencionadas.<br/> -  El metaanálisis mostró una mayor tasa de eventos adversos pero  que no  alcanzó la significancia estadística, en el grupo intervención  (RR 1,28  con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser  individualizado, no parece ser un argumento para no usarlos, aunque  es  cierto que sólo  se habla de síntomas gastrointestinales, muy  variados.  <br/> -          Es importante destacar que respecto a la reducción del  dolor, no  queda claro el método de evaluación que usaron los  respectivos autores  de los diversos ECRs incluidos en este metanálisis,  por lo tanto, siendo  el dolor una variable subjetiva por excelencia  que se intenta objetivar  arbitrariamente, deben interpretarse los  resultados con cautela.<br/> - Los resultados comentados provienen de  ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a  tratamiento con  bifosfonato. Hubiese sido interesante hacer un  análisis de subgrupos  según etapa clínica, ya que parece interesante la  idea de que los  efectos que mostró el bifosfonato sean mayores en  etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a  la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de  bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en  nuestro país es el alendronato, droga no incluida en  ésta revisión,  pero dado el mecanismo de acción común, el clínico podría  extrapolar  éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos  estrictos con los hallazgos de la  revisión, los bifosfonatos que  demostraron claro beneficio fueron  pamidronato y clodronato, por lo  tanto deberían ser los únicos  utilizados para lograr los beneficios que  hemos comentado en nuestros  pacientes con mieloma múltiple.           Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que  debe ser considerado si se piensa utilizar alguno de ellos en  beneficio  de nuestros pacientes. En este sentido si aplicamos el mismo   fundamento de acción común esperaremos resultados similares.<br/> - El  número necesario a tratar (NNT) con esta droga es  prometedor para  nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el  uso de estas drogas en otras patologías que cursan con  complicaciones  similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias  que con frecuencias se complican con compromiso óseo,  dolor y fracturas  en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de  sumar a la terapia estándar, logrando disminuir motivos de  consulta  frecuentes como son las fracturas de hueso patológico o el  dolor. Aun  cuando el bifosfonato más disponible en Chile no se encuentra  en la  revisión nos parece adecuado extrapolar los beneficios  demostrados y  por lo tanto indicarlo en pacientes con mieloma múltiple.  En este  sentido si el paciente tuviera una preferencia por otro  bifosfonato,  como puede ser uno con vía de administración distinta,  podrían evaluar  en conjunto el clínico junto con el paciente, los costos  y beneficios,  llegando a la  decisión final.</p>', 'Adsd', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 62),
(64, 'Page', '2011-03-17 21:17:22', '2011-03-17 21:19:04', 'temas', 'Temas', NULL, NULL, 'Temas', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11),
(66, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:19:32', 'revisiones-sistematicas', 'Revisiones sistemáticas', NULL, NULL, 'Revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 11),
(67, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:19:54', 'estudios-metodicos', 'Estudios metódicos', NULL, NULL, 'Estudios metódicos', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 4, 11),
(68, 'Page', '2011-03-17 21:18:29', '2011-03-17 21:20:17', 'analisis-critico', 'Análisis crítico', NULL, NULL, 'Análisis crítico', NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11),
(69, 'Page', '2011-03-17 21:18:44', '2011-03-17 21:20:43', 'opinion', 'Opinión', NULL, NULL, 'Opinión', NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 2, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_versions`
--

CREATE TABLE IF NOT EXISTS `SiteTree_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('SiteTree','Page','EnlacesPage','News','HomePage','TutorialPart','AlertPage','ArchivePage','CursosHolder','CursosPage','Eclipse','Edicion','EdicionesHolder','Glosary','MemberHolder','MemberPage','ProyectosUmbe','ResumenDeEvidencia','RevistasHolder','TutorialPage','TutorialesHolder','ErrorPage','RedirectorPage','VirtualPage','EclipseMulti','ResumenDeEvidenciaEdicion','ResumenDeEvidenciaEdicionMulti','ResumenDeEvidenciaMulti') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `MetaKeywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HomepageForDomain` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Status` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ToDo` mediumtext CHARACTER SET utf8,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `AuthorID` (`AuthorID`),
  KEY `PublisherID` (`PublisherID`),
  KEY `ParentID` (`ParentID`),
  KEY `URLSegment` (`URLSegment`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=201 ;

--
-- Volcar la base de datos para la tabla `SiteTree_versions`
--

INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `ParentID`) VALUES
(1, 1, 1, 1, 0, 0, 'Page', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'home', 'Inicio', NULL, '<p>Bienvenido a SilverStripe! Esta es la página de inicio por defecto. Puedes editarla abriendo <a href="admin/">el Sistema Gestor de Contenidos (CMS)</a>. Puedes acceder ahora a <a href="http://doc.silverstripe.com">la documentación para desarrolladores</a>, o empezar <a href="http://doc.silverstripe.com/doku.php?id=tutorials">los tutoriales.</a></p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(2, 2, 1, 1, 0, 0, 'Page', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'sobre-nosotros', 'Sobre nosotros', NULL, '<p>Tú puedes rellenar esta página con tu propio contenido, o borrarla y crear tus propias páginas.<br/>Aquí pondrías información sobre los dueños de tu página.<br/></p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(3, 3, 1, 1, 0, 0, 'Page', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'contacta-con-nosotros', 'Contacta con nosotros', NULL, '<p>Tú puedes rellenar esta página con tu propio contenido, o borrarla y crear tus propias páginas.<br/>Aquí pondrías tu información de contacto.<br/></p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(4, 4, 1, 1, 0, 0, 'News', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'noticias', 'Noticias', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(5, 5, 1, 1, 0, 0, 'ErrorPage', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'pagina-no-encontrada', 'Página no encontrada', NULL, '<p>Lo sentimos, parece que intentaste acceder a una página que no existe.</p><p>Por favor, comprueba que la URL que intentabas acceder está bien escrita e inténtalo de nuevo.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 5, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(6, 6, 1, 1, 0, 0, 'ErrorPage', '2011-03-04 18:52:39', '2011-03-04 18:52:39', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 6, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(7, 7, 1, 0, 1, 0, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'inicio', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 0, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(8, 7, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'inicio', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(9, 8, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'nuestro-trabajo', 'Nuestro Trabajo', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(10, 9, 1, 0, 1, 0, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 0, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 8),
(11, 9, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 8),
(12, 10, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:53', '2011-03-04 19:36:53', 'resumenes-de-evidencia', 'Resúmenes de evidencia', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 8),
(13, 11, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'publicaciones', 'Publicaciones', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 8),
(14, 12, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'proyectos-umbeuc', 'Proyectos UmbeUC', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 8),
(15, 13, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(16, 14, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'cursos', 'Cursos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(17, 15, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'herramientas', 'Herramientas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(18, 16, 1, 0, 1, 0, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'enlaces', 'Enlaces', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 0, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 15),
(19, 16, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'enlaces', 'Enlaces', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 15),
(20, 17, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'calculadora', 'Calculadora', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 15),
(21, 18, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'glosario', 'Glosario', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 15),
(22, 19, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'acerca-de', 'Acerca de', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(23, 20, 1, 0, 1, 0, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'quienes-somos', 'Quiénes somos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 0, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 19),
(24, 20, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'quienes-somos', 'Quiénes somos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 19),
(25, 21, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'que-hacemos', 'Qué Hacemos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 19),
(26, 22, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'terminos', 'Términos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 19),
(27, 23, 1, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 19:36:54', 'redes-y-alianzas', 'Redes y alianzas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 19),
(28, 7, 3, 1, 1, 1, 'HomePage', '2011-03-04 19:36:53', '2011-03-04 19:37:22', 'inicio', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(29, 24, 1, 1, 1, 1, 'Page', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'home', 'Inicio', NULL, '<p>Bienvenido a SilverStripe! Esta es la página de inicio por defecto. Puedes editarla abriendo <a href="admin/">el Sistema Gestor de Contenidos (CMS)</a>. Puedes acceder ahora a <a href="http://doc.silverstripe.com">la documentación para desarrolladores</a>, o empezar <a href="http://doc.silverstripe.com/doku.php?id=tutorials">los tutoriales.</a></p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(30, 25, 1, 1, 1, 1, 'News', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'noticias', 'Noticias', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 7, 0, 0, 'Published', NULL, 'Inherit', 'Inherit', NULL, 0),
(31, 26, 1, 1, 1, 1, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'pagina-no-encontrada', 'Página no encontrada', NULL, '<p>Lo sentimos, parece que intentaste acceder a una página que no existe.</p><p>Por favor, comprueba que la URL que intentabas acceder está bien escrita e inténtalo de nuevo.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 8, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(32, 27, 1, 1, 1, 1, 'ErrorPage', '2011-03-04 19:37:31', '2011-03-04 19:37:31', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, NULL, NULL, 0, 0, NULL, 0, 9, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 0),
(33, 7, 4, 1, 1, 1, 'HomePage', '2011-03-04 19:36:53', '2011-03-04 19:38:27', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(34, 10, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:53', '2011-03-04 21:33:50', 'resumenes-de-evidencia', 'Resúmenes de evidencia', 'Resúmenes', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(35, 12, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-04 21:34:42', 'proyectos-umbeuc', 'Proyectos UmbeUC', 'Proyectos', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(36, 7, 5, 1, 1, 1, 'HomePage', '2011-03-04 19:36:53', '2011-03-07 14:25:37', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(37, 7, 6, 1, 1, 1, 'HomePage', '2011-03-04 19:36:53', '2011-03-07 14:29:26', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(38, 28, 1, 0, 1, 0, 'Page', '2011-03-07 14:49:57', '2011-03-07 14:49:57', 'nuevapage', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 9),
(39, 28, 2, 1, 1, 1, 'Page', '2011-03-07 14:49:57', '2011-03-07 14:50:27', 'que-es', 'Qué es', NULL, NULL, 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 9),
(40, 29, 1, 0, 1, 0, 'HomePage', '2011-03-07 14:50:32', '2011-03-07 14:50:32', 'new-homepage', 'NuevaHomePage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 9),
(41, 30, 1, 0, 1, 0, 'HomePage', '2011-03-07 14:50:32', '2011-03-07 14:50:32', 'new-homepage-2', 'NuevaHomePage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 9),
(42, 29, 2, 1, 1, 1, 'Page', '2011-03-07 14:50:32', '2011-03-07 14:50:44', 'new-homepage', 'NuevaHomePage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 9),
(43, 30, 2, 1, 1, 1, 'Page', '2011-03-07 14:50:32', '2011-03-07 14:50:58', 'new-homepage-2', 'NuevaHomePage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 9),
(44, 29, 3, 1, 1, 1, 'Page', '2011-03-07 14:50:32', '2011-03-07 14:51:17', 'archivo', 'Archivo', NULL, NULL, 'Archivo', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(45, 30, 3, 1, 1, 1, 'Page', '2011-03-07 14:50:32', '2011-03-07 14:51:36', 'ultima-edicion', 'Última Edición', NULL, NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(46, 31, 1, 0, 1, 0, 'Page', '2011-03-07 14:51:43', '2011-03-07 14:51:43', 'nuevapage', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 9),
(47, 31, 2, 1, 1, 1, 'Page', '2011-03-07 14:51:43', '2011-03-07 14:51:55', 'revistas', 'Revistas', NULL, NULL, 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 9),
(48, 9, 3, 1, 1, 1, 'AlertPage', '2011-03-04 19:36:53', '2011-03-07 15:19:50', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(49, 8, 2, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:35:35', 'nuestro-trabajo', 'Nuestro Trabajo', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(50, 8, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:35:47', 'nuestro-trabajo', 'Nuestro Trabajo', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(51, 9, 4, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:46:22', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(52, 9, 5, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-07 15:46:32', 'alertas', 'Alertas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(53, 28, 3, 1, 1, 1, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 15:46:42', 'que-es', 'Qué es', NULL, NULL, 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(54, 28, 4, 1, 1, 1, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 15:59:13', 'que-es', 'Qué es', NULL, '<h2>¿Qué son las las alertas?</h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(55, 28, 5, 1, 1, 1, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 16:00:33', 'que-es', 'Qué es', NULL, '<h2>¿Qué son las las alertas?</h2>\n<p><img class="left" src="assets/medicos.jpeg" width="520" height="390" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(56, 28, 6, 1, 1, 1, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 16:07:06', 'que-es', '¿Qué son las alertas?', 'Qué es', '<h2><img class="left" src="assets/medicos.jpeg" width="520" height="390" alt="" title=""/></h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(57, 28, 7, 1, 1, 1, 'AlertPage', '2011-03-07 14:49:57', '2011-03-07 16:08:21', 'que-es', '¿Qué son las alertas?', 'Qué es', '<h2><img class="left" src="assets/medicos.jpeg" width="520" height="390" alt="" title=""/></h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  ultricies, lorem ut facilisis imperdiet, sapien velit placerat justo, ut  imperdiet ipsum neque eu turpis. Sed auctor laoreet semper. Integer id  enim non lorem gravida varius at vitae metus. Nulla et libero et elit  egestas hendrerit. Praesent ultricies suscipit arcu, ut semper est  volutpat at. Cum sociis natoque penatibus et magnis dis parturient  montes, nascetur ridiculus mus. Sed at justo in est egestas dictum eu et  massa. Nam porta orci ac odio ultricies mattis. Vivamus tincidunt  lobortis lobortis. Proin auctor, justo eu venenatis accumsan, urna dui  faucibus augue, vitae porta metus lorem a ante. Nullam ac ligula massa.  Ut non sem sapien, id aliquam eros. Nam sollicitudin massa vitae diam  sagittis non rutrum massa elementum. Phasellus mattis tempus mi, id  sagittis dolor volutpat quis. Integer non augue vitae enim volutpat  malesuada. Vivamus sagittis, sapien a blandit dictum, nunc metus  sollicitudin mi, nec imperdiet magna leo at velit. Duis bibendum  scelerisque elit, a tempor urna laoreet placerat. Mauris fermentum  faucibus nunc, quis tempus mauris mattis vel. Maecenas cursus, ligula  eget malesuada laoreet, arcu urna lacinia quam, hendrerit tincidunt  augue leo sed ipsum. Morbi volutpat neque et nisi tempor imperdiet.</p>', 'Que es', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(58, 30, 4, 1, 1, 1, 'EdicionesHolder', '2011-03-07 14:50:32', '2011-03-07 18:46:51', 'ultima-edicion', 'Última Edición', NULL, NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(59, 32, 1, 0, 1, 0, 'AlertPage', '2011-03-07 18:47:18', '2011-03-07 18:47:18', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(60, 33, 1, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-07 18:53:07', 'new-edicion', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(61, 34, 1, 0, 1, 0, 'AlertPage', '2011-03-07 18:53:17', '2011-03-07 18:53:17', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 33),
(62, 33, 2, 1, 1, 1, 'Edicion', '2011-03-07 18:53:07', '2011-03-07 18:57:13', 'alertas-de-diciembre-2010', 'Alertas de Diciembre 2010', 'Diciembre 2010', NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 30),
(63, 33, 3, 1, 1, 1, 'Edicion', '2011-03-07 18:53:07', '2011-03-07 18:58:22', 'alertas-de-diciembre-2010', 'Alertas de Diciembre 2010', 'Diciembre 2010', NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(64, 35, 1, 1, 1, 1, 'Edicion', '2011-03-07 19:18:48', '2011-03-07 19:18:48', 'new-edicion', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(65, 30, 5, 1, 1, 1, 'EdicionesHolder', '2011-03-07 14:50:32', '2011-03-07 19:19:12', 'ultima-edicion', 'Última Edición', 'Ediciones', NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(66, 35, 2, 1, 1, 1, 'Edicion', '2011-03-07 19:18:48', '2011-03-07 21:21:09', 'new-edicion', 'Enero 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(67, 36, 1, 0, 1, 0, 'Edicion', '2011-03-07 21:29:15', '2011-03-07 21:29:15', 'new-edicion-2', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(68, 37, 1, 0, 1, 0, 'Edicion', '2011-03-07 21:40:08', '2011-03-07 21:40:08', 'new-edicion-2', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(69, 38, 1, 1, 1, 1, 'Edicion', '2011-03-07 21:42:59', '2011-03-07 21:42:59', 'new-edicion-2', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(70, 39, 1, 1, 1, 1, 'Edicion', '2011-03-08 14:21:12', '2011-03-08 14:21:12', 'new-edicion-3', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(71, 39, 2, 0, 1, 0, 'Edicion', '2011-03-08 14:21:12', '2011-03-08 14:21:32', 'diciembre-2009', 'Diciembre 2009', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(72, 40, 1, 1, 1, 1, 'Edicion', '2011-03-08 14:22:02', '2011-03-08 14:22:02', 'new-edicion-3', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(73, 40, 2, 0, 1, 0, 'Edicion', '2011-03-08 14:22:02', '2011-03-08 14:22:17', 'marzo-2010', 'Marzo 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(74, 41, 1, 1, 1, 1, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:22', 'new-edicion-3', 'NuevaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 30),
(75, 41, 2, 0, 1, 0, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:34', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 40),
(76, 41, 3, 0, 1, 0, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:34', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 40),
(77, 41, 4, 0, 1, 0, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:40', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(78, 41, 5, 0, 1, 0, 'Edicion', '2011-03-08 14:22:22', '2011-03-08 14:22:41', 'enero-2010', 'Enero 2010', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(79, 31, 3, 1, 1, 1, 'RevistasHolder', '2011-03-07 14:51:43', '2011-03-08 16:09:27', 'revistas', 'Revistas', NULL, NULL, 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(80, 31, 4, 1, 1, 1, 'RevistasHolder', '2011-03-07 14:51:43', '2011-03-08 16:29:31', 'revistas-revisadas', 'Revistas revisadas', 'Revistas', NULL, 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(81, 30, 6, 1, 1, 1, 'EdicionesHolder', '2011-03-07 14:50:32', '2011-03-08 16:30:12', 'ultima-edicion', 'Última edición', NULL, NULL, 'Última Edición', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(82, 31, 5, 1, 1, 1, 'RevistasHolder', '2011-03-07 14:51:43', '2011-03-08 18:21:17', 'revistas-revisadas', 'Revistas revisadas', 'Revistas', '<p>En esta sección veremos las revistas desde las cuales se obtiene la información que incorporamos en nuestras alertas.</p>', 'Revistas', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(83, 29, 4, 1, 1, 1, 'ArchivePage', '2011-03-07 14:50:32', '2011-03-08 19:35:13', 'archivo', 'Archivo', NULL, NULL, 'Archivo', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(84, 13, 2, 1, 1, 1, 'TutorialesHolder', '2011-03-04 19:36:54', '2011-03-10 16:10:38', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(85, 42, 1, 0, 1, 0, 'TutorialPage', '2011-03-10 16:12:42', '2011-03-10 16:12:42', 'new-tutorialpage', 'NuevaTutorialPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 13),
(86, 42, 2, 1, 1, 1, 'TutorialPage', '2011-03-10 16:12:42', '2011-03-10 17:38:46', 'primer-tutorial', 'Primer Tutorial', 'Otro Tutorial', NULL, 'Primer Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 13),
(87, 43, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 17:47:33', 'new-tutorialpart', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 42),
(88, 42, 3, 1, 1, 1, 'TutorialPage', '2011-03-10 16:12:42', '2011-03-10 17:48:13', 'riesgo-de-sesgo-de-estudios-clinicos-randomizados', 'Riesgo de Sesgo de Estudios Clínicos Randomizados', NULL, NULL, 'Primer Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 13),
(89, 43, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 17:48:32', 'new-tutorialpart', 'NuevaTutorialPart', 'Randomización', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 42),
(90, 43, 3, 1, 1, 1, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 17:49:07', 'randomizacion', 'Randomización', NULL, NULL, 'Randomización', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 42),
(91, 43, 4, 1, 1, 1, 'TutorialPart', '2011-03-10 17:47:33', '2011-03-10 17:49:57', 'randomizacion', 'Randomización', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin velit  nisi, aliquam vitae consectetur quis, ornare quis justo. Vestibulum  vehicula, quam vel accumsan vulputate, ipsum velit rhoncus mauris, eget  auctor leo sem a erat. Duis elit magna, hendrerit sit amet eleifend ut,  facilisis id turpis. In hac habitasse platea dictumst. Mauris tempor  adipiscing lorem ac placerat. Morbi quis libero tellus. Nullam eget  risus non velit pellentesque consequat ac eget neque. Donec a justo  aliquam libero hendrerit porttitor. Nulla facilisi. Donec odio dui,  fermentum id fringilla ac, rhoncus ut turpis. Phasellus dignissim,  libero tempus tincidunt luctus, felis eros auctor ante, hendrerit porta  ipsum leo a ante. Donec vehicula ornare sem, eget placerat nisi varius  nec. Suspendisse tristique laoreet sollicitudin. Morbi in sem quam.  Vestibulum pulvinar justo sem, at iaculis velit. Nulla mauris nibh,  rutrum quis pulvinar non, luctus vel lorem. Quisque ac interdum urna.  Mauris commodo lacus ut risus hendrerit mattis. Phasellus dapibus  euismod sodales.</p>\n<p>Cras imperdiet tellus vel turpis ullamcorper quis feugiat sapien  pretium. Praesent dapibus, dolor dictum pulvinar interdum, mi massa  faucibus metus, vel hendrerit sem tellus lacinia tellus. Sed tempus  gravida felis eget rutrum. Aliquam tempor dolor vitae libero condimentum  sed tincidunt velit semper. Nullam tempus lorem odio. Donec convallis  luctus ligula, id mattis nulla dictum ac. Proin neque arcu, imperdiet  nec eleifend quis, dignissim sit amet orci. Curabitur sit amet purus  nisl, ac mollis arcu. Fusce eget tortor tortor. Nunc neque ipsum,  hendrerit nec gravida sit amet, venenatis eget diam. Etiam a leo nisl.  Nam non fermentum purus. Suspendisse placerat elit vitae est tempor  dictum. Nunc eleifend volutpat fringilla. Proin nisi nisl, lacinia nec  lacinia consectetur, tincidunt ut leo. Vestibulum sollicitudin, eros nec  convallis venenatis, felis enim tristique erat, ac ornare nisi elit in  urna.</p>', 'Randomización', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 42),
(92, 44, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 17:50:09', '2011-03-10 17:50:09', 'new-tutorialpart', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 42),
(93, 44, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 17:50:09', '2011-03-10 17:52:14', 'ocultamiento', 'Ocultamiento', NULL, NULL, 'Ocultamiento', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 42),
(94, 45, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 17:52:46', '2011-03-10 17:52:46', 'new-tutorialpart', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 42),
(95, 45, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 17:52:46', '2011-03-10 17:52:54', 'ciego', 'Ciego', NULL, NULL, 'Ciego', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 42),
(96, 13, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-10 17:55:18', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(97, 13, 4, 1, 1, 1, 'TutorialesHolder', '2011-03-04 19:36:54', '2011-03-10 17:55:39', 'tutoriales', 'Tutoriales', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(98, 44, 3, 1, 1, 1, 'TutorialPart', '2011-03-10 17:50:09', '2011-03-10 18:28:03', 'ocultamiento', 'Ocultamiento', NULL, '<p>Hola soy un contenido</p>', 'Ocultamiento', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 42),
(99, 45, 3, 1, 1, 1, 'TutorialPart', '2011-03-10 17:52:46', '2011-03-10 18:28:19', 'ciego', 'Ciego', NULL, '<p>SDADASDA ASDASD  dasdsa adasd ds adsa elfa dfedaer asdlr edr advfgl</p>', 'Ciego', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 42),
(100, 46, 1, 0, 1, 0, 'TutorialPage', '2011-03-10 18:51:38', '2011-03-10 18:51:38', 'new-tutorialpage', 'NuevaTutorialPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 13),
(101, 46, 2, 1, 1, 1, 'TutorialPage', '2011-03-10 18:51:38', '2011-03-10 18:51:51', 'otro-tutorial', 'Otro Tutorial', NULL, NULL, 'Otro Tutorial', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 13),
(102, 47, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 18:51:57', '2011-03-10 18:51:57', 'new-tutorialpart', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 46),
(103, 48, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 18:52:05', '2011-03-10 18:52:05', 'new-tutorialpart-2', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 46),
(104, 49, 1, 0, 1, 0, 'TutorialPart', '2011-03-10 18:52:09', '2011-03-10 18:52:09', 'new-tutorialpart-3', 'NuevaTutorialPart', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 46),
(105, 47, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 18:51:57', '2011-03-10 18:52:17', 'inicio', 'Inicio', 'NuevaTutorialPart', NULL, 'Inicio', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 46),
(106, 47, 3, 1, 1, 1, 'TutorialPart', '2011-03-10 18:51:57', '2011-03-10 18:52:25', 'inicio', 'Inicio', NULL, NULL, 'Inicio', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 46),
(107, 48, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 18:52:05', '2011-03-10 18:52:34', 'medio', 'Medio', NULL, NULL, 'Medio', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 46),
(108, 49, 2, 1, 1, 1, 'TutorialPart', '2011-03-10 18:52:09', '2011-03-10 18:52:46', 'final', 'Final', NULL, NULL, 'Final', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 46),
(109, 18, 2, 1, 1, 1, 'Glosary', '2011-03-04 19:36:54', '2011-03-10 21:23:31', 'glosario', 'Glosario', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 15),
(110, 16, 3, 1, 1, 1, 'EnlacesPage', '2011-03-04 19:36:54', '2011-03-11 15:49:46', 'enlaces', 'Enlaces', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 15),
(111, 16, 4, 1, 1, 1, 'EnlacesPage', '2011-03-04 19:36:54', '2011-03-11 16:10:35', 'enlaces', 'Enlaces', NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luctus pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec vitae. Donec tempor bibendum elit ac pellentesque.', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 15),
(112, 16, 5, 1, 1, 1, 'EnlacesPage', '2011-03-04 19:36:54', '2011-03-11 17:56:07', 'enlaces', 'Enlaces', NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut luctus pulvinar gravida. Etiam luctus leo sed orci porta ultricies nec vitae. Donec tempor bibendum elit ac pellentesque.', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 15),
(113, 14, 2, 1, 1, 1, 'CursosHolder', '2011-03-04 19:36:54', '2011-03-11 18:20:27', 'cursos', 'Cursos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(114, 50, 1, 0, 1, 0, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:21:16', 'new-cursospage', 'NuevaCursosPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 14),
(115, 51, 1, 0, 1, 0, 'AlertPage', '2011-03-11 18:21:19', '2011-03-11 18:21:19', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 50),
(116, 52, 1, 0, 1, 0, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:21:40', 'new-cursospage-2', 'NuevaCursosPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 14),
(117, 50, 2, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:22:20', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', NULL, NULL, 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 14),
(118, 52, 2, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:23:03', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', NULL, NULL, 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 14),
(119, 52, 3, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:25:09', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', NULL, '<p><img class="left" src="assets/novedades50diplomadoweb2-500x355.jpg" width="500" height="355" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14),
(120, 50, 3, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:25:27', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `ParentID`) VALUES
(121, 50, 4, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:33:35', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14),
(122, 52, 4, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:33:43', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', NULL, '<p><img class="left" src="assets/novedades50diplomadoweb2-500x355.jpg" width="500" height="355" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14),
(123, 50, 5, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:16', '2011-03-11 18:40:13', 'diplomado-de-medicina-basada-en-evidencia', 'Diplomado de medicina basada en evidencia', 'Dip. de med. basada en evidencia', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de medicina basada en evidencia', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14),
(124, 52, 5, 1, 1, 1, 'CursosPage', '2011-03-11 18:21:40', '2011-03-11 18:41:00', 'diplomado-de-revisiones-sistematicas', 'Diplomado de revisiones sistemáticas', 'Dip. de rev. sist.', '<p><img class="left" src="assets/novedades50diplomadoweb2-500x355.jpg" width="500" height="355" alt="" title=""/></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis hendrerit  tortor et tortor auctor ac fringilla lorem iaculis. Pellentesque eu sem  ipsum, vel tempor justo. Integer viverra consequat est vel dapibus.  Quisque accumsan, ante sit amet congue rhoncus, sem augue pretium neque,  id dictum eros felis ut dui. Aenean in ante eros, at malesuada risus.  Vivamus vulputate commodo felis eu vehicula. Ut fringilla consequat  ante. Quisque porta mattis enim ac accumsan. Aliquam ultricies ligula  vel odio congue ac molestie ligula accumsan. Maecenas mattis nulla non  elit sagittis sed laoreet nunc condimentum. Vestibulum ut arcu a tortor  rutrum elementum quis vitae dui. Maecenas consectetur sem id orci  lacinia tempor. Nunc tristique nisl a nulla posuere in bibendum nunc  rhoncus. Praesent fermentum tristique justo, at condimentum neque  rhoncus non. Sed auctor ultricies tristique. Maecenas in est ac erat  condimentum cursus vel eu elit. Curabitur eget purus nibh, fermentum  tincidunt diam. Phasellus tempus sapien vel risus vulputate sed interdum  quam euismod. Morbi semper libero nec orci eleifend sagittis.</p>\n<p>Fusce turpis magna, tempus et volutpat in, adipiscing in ante. Sed ut  diam at ante pellentesque vehicula ac sed enim. Nam ut diam elit, eget  adipiscing enim. Vivamus et justo vel purus ultrices commodo. Vivamus  tincidunt tristique est vulputate viverra. Proin eget dui nec diam  faucibus semper. Proin at risus lacus, non volutpat purus. Curabitur  faucibus dolor et nisi ultricies sed porta erat gravida. Sed ac dolor  nec libero dictum scelerisque. Nullam congue, purus in molestie viverra,  eros dui egestas metus, et sagittis est ligula sit amet tellus. In  egestas vulputate dignissim. Aenean egestas vestibulum mollis. Etiam nec  dui ante. Vivamus ac tellus dui, vel condimentum augue. Donec  vestibulum auctor nulla, a varius nunc mattis a. Lorem ipsum dolor sit  amet, consectetur adipiscing elit. Nulla facilisi. Fusce hendrerit erat  id erat tincidunt semper. Fusce blandit, odio at commodo adipiscing,  nulla nibh tincidunt magna, a iaculis dui nibh non odio. Nunc fringilla,  odio in accumsan commodo, justo urna fermentum mauris, consequat  gravida ligula urna et lacus.</p>\n<p>In hac habitasse platea dictumst. Quisque facilisis quam at augue  faucibus bibendum. Aenean mollis, augue tempus bibendum eleifend, diam  justo congue mi, ac facilisis ligula erat et augue. Aliquam rutrum  euismod nisl vitae mollis. Aenean vitae libero tincidunt ante ultricies  euismod sit amet vitae enim. Nunc rhoncus consequat magna sit amet  commodo. In hac habitasse platea dictumst. Donec elit magna, pretium a  accumsan vel, fringilla vel ante. Nullam imperdiet purus fermentum dolor  rhoncus gravida. Sed a ante quis lacus tincidunt adipiscing sit amet  vel lacus. Quisque imperdiet semper tincidunt. Integer tincidunt feugiat  felis, sit amet ultrices nulla facilisis ut. Sed cursus tristique elit  nec volutpat. Pellentesque egestas nulla sit amet mi ornare ac sagittis  nisl sollicitudin. Aenean viverra diam quis metus hendrerit lacinia.  Fusce et dictum libero. Aenean in dapibus nisl. Duis ut metus odio, in  ullamcorper nisi. Nam tincidunt malesuada gravida. Nam lectus felis,  gravida a vulputate id, facilisis a magna.</p>\n<p>Vivamus gravida cursus erat ornare tincidunt. Vivamus bibendum odio  tellus, non consectetur elit. Ut accumsan, orci vitae euismod  ullamcorper, enim felis consequat lectus, vitae tempus ante lorem eget  odio. Praesent auctor scelerisque varius. Maecenas suscipit dignissim  ipsum eget interdum. Nunc vitae ornare augue. Praesent elementum, diam  id ornare cursus, diam velit ultricies mauris, sit amet aliquet dui erat  non nisl. Etiam accumsan sapien eu nisi tempor sed porttitor tellus  blandit. Morbi non ullamcorper sem. Duis pretium consectetur pretium.  Suspendisse iaculis purus id ante sodales quis elementum orci  scelerisque. Nam porta odio ut augue aliquet id auctor tellus dapibus.  Pellentesque tortor massa, aliquet feugiat vulputate non, sodales eu  dui. Ut dolor libero, convallis nec tincidunt luctus, pellentesque  consectetur ligula. Vivamus viverra interdum urna. Nunc nulla felis,  facilisis tempor faucibus facilisis, varius eget turpis. Vestibulum  dapibus nunc vitae mi iaculis id consectetur nibh luctus. Nam dictum  porta placerat.</p>', 'Diplomado de revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 14),
(125, 38, 2, 0, 1, 0, 'Edicion', '2011-03-07 21:42:59', '2011-03-11 21:09:45', 'new-edicion-2', 'Mayo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(126, 38, 3, 1, 1, 1, 'Edicion', '2011-03-07 21:42:59', '2011-03-11 21:09:52', 'new-edicion-2', 'Mayo 2011', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(127, 33, 4, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:12', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 38),
(128, 33, 5, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:13', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 38),
(129, 33, 6, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:27', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(130, 33, 7, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:37', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(131, 33, 8, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:37', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 9),
(132, 33, 9, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:45', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 38),
(133, 33, 10, 0, 1, 0, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:45', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 38),
(134, 33, 11, 1, 1, 1, 'Edicion', '2011-03-07 18:53:07', '2011-03-11 21:10:51', 'diciembre-2011', 'Diciembre 2011', NULL, NULL, 'Alertas de Diciembre 2010', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 30),
(135, 20, 3, 1, 1, 1, 'MemberPage', '2011-03-04 19:36:54', '2011-03-14 14:55:34', 'page-20', ' ', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19),
(136, 20, 4, 1, 1, 1, 'MemberHolder', '2011-03-04 19:36:54', '2011-03-14 15:06:01', 'page-20', ' ', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19),
(137, 20, 5, 1, 1, 1, 'MemberHolder', '2011-03-04 19:36:54', '2011-03-14 15:06:21', 'quienes-somos', ' Quienes somos', 'Quienes somos', NULL, ' Quienes somos', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19),
(138, 53, 1, 0, 1, 0, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 15:12:16', 'page-0', ' ', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 20),
(139, 53, 2, 1, 1, 1, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 15:37:06', 'gabriel-rada', 'Gabriel Rada', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 20),
(140, 53, 3, 1, 1, 1, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 16:16:05', 'gabriel-rada', 'Gabriel Rada', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 20),
(141, 53, 4, 1, 1, 1, 'MemberPage', '2011-03-14 15:12:16', '2011-03-14 16:16:38', 'gabriel-rada', 'Gabriel Rada', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 20),
(142, 20, 6, 1, 1, 1, 'MemberHolder', '2011-03-04 19:36:54', '2011-03-14 16:21:21', 'quienes-somos', ' Quienes somos', 'Quienes somos', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>', ' Quienes somos', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19),
(143, 19, 2, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-14 16:32:51', 'acerca-de', 'Acerca de', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(144, 19, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-14 16:33:06', 'acerca-de', 'Acerca de', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(145, 54, 1, 0, 1, 0, 'ResumenDeEvidencia', '2011-03-15 15:26:40', '2011-03-15 15:26:40', 'new-resumendeevidencia', 'NuevaResumenDeEvidencia', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 10),
(146, 54, 2, 1, 1, 1, 'ResumenDeEvidencia', '2011-03-15 15:26:40', '2011-03-15 15:26:53', 'eclipses', 'Eclipses', NULL, NULL, 'Eclipses', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 10),
(147, 55, 1, 0, 1, 0, 'AlertPage', '2011-03-15 15:26:57', '2011-03-15 15:26:57', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 54),
(148, 56, 1, 0, 1, 0, 'ResumenDeEvidencia', '2011-03-15 15:27:11', '2011-03-15 15:27:11', 'new-resumendeevidencia', 'NuevaResumenDeEvidencia', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 10),
(149, 56, 2, 1, 1, 1, 'ResumenDeEvidencia', '2011-03-15 15:27:11', '2011-03-15 15:27:54', 'resumenes-support', 'Resúmenes Support', NULL, NULL, 'Resúmenes Support', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 10),
(150, 57, 1, 0, 1, 0, 'AlertPage', '2011-03-15 15:27:59', '2011-03-15 15:27:59', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 10),
(151, 57, 2, 1, 1, 1, 'AlertPage', '2011-03-15 15:27:59', '2011-03-15 15:28:17', 'resumenes-sin-nombre', 'Resúmenes sin nombre', NULL, NULL, 'Resúmenes sin nombre', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 10),
(152, 58, 1, 1, 1, 1, 'ResumenDeEvidenciaEdicion', '2011-03-15 15:35:55', '2011-03-15 15:35:55', 'new-resumendeevidenciaedicion', 'NuevaResumenDeEvidenciaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 54),
(153, 59, 1, 1, 1, 1, 'ResumenDeEvidenciaEdicion', '2011-03-15 16:32:22', '2011-03-15 16:32:22', 'new-resumendeevidenciaedicion', 'NuevaResumenDeEvidenciaEdicion', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 54),
(154, 60, 1, 0, 1, 0, 'Eclipse', '2011-03-15 17:01:07', '2011-03-15 17:01:07', 'new-eclipse', 'NuevaEclipse', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 59),
(155, 61, 1, 0, 1, 0, 'Eclipse', '2011-03-15 17:01:13', '2011-03-15 17:01:13', 'new-eclipse-2', 'NuevaEclipse', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 59),
(156, 60, 2, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-15 17:23:45', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', 'NuevaEclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 59),
(157, 60, 3, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-15 17:25:09', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', 'NuevaEclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 59);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `ParentID`) VALUES
(158, 60, 4, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-15 17:25:17', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 59),
(159, 61, 2, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:13', '2011-03-15 17:29:22', 'vacunacion-con-virus-vivo-atenuado-seria-mas-efectiva-que-virus-inactivado-en-prevencion-de-influenza-en-ninos', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', 'NuevaEclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>En niños sin un episodio reciente          de enfermedad obstructiva o asma severa, </strong><strong>¿</strong><strong>es          la vacunación con virus vivo atenuado,            más efectiva que la vacunación con          virus inactivo, en prevenir la influenza?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Live attenuated versus inactivated influenza vaccine in infants and young          children. Belshe RB, Edwards KM, Vesikari T, Black SV, Walker RE, Hultquist          M, Kemble G, Connor EM; CAIV-T Comparative Efficacy Study Group. N Engl          J Med. 2007 Feb 15;356(7):685-96.<br/><a href="http://content.nejm.org/cgi/content/abstract/356/7/685" target="_blank">VER          ARTÍCULO EN SITIO ORIGINAL</a></p>\n<p><strong>Contexto:<br/></strong>La mejor manera de prevenir la influenza y sus complicaciones          es la vacunación. Diversos estudios controlados han demostrado          que la vacuna antiinfluenza es capaz de evitar episodios graves, hospitalización          y significativos costos económicos (1). En Chile desde el año          2006 se vacuna todos los años a los niños entre 6 y 23 meses          de edad (1). Las vacunas antiinfluenza disponibles actualmente en el mundo          contienen virus inactivado (de uso parenteral), virus vivo atenuado (de          uso nasal) o virosomas (de uso parenteral). La vacuna que contiene virus          vivo atenuado de uso nasal se cree que podría estimular una mayor          respuesta sistémica antigénica (2). En nuestro medio, se          encuentran disponibles vacunas inactivadas y virosomales, ambas de uso          parenteral. <strong><br/><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Estudio          clínico randomizado, realizado en 249 centros de atención          primaria, distribuidos en 16 países. Seguimiento a 219 días.</p>\n<table style="width: 90%; height: 227px;" border="2" align="center"><tbody><tr><td width="36%" height="219" valign="top">\n<p><strong>Los pacientes:</strong><br/> Niños entre 6 y 59 meses, con o sin vacunación previa                contra la influenza. Se excluyeron aquellos que presentaran episodios                de enfermedad respiratoria obstructiva o asma severas en los 42                días previos, hipersensibilidad a algún componente                de las vacunas, uso de aspirinas o salicilatos en los 30 días                previos, inmunosupresión, o fiebre &gt; 37,8ºC en los                3 días previos.</p>\n</td>\n<td width="32%" height="219" valign="top">\n<p><strong>Intervención<br/></strong><strong>n=3916</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días                28 y 42) de vacuna intranasal de virus vivo atenuado, más                placebo (inyección intramuscular de suero fisiológico).<br/><br/> CVP: Una dosis en día 0 de vacuna intranasal de virus vivo                atenuado, más placebo (inyección intramuscular de                suero fisiológico).</p>\n</td>\n<td width="32%" height="219" valign="top"><strong>Comparación<br/></strong> <strong>n=3936</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días 28              y 42) de vacuna intramuscular de virus inactivado, más placebo              (spray intranasal de suero fisiológico)\n<p>CVP: Una dosis en día 0 de vacuna intramuscular de virus                inactivado, más placebo (spray intranasal de suero fisiológico).</p>\n</td>\n</tr></tbody></table><p>SVP: sin vacunación previa , CVP: con vacunación        previa</p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 119px;" border="2" align="center"><tbody><tr><td width="50%" height="111" valign="top">\n<p>1- <strong>Randomizado.</strong> SI<br/><strong>    Secuencia de randomización                oculta. </strong>SI<br/> 2-<strong> Seguimiento. </strong>92,6%<br/> 3- <strong>Intención de tratar</strong>. NO<br/> 4- <strong>Grupos similares respecto a variables pronósticas                conocidas</strong>. SI <br/> 5- <strong>Interrumpido precozmente por beneficio.</strong> NO</p>\n</td>\n<td width="50%" height="111" valign="top">\n<p>6-<strong> Pacientes                ciegos a la intervención. </strong>SI<br/><strong>      Tratantes ciegos                a la intervención. </strong> SI<br/><strong>      Recolectores ciegos                a la intervención. </strong>SI<br/><strong>     Adjudicadores ciegos                a la intervención. </strong>SI<br/>     <strong>Analistas ciegos a la                intervención. </strong>SI<strong><br/></strong></p>\n</td>\n</tr></tbody></table><div align="left"><br/><br/><strong>Resultados: <br/></strong><br/><table style="width: 762px; height: 307px;" border="2" align="center"><tbody><tr><td width="210">\n<div align="center"><strong>Outcome<br/></strong></div>\n</td>\n<td width="168">\n<div align="center"><strong>Tasa de eventos en grupo                  virus atenuado</strong></div>\n</td>\n<td width="157">\n<div align="center"><strong>Tasa de eventos en grupo                  virus inactivado</strong></div>\n</td>\n<td width="100">\n<div align="center"><strong>RRR<br/> (95% IC)</strong></div>\n</td>\n<td width="91">\n<div align="center"><strong>NNT<br/> (95% IC) </strong></div>\n</td>\n</tr><tr><td height="57">\n<div align="left"><strong>Influenza (total)*</strong></div>\n</td>\n<td>\n<div align="center">3,9%</div>\n</td>\n<td>\n<div align="center">8,6%</div>\n</td>\n<td>\n<div align="center">55%<br/> (42 a 67)</div>\n</td>\n<td>\n<div align="center">21<br/> (17 a 28)</div>\n</td>\n</tr><tr><td height="49">\n<div align="left"><strong>Influenza A</strong></div>\n</td>\n<td>\n<div align="center">1%</div>\n</td>\n<td>\n<div align="center">5,2%</div>\n</td>\n<td>\n<div align="center">81%<br/> (66 a 95)</div>\n</td>\n<td>\n<div align="center">24 <br/> (20 a 29)</div>\n</td>\n</tr><tr><td height="49"><strong>Influenza B<br/></strong></td>\n<td>\n<div align="center">2,9%</div>\n</td>\n<td>\n<div align="center">3,5%</div>\n</td>\n<td>\n<div align="center">17%<br/> (-5 a 39)</div>\n</td>\n<td>\n<div align="center">168<br/> (73 a inf)</div>\n</td>\n</tr><tr><td height="50">\n<p><strong>Influenza total subgrupo SVP</strong></p>\n</td>\n<td>\n<div align="center">1,2%</div>\n</td>\n<td>\n<div align="center">2,1%</div>\n</td>\n<td>\n<div align="center">43%<br/> (12 a 74)</div>\n</td>\n<td>\n<div align="center">111<br/> (65 a 393)</div>\n</td>\n</tr><tr><td><strong>Influenza total subgrupo CVP</strong></td>\n<td>\n<div align="center">1,9%</div>\n</td>\n<td>\n<div align="center">3,1%</div>\n</td>\n<td>\n<div align="center">39<br/> (-7 a 84)</div>\n</td>\n<td>\n<div align="center">83<br/> (38 a inf)</div>\n</td>\n</tr></tbody></table></div>\n<div align="left">\n<p>RRR= Reducción            del riesgo relativo (RR), NNT= Número necesario para tratar,            IC= Intervalo de confianza, inf=infinito<br/> * Outcome influenza (total) se constató de acuerdo a clínica            sugerente más cultivos confirmatorios. Se realizó un promedio            de 2,4 cultivos por niño durante el seguimiento. <br/><br/><strong><br/></strong> <strong>Comentarios y aplicación práctica:            <br/></strong><em>• Comentarios acerca de la validez (riesgo de sesgo): </em><br/> - En cuanto a su validez, este estudio tiene una metodología            adecuada, sin embargo sus falencias radican en que no son rigurosos            respecto al porcentaje de seguimiento, ni a la intención de tratar.            No explicitan por qué de 8475 pacientes enrolados, se incluyeron            solamente a 8352, y finalmente sólo con 7852 pacientes se obtuvieron            los resultados. Claramente no hay intención de tratar, pues los            pacientes que abandonaron el tratamiento se excluyeron del denominador.            Respecto al seguimiento, siendo rigurosos, este seria de un 92,6%, pues            hay que considerarlo respecto a los pacientes inicialmente enrolados            en el estudio. <br/><em><br/></em> <em>• Comentarios acerca de los resultados: </em><br/> - El estudio demuestra que la intervención con vacuna de virus            atenuado intranasal, es más efectiva que la vacuna con virus            inactivado. Globalmente, incluyendo aquellos casos de Influenza A y            B, previamente vacunados o no, y sin estratificar por edad, el efecto            final apoya el uso de ésta.<em> </em>El número de pacientes            evaluados es adecuado, por lo que los resultados principales son muy            precisos.<em><br/></em>- Al analizar por separado su efecto sobre las diferentes cepas            de Influenza, se registra beneficio significativo de la vacuna intranasal            con virus vivo atenuado para la influenza A, sin embargo, no se demuestra            beneficio significativo para la prevención de la influenza B.<em> <br/></em>- Estratificando los resultados según presencia o ausencia            de vacunación previa, estos muestran que no habría beneficio            significativo para quienes hayan sido vacunados en los 42 días            previos. En cambio, sí se observa efecto significativo para aquellos            que no habían recibido vacunación en los 42 días            previos al estudio.</p>\n<p><em>• Aplicabilidad: </em><br/> - En cuanto a su aplicabilidad, dada la simplicidad de la intervención            y la amplitud de inclusión, estos resultados podrían ser            perfectamente aplicables a nuestro escenario. Además la inyección            intranasal resulta un procedimiento mejor tolerado por los niños            y que no necesita mayor entrenamiento de parte del personal de la salud.            Sin embargo, esta vacuna no está disponible actualmente en Chile,            por lo cual su aplicación inmediata es imposible. Como evaluación            para su aplicación futura, sería importante indagar en            la diferencia de costos entre una y otra, que podría ser otra            limitante en su aplicabilidad. <br/> - También se compararon respecto a sus efectos adversos, donde            fueron equivalentes, excepto en el segmento etario entre 6 y 11 meses,            donde la vacuna intranasal de virus vivo atenuado registró mayor            tasa de eventos adversos (en tasas de 6,4 versus 3,4 de efectos adversos            serios, y 6,1 versus 2,6 de hospitalizaciones por cualquier causa. Ninguno            de los dos grupos registró muertes relacionadas con el tratamiento).            Por lo tanto, una evaluación mas detallada de sus riesgos versus            sus beneficios, indican que su mayor indicación estaría            para el grupo entre 12 y 59 meses.</p>\n<p>- En resumen, este es un estudio con un riesgo de sesgo moderado, que            muestra un beneficio de importante magnitud sobre un outcome de gran            relevancia clínica.</p>\n</div>\n<p><strong> Información adicional:</strong></p>\n<p><strong>Referencias:</strong></p>\n<ol><li>Luis E. Vega-Briceño, Katia Abarca V. e Ignacio Sánchez            D. Flu vaccine in children: State of the art.Rev Chil Infect, 2006;            23 (2): 164, Santiago jun. 2006</li>\n<li> Harper S A, Fukuda K, Uyeki T M, Cox N J, Bridges C B; Centers for            Disease Control and Prevention (CDC). Advisory Committee on Immunization            Practices (ACIP). Prevention and control of influenza: Recommendations            of ACIP. MMWR Morbid Mortal Wkly Rep 2004; 53 (RR-6): 1-40, California            April 2006.</li>\n</ol>', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 59),
(160, 61, 3, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:13', '2011-03-15 17:29:28', 'vacunacion-con-virus-vivo-atenuado-seria-mas-efectiva-que-virus-inactivado-en-prevencion-de-influenza-en-ninos', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>En niños sin un episodio reciente          de enfermedad obstructiva o asma severa, </strong><strong>¿</strong><strong>es          la vacunación con virus vivo atenuado,            más efectiva que la vacunación con          virus inactivo, en prevenir la influenza?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Live attenuated versus inactivated influenza vaccine in infants and young          children. Belshe RB, Edwards KM, Vesikari T, Black SV, Walker RE, Hultquist          M, Kemble G, Connor EM; CAIV-T Comparative Efficacy Study Group. N Engl          J Med. 2007 Feb 15;356(7):685-96.<br/><a href="http://content.nejm.org/cgi/content/abstract/356/7/685" target="_blank">VER          ARTÍCULO EN SITIO ORIGINAL</a></p>\n<p><strong>Contexto:<br/></strong>La mejor manera de prevenir la influenza y sus complicaciones          es la vacunación. Diversos estudios controlados han demostrado          que la vacuna antiinfluenza es capaz de evitar episodios graves, hospitalización          y significativos costos económicos (1). En Chile desde el año          2006 se vacuna todos los años a los niños entre 6 y 23 meses          de edad (1). Las vacunas antiinfluenza disponibles actualmente en el mundo          contienen virus inactivado (de uso parenteral), virus vivo atenuado (de          uso nasal) o virosomas (de uso parenteral). La vacuna que contiene virus          vivo atenuado de uso nasal se cree que podría estimular una mayor          respuesta sistémica antigénica (2). En nuestro medio, se          encuentran disponibles vacunas inactivadas y virosomales, ambas de uso          parenteral. <strong><br/><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Estudio          clínico randomizado, realizado en 249 centros de atención          primaria, distribuidos en 16 países. Seguimiento a 219 días.</p>\n<table style="width: 90%; height: 227px;" border="2" align="center"><tbody><tr><td width="36%" height="219" valign="top">\n<p><strong>Los pacientes:</strong><br/> Niños entre 6 y 59 meses, con o sin vacunación previa                contra la influenza. Se excluyeron aquellos que presentaran episodios                de enfermedad respiratoria obstructiva o asma severas en los 42                días previos, hipersensibilidad a algún componente                de las vacunas, uso de aspirinas o salicilatos en los 30 días                previos, inmunosupresión, o fiebre &gt; 37,8ºC en los                3 días previos.</p>\n</td>\n<td width="32%" height="219" valign="top">\n<p><strong>Intervención<br/></strong><strong>n=3916</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días                28 y 42) de vacuna intranasal de virus vivo atenuado, más                placebo (inyección intramuscular de suero fisiológico).<br/><br/> CVP: Una dosis en día 0 de vacuna intranasal de virus vivo                atenuado, más placebo (inyección intramuscular de                suero fisiológico).</p>\n</td>\n<td width="32%" height="219" valign="top"><strong>Comparación<br/></strong> <strong>n=3936</strong><br/><br/> SVP: Dos dosis (1era en día 0, 2da entre los días 28              y 42) de vacuna intramuscular de virus inactivado, más placebo              (spray intranasal de suero fisiológico)\n<p>CVP: Una dosis en día 0 de vacuna intramuscular de virus                inactivado, más placebo (spray intranasal de suero fisiológico).</p>\n</td>\n</tr></tbody></table><p>SVP: sin vacunación previa , CVP: con vacunación        previa</p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 119px;" border="2" align="center"><tbody><tr><td width="50%" height="111" valign="top">\n<p>1- <strong>Randomizado.</strong> SI<br/><strong>    Secuencia de randomización                oculta. </strong>SI<br/> 2-<strong> Seguimiento. </strong>92,6%<br/> 3- <strong>Intención de tratar</strong>. NO<br/> 4- <strong>Grupos similares respecto a variables pronósticas                conocidas</strong>. SI <br/> 5- <strong>Interrumpido precozmente por beneficio.</strong> NO</p>\n</td>\n<td width="50%" height="111" valign="top">\n<p>6-<strong> Pacientes                ciegos a la intervención. </strong>SI<br/><strong>      Tratantes ciegos                a la intervención. </strong> SI<br/><strong>      Recolectores ciegos                a la intervención. </strong>SI<br/><strong>     Adjudicadores ciegos                a la intervención. </strong>SI<br/>     <strong>Analistas ciegos a la                intervención. </strong>SI<strong><br/></strong></p>\n</td>\n</tr></tbody></table><div align="left"><br/><br/><strong>Resultados: <br/></strong><br/><table style="width: 762px; height: 307px;" border="2" align="center"><tbody><tr><td width="210">\n<div align="center"><strong>Outcome<br/></strong></div>\n</td>\n<td width="168">\n<div align="center"><strong>Tasa de eventos en grupo                  virus atenuado</strong></div>\n</td>\n<td width="157">\n<div align="center"><strong>Tasa de eventos en grupo                  virus inactivado</strong></div>\n</td>\n<td width="100">\n<div align="center"><strong>RRR<br/> (95% IC)</strong></div>\n</td>\n<td width="91">\n<div align="center"><strong>NNT<br/> (95% IC) </strong></div>\n</td>\n</tr><tr><td height="57">\n<div align="left"><strong>Influenza (total)*</strong></div>\n</td>\n<td>\n<div align="center">3,9%</div>\n</td>\n<td>\n<div align="center">8,6%</div>\n</td>\n<td>\n<div align="center">55%<br/> (42 a 67)</div>\n</td>\n<td>\n<div align="center">21<br/> (17 a 28)</div>\n</td>\n</tr><tr><td height="49">\n<div align="left"><strong>Influenza A</strong></div>\n</td>\n<td>\n<div align="center">1%</div>\n</td>\n<td>\n<div align="center">5,2%</div>\n</td>\n<td>\n<div align="center">81%<br/> (66 a 95)</div>\n</td>\n<td>\n<div align="center">24 <br/> (20 a 29)</div>\n</td>\n</tr><tr><td height="49"><strong>Influenza B<br/></strong></td>\n<td>\n<div align="center">2,9%</div>\n</td>\n<td>\n<div align="center">3,5%</div>\n</td>\n<td>\n<div align="center">17%<br/> (-5 a 39)</div>\n</td>\n<td>\n<div align="center">168<br/> (73 a inf)</div>\n</td>\n</tr><tr><td height="50">\n<p><strong>Influenza total subgrupo SVP</strong></p>\n</td>\n<td>\n<div align="center">1,2%</div>\n</td>\n<td>\n<div align="center">2,1%</div>\n</td>\n<td>\n<div align="center">43%<br/> (12 a 74)</div>\n</td>\n<td>\n<div align="center">111<br/> (65 a 393)</div>\n</td>\n</tr><tr><td><strong>Influenza total subgrupo CVP</strong></td>\n<td>\n<div align="center">1,9%</div>\n</td>\n<td>\n<div align="center">3,1%</div>\n</td>\n<td>\n<div align="center">39<br/> (-7 a 84)</div>\n</td>\n<td>\n<div align="center">83<br/> (38 a inf)</div>\n</td>\n</tr></tbody></table></div>\n<div align="left">\n<p>RRR= Reducción            del riesgo relativo (RR), NNT= Número necesario para tratar,            IC= Intervalo de confianza, inf=infinito<br/> * Outcome influenza (total) se constató de acuerdo a clínica            sugerente más cultivos confirmatorios. Se realizó un promedio            de 2,4 cultivos por niño durante el seguimiento. <br/><br/><strong><br/></strong> <strong>Comentarios y aplicación práctica:            <br/></strong><em>• Comentarios acerca de la validez (riesgo de sesgo): </em><br/> - En cuanto a su validez, este estudio tiene una metodología            adecuada, sin embargo sus falencias radican en que no son rigurosos            respecto al porcentaje de seguimiento, ni a la intención de tratar.            No explicitan por qué de 8475 pacientes enrolados, se incluyeron            solamente a 8352, y finalmente sólo con 7852 pacientes se obtuvieron            los resultados. Claramente no hay intención de tratar, pues los            pacientes que abandonaron el tratamiento se excluyeron del denominador.            Respecto al seguimiento, siendo rigurosos, este seria de un 92,6%, pues            hay que considerarlo respecto a los pacientes inicialmente enrolados            en el estudio. <br/><em><br/></em> <em>• Comentarios acerca de los resultados: </em><br/> - El estudio demuestra que la intervención con vacuna de virus            atenuado intranasal, es más efectiva que la vacuna con virus            inactivado. Globalmente, incluyendo aquellos casos de Influenza A y            B, previamente vacunados o no, y sin estratificar por edad, el efecto            final apoya el uso de ésta.<em> </em>El número de pacientes            evaluados es adecuado, por lo que los resultados principales son muy            precisos.<em><br/></em>- Al analizar por separado su efecto sobre las diferentes cepas            de Influenza, se registra beneficio significativo de la vacuna intranasal            con virus vivo atenuado para la influenza A, sin embargo, no se demuestra            beneficio significativo para la prevención de la influenza B.<em> <br/></em>- Estratificando los resultados según presencia o ausencia            de vacunación previa, estos muestran que no habría beneficio            significativo para quienes hayan sido vacunados en los 42 días            previos. En cambio, sí se observa efecto significativo para aquellos            que no habían recibido vacunación en los 42 días            previos al estudio.</p>\n<p><em>• Aplicabilidad: </em><br/> - En cuanto a su aplicabilidad, dada la simplicidad de la intervención            y la amplitud de inclusión, estos resultados podrían ser            perfectamente aplicables a nuestro escenario. Además la inyección            intranasal resulta un procedimiento mejor tolerado por los niños            y que no necesita mayor entrenamiento de parte del personal de la salud.            Sin embargo, esta vacuna no está disponible actualmente en Chile,            por lo cual su aplicación inmediata es imposible. Como evaluación            para su aplicación futura, sería importante indagar en            la diferencia de costos entre una y otra, que podría ser otra            limitante en su aplicabilidad. <br/> - También se compararon respecto a sus efectos adversos, donde            fueron equivalentes, excepto en el segmento etario entre 6 y 11 meses,            donde la vacuna intranasal de virus vivo atenuado registró mayor            tasa de eventos adversos (en tasas de 6,4 versus 3,4 de efectos adversos            serios, y 6,1 versus 2,6 de hospitalizaciones por cualquier causa. Ninguno            de los dos grupos registró muertes relacionadas con el tratamiento).            Por lo tanto, una evaluación mas detallada de sus riesgos versus            sus beneficios, indican que su mayor indicación estaría            para el grupo entre 12 y 59 meses.</p>\n<p>- En resumen, este es un estudio con un riesgo de sesgo moderado, que            muestra un beneficio de importante magnitud sobre un outcome de gran            relevancia clínica.</p>\n</div>\n<p><strong> Información adicional:</strong></p>\n<p><strong>Referencias:</strong></p>\n<ol><li>Luis E. Vega-Briceño, Katia Abarca V. e Ignacio Sánchez            D. Flu vaccine in children: State of the art.Rev Chil Infect, 2006;            23 (2): 164, Santiago jun. 2006</li>\n<li> Harper S A, Fukuda K, Uyeki T M, Cox N J, Bridges C B; Centers for            Disease Control and Prevention (CDC). Advisory Committee on Immunization            Practices (ACIP). Prevention and control of influenza: Recommendations            of ACIP. MMWR Morbid Mortal Wkly Rep 2004; 53 (RR-6): 1-40, California            April 2006.</li>\n</ol>', 'Vacunación con virus vivo atenuado sería más efectiva que virus inactivado en prevención de influenza en niños', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 59),
(161, 10, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-15 19:14:23', 'resumenes-de-evidencia', 'Resúmenes de evidencia', 'Resúmenes', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(162, 10, 4, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:53', '2011-03-15 19:14:44', 'resumenes-de-evidencia', 'Resúmenes de evidencia', 'Resúmenes', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(163, 54, 3, 1, 1, 1, 'ResumenDeEvidencia', '2011-03-15 15:26:40', '2011-03-15 21:42:35', 'eclipses', 'Eclipses', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse  vehicula tincidunt erat, eget imperdiet odio euismod nec. Nunc luctus mi  et nisi tincidunt condimentum sed non magna. Nulla eu lacus massa, eu  tincidunt purus. Ut cursus ipsum dolor, at varius lorem. Mauris mauris  arcu, pretium et aliquet eget, posuere egestas sapien. Quisque ut lacus  et leo hendrerit pharetra. Fusce posuere, turpis a pharetra sodales,  nisl diam condimentum elit, vitae egestas lectus nulla in augue. Cras  posuere metus ut est rhoncus sodales. Nam placerat nibh sed libero  semper vestibulum. Ut mauris dui, tristique vel semper non, ultrices ac  urna. Phasellus mattis varius odio eu tincidunt. Maecenas sagittis  turpis sed magna vulputate id rhoncus nisl hendrerit.</p>\n<p>Suspendisse quis tristique neque. Aliquam erat volutpat. Vestibulum  volutpat accumsan turpis, eget lacinia justo tempus in. In luctus turpis  velit, auctor dapibus leo. Sed nisl elit, tempus sed luctus nec, varius  sed urna. Sed blandit suscipit lorem, quis euismod quam ornare mollis.  Donec volutpat, dui vitae pretium porta, nibh augue iaculis risus, non  imperdiet velit sem eget ante. Suspendisse adipiscing, lorem suscipit  tempor malesuada, nibh felis malesuada tellus, nec porta urna eros ut  dolor. Quisque arcu est, molestie sed adipiscing nec, placerat vitae  massa. Praesent eu erat dui. Praesent congue pulvinar lacus, eu interdum  augue laoreet semper. Vestibulum ante ipsum primis in faucibus orci  luctus et ultrices posuere cubilia Curae; Aliquam erat volutpat. Aenean  in turpis orci, eu gravida orci. Nulla pharetra, augue non molestie  sollicitudin, neque quam luctus lectus, in facilisis purus lacus eu  felis. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Suspendisse potenti. Cras neque tellus, sagittis  sed malesuada quis, auctor quis sapien.</p>\n<p>Morbi nec orci sem. Nulla a diam eget dui adipiscing fringilla eu rutrum  lacus. Fusce rutrum placerat massa, eget vehicula nunc feugiat sit  amet. Curabitur a nisl nibh. Etiam at mauris quis nibh dignissim  molestie. Sed convallis lorem ipsum, a lobortis nulla. Morbi ipsum  magna, tempor sed sodales quis, elementum eget lorem. Nunc quam ante,  pharetra sed scelerisque ac, porta vel velit. Ut felis ante, laoreet  quis fermentum eu, tincidunt quis lacus. Fusce tristique ante quis  sapien feugiat sit amet vulputate tellus dictum. Donec commodo venenatis  diam, ac mollis ante faucibus in. Aenean ante nulla, dictum vitae  ultrices eu, sagittis sit amet enim. Etiam a quam quis libero fringilla  ultricies.</p>', 'Eclipses', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 10),
(164, 56, 3, 1, 1, 1, 'ResumenDeEvidenciaMulti', '2011-03-15 15:27:11', '2011-03-16 15:32:15', 'resumenes-support', 'Resúmenes Support', NULL, NULL, 'Resúmenes Support', NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 10),
(165, 62, 1, 1, 1, 1, 'ResumenDeEvidenciaEdicionMulti', '2011-03-16 15:37:20', '2011-03-16 15:37:20', 'new-resumendeevidenciaedicionmulti', 'NuevaResumenDeEvidenciaEdicionMulti', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 56),
(166, 63, 1, 0, 1, 0, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 15:38:17', 'new-eclipsemulti', 'NuevaEclipseMulti', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 62),
(167, 63, 2, 1, 1, 1, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 15:44:18', 'adsd', 'Adsd', 'Zzxc', NULL, 'Adsd', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 62),
(168, 63, 3, 1, 1, 1, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 15:44:36', 'hola-soy-un-eclipse', 'Hola soy un eclipse', 'Yo tambien', NULL, 'Adsd', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 62),
(169, 63, 4, 1, 1, 1, 'EclipseMulti', '2011-03-16 15:38:17', '2011-03-16 16:18:57', 'hola-soy-un-eclipse-en-espanol', 'Hola soy un eclipse en español', 'Hola soy un eclipse', '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al.  Bisphosphonates in multiple myeloma.  Chochrane database of systematic  reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos   randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma   múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos:  MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000),  LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda  manual  se realizó en los abstracts de congreso de las siguientes  sociedades  (1993 al 2000): ASH (american society of hematology), ASCO  (amercian  society for clinical oncology), EHA (european hematology  asociation).  Además se contactó con compañías farmacéuticas que  producen bifosfonatos  y con investigadores alrededor del mundo en USA,  Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se  revisaron las referencias de  los artículos incluidos, y se contactó a  los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó  123 estudios, de los cuales 11  cumplieron con los criterios de  inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de  médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los  estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que  responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples  bases de datos, múltiples idiomas, realizan búsqueda manual en   abstracts de congresos y contacto con compañías farmacéuticas y   expertos, en términos de reproducibilidad de la selección de los   estudios, al menos 2 revisores realizaron esa función y resolvieron las   discrepancias por consenso, y finalmente se evalúo la calidad   metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia   estadística en un outcome como mortalidad, sin embargo, sí se observa   beneficio significativo en la disminución de fracturas vertebrales y en   dolor. Estos outcomes son relevantes, ya que son motivo de consulta,   hospitalización y costos asociados a la patología, los que pueden ser   prevenidos por una intervención fácil, y eventualmente de un costo menor   al relacionado al manejo de las complicaciones antes mencionadas.<br/> -  El metaanálisis mostró una mayor tasa de eventos adversos pero  que no  alcanzó la significancia estadística, en el grupo intervención  (RR 1,28  con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser  individualizado, no parece ser un argumento para no usarlos, aunque  es  cierto que sólo  se habla de síntomas gastrointestinales, muy  variados.  <br/> -          Es importante destacar que respecto a la reducción del  dolor, no  queda claro el método de evaluación que usaron los  respectivos autores  de los diversos ECRs incluidos en este metanálisis,  por lo tanto, siendo  el dolor una variable subjetiva por excelencia  que se intenta objetivar  arbitrariamente, deben interpretarse los  resultados con cautela.<br/> - Los resultados comentados provienen de  ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a  tratamiento con  bifosfonato. Hubiese sido interesante hacer un  análisis de subgrupos  según etapa clínica, ya que parece interesante la  idea de que los  efectos que mostró el bifosfonato sean mayores en  etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a  la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de  bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en  nuestro país es el alendronato, droga no incluida en  ésta revisión,  pero dado el mecanismo de acción común, el clínico podría  extrapolar  éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos  estrictos con los hallazgos de la  revisión, los bifosfonatos que  demostraron claro beneficio fueron  pamidronato y clodronato, por lo  tanto deberían ser los únicos  utilizados para lograr los beneficios que  hemos comentado en nuestros  pacientes con mieloma múltiple.           Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que  debe ser considerado si se piensa utilizar alguno de ellos en  beneficio  de nuestros pacientes. En este sentido si aplicamos el mismo   fundamento de acción común esperaremos resultados similares.<br/> - El  número necesario a tratar (NNT) con esta droga es  prometedor para  nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el  uso de estas drogas en otras patologías que cursan con  complicaciones  similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias  que con frecuencias se complican con compromiso óseo,  dolor y fracturas  en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de  sumar a la terapia estándar, logrando disminuir motivos de  consulta  frecuentes como son las fracturas de hueso patológico o el  dolor. Aun  cuando el bifosfonato más disponible en Chile no se encuentra  en la  revisión nos parece adecuado extrapolar los beneficios  demostrados y  por lo tanto indicarlo en pacientes con mieloma múltiple.  En este  sentido si el paciente tuviera una preferencia por otro  bifosfonato,  como puede ser uno con vía de administración distinta,  podrían evaluar  en conjunto el clínico junto con el paciente, los costos  y beneficios,  llegando a la  decisión final.</p>', 'Adsd', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 62),
(170, 12, 3, 1, 1, 1, 'ProyectosUmbe', '2011-03-04 19:36:54', '2011-03-16 20:08:22', 'proyectos-umbeuc', 'Proyectos UmbeUC', 'Proyectos', NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(171, 21, 2, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-16 20:45:31', 'que-hacemos', 'Qué Hacemos', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19),
(172, 21, 3, 1, 1, 1, 'Page', '2011-03-04 19:36:54', '2011-03-16 20:45:43', 'que-hacemos', 'Qué Hacemos', NULL, '<p>Lorem Ipsum</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 19);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `ParentID`) VALUES
(173, 60, 5, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:35:13', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(174, 60, 6, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:36:21', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 59),
(175, 60, 7, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:36:58', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(176, 60, 8, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:37:04', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(177, 60, 9, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:38:45', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaTitle`, `MetaDescription`, `MetaKeywords`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `HomepageForDomain`, `ProvideComments`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `Status`, `ReportClass`, `CanViewType`, `CanEditType`, `ToDo`, `ParentID`) VALUES
(178, 60, 10, 1, 1, 1, 'Eclipse', '2011-03-15 17:01:07', '2011-03-16 21:40:08', 'los-bifosfonatos-en-pacientes-con-mieloma-multiple-podrian-reducir-el-dolor-y-el-riesgo-de-fracturas-vertebrales', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, '<p align="center"><strong>Pregunta          clínica de 4 partes:</strong> <strong>P</strong><strong>aciente</strong>-<strong>Intervención</strong>-<strong>Comparación</strong><strong>-O</strong><strong>utcome</strong>.<br/><strong>¿En pacientes con mieloma múltiple, </strong><strong>el uso de bifosfonatos comparado con placebo o tratamiento estándar, </strong><strong>¿reduce el riesgo de fracturas y el dolor?</strong></p>\n<p align="left"><strong>Artículo:</strong> <br/> Djulbegovic B et al. Bisphosphonates in multiple myeloma.  Chochrane database of systematic reviews 2002, sigue 4. Art. No.:  CD003188.<br/><a href="http://dx.doi.org/10.1002/14651858.CD003188">VER          ABSTRACT DEL ARTÍCULO EN SITIO ORIGINAL</a><br/><strong><br/></strong> <strong>Características del estudio:<br/> Tipo de estudio</strong><strong>:</strong> Revisión sistemática (RS) con metaanálisis de estudios clínicos  randomizados (ECR) del uso de bifosfonatos en pacientes con mieloma  múltiple. <br/> La búsqueda se realizó en las siguientes bases de datos: MEDLINE  (1966 a junio de 2001), EMBASE (1974 a Diciembre del 2000), LILACS  (1982 a junio de 2001), CENTRAL (hasta marzo 2001). La búsqueda manual  se realizó en los abstracts de congreso de las siguientes sociedades  (1993 al 2000): ASH (american society of hematology), ASCO (amercian  society for clinical oncology), EHA (european hematology asociation).  Además se contactó con compañías farmacéuticas que producen bifosfonatos  y con investigadores alrededor del mundo en USA, Europa, Japón, Korea,  Grecia, Arabia Saudita y Brasil. También se revisaron las referencias de  los artículos incluidos, y se contactó a los autores de dichos  artículos. <br/> La búsqueda electrónica pesquisó 123 estudios, de los cuales 11  cumplieron con los criterios de inclusión. No se obtuvieron estudios  adicionales en la búsqueda manual.</p>\n<table style="width: 90%; height: 129px;" border="2" align="center"><tbody><tr><td width="34%" height="121" valign="top">\n<p><strong>Los pacientes:</strong><br/> 2183  pacientes con mieloma múltiple.<br/> El diagnóstico de mieloma múltiple se efectuó en todos por  biopsia de médula ósea. Incluyeron etapas de la I a la III. Se  excluyeron los estudios que utilizaran otros agentes relacionados al  metabolismo óseo.</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Intervención</strong><br/> n=1113</p>\n<p>Bifosfonatos</p>\n</td>\n<td width="33%" height="121" valign="top">\n<p><strong>Comparación<br/></strong>n=1070</p>\n<p>Placebo o no tratamiento</p>\n</td>\n</tr></tbody></table><p> </p>\n<p align="left"><strong>¿Es          válida la evidencia obtenida de este estudio?</strong></p>\n<table style="width: 85%; height: 130px;" border="2" align="center"><tbody><tr><td height="122" valign="top">\n<p>1-<strong> Pregunta                específica y focalizada</strong> <strong>.</strong> SI<br/> 2-<strong> Búsqueda                amplia y completa</strong>. SI<br/> 3-<strong>Criterios de inclusión y exclusión                claros y pertinentes a la pregunta</strong>. SI<br/> 4-<strong> Evaluación de validez de los estudios                incluidos. </strong>SI<br/> 5- <strong>Dos revisores independientes.</strong> SI<br/> 6- <strong>Evaluación de heterogeneidad.</strong> SI</p>\n</td>\n</tr></tbody></table><p><br/><strong>Resultados: <br/></strong></p>\n<table style="width: 80%;" border="2" align="center"><tbody><tr><td width="241" align="center">\n<div align="center"><strong>Outcome</strong></div>\n</td>\n<td width="248" align="center">\n<div align="center"><strong>RR<br/> (95% IC) </strong></div>\n</td>\n<td width="250" align="center"><strong>NNT<br/> (95% IC) </strong></td>\n</tr><tr><td height="43" align="center"><strong>Fracturas vertebrales</strong></td>\n<td align="center">0,59<br/> (0,45 a 0,78)</td>\n<td align="center">10<br/> (7 a 20)</td>\n</tr><tr><td height="43" align="center"><strong>Fracturas no vertebrales</strong></td>\n<td align="center">1,05<br/> (0,77 a 1,44)</td>\n<td align="center">NS</td>\n</tr><tr><td height="43" align="center"><strong>Dolor</strong></td>\n<td align="center">0,59<br/> (0,46 a 0,76)</td>\n<td align="center">11<br/> (7 a 28)</td>\n</tr><tr><td height="43" align="center"><strong>Mortalidad</strong></td>\n<td align="center">0,99<br/> (0,88 a 1,12)</td>\n<td align="center">NS</td>\n</tr></tbody></table><p> </p>\n<p>RR= Riesgo relativo, IC= Intervalo de confianza<br/><br/><strong>Comentarios y aplicación práctica: <br/></strong><em>• Comentarios acerca de la validez: </em><br/> - La revisión sistemática es de alta calidad metodológica, ya  que responde una pregunta acotada; la búsqueda es amplia, incluye  múltiples bases de datos, múltiples idiomas, realizan búsqueda manual en  abstracts de congresos y contacto con compañías farmacéuticas y  expertos, en términos de reproducibilidad de la selección de los  estudios, al menos 2 revisores realizaron esa función y resolvieron las  discrepancias por consenso, y finalmente se evalúo la calidad  metodológica de los estudios.<br/><br/><em>• Comentarios acerca de los resultados y aplicabilidad: </em><br/> - En relación a los resultados, no se observa significancia  estadística en un outcome como mortalidad, sin embargo, sí se observa  beneficio significativo en la disminución de fracturas vertebrales y en  dolor. Estos outcomes son relevantes, ya que son motivo de consulta,  hospitalización y costos asociados a la patología, los que pueden ser  prevenidos por una intervención fácil, y eventualmente de un costo menor  al relacionado al manejo de las complicaciones antes mencionadas.<br/> - El metaanálisis mostró una mayor tasa de eventos adversos pero  que no alcanzó la significancia estadística, en el grupo intervención  (RR 1,28 con IC 95% de 0,95 a 1,74), por lo tanto, aunque ese punto debe  ser individualizado, no parece ser un argumento para no usarlos, aunque  es cierto que sólo  se habla de síntomas gastrointestinales, muy  variados. <br/> -          Es importante destacar que respecto a la reducción del dolor, no  queda claro el método de evaluación que usaron los respectivos autores  de los diversos ECRs incluidos en este metanálisis, por lo tanto, siendo  el dolor una variable subjetiva por excelencia que se intenta objetivar  arbitrariamente, deben interpretarse los resultados con cautela.<br/> - Los resultados comentados provienen de ECRs que no diferencian  según estadio del mieloma múltiple y respuesta a tratamiento con  bifosfonato. Hubiese sido interesante hacer un análisis de subgrupos  según etapa clínica, ya que parece interesante la idea de que los  efectos que mostró el bifosfonato sean mayores en etapas tempranas  versus las tardías de esta patología. <br/> - Respecto a la aplicabilidad, los estudios incluidos utilizan  múltiples tipos de bifosfonatos, sin embargo, el bifosfonato de mayor  disponibilidad en nuestro país es el alendronato, droga no incluida en  ésta revisión, pero dado el mecanismo de acción común, el clínico podría  extrapolar éstos resultados a nuestra realidad.  <br/> Por el contrario, si somos estrictos con los hallazgos de la  revisión, los bifosfonatos que demostraron claro beneficio fueron  pamidronato y clodronato, por lo tanto deberían ser los únicos  utilizados para lograr los beneficios que hemos comentado en nuestros  pacientes con mieloma múltiple.          Nuevos bifosfonatos, como zolendronato, no fueron evaluados, lo  que debe ser considerado si se piensa utilizar alguno de ellos en  beneficio de nuestros pacientes. En este sentido si aplicamos el mismo  fundamento de acción común esperaremos resultados similares.<br/> - El número necesario a tratar (NNT) con esta droga es  prometedor para nosotros e incluso dado los hallazgos de ésta revisión,  es atractivo el uso de estas drogas en otras patologías que cursan con  complicaciones similares, por ejemplo cáncer de próstata o de mama,  ambas neoplasias que con frecuencias se complican con compromiso óseo,  dolor y fracturas en hueso patológico.</p>\n<p>En resumen, el uso de la terapia con bifosfonatos es  posible de sumar a la terapia estándar, logrando disminuir motivos de  consulta frecuentes como son las fracturas de hueso patológico o el  dolor. Aun cuando el bifosfonato más disponible en Chile no se encuentra  en la revisión nos parece adecuado extrapolar los beneficios  demostrados y por lo tanto indicarlo en pacientes con mieloma múltiple.  En este sentido si el paciente tuviera una preferencia por otro  bifosfonato, como puede ser uno con vía de administración distinta,  podrían evaluar en conjunto el clínico junto con el paciente, los costos  y beneficios, llegando a la  decisión final.</p>', 'Los bifosfonatos en pacientes con mieloma múltiple podrían reducir el dolor y el riesgo de fracturas vertebrales', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 59),
(179, 57, 3, 1, 1, 1, 'ResumenDeEvidenciaEdicion', '2011-03-15 15:27:59', '2011-03-16 22:34:19', 'resumenes-sin-nombre', 'Resúmenes sin nombre', NULL, NULL, 'Resúmenes sin nombre', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 10),
(180, 57, 4, 1, 1, 1, 'ResumenDeEvidencia', '2011-03-15 15:27:59', '2011-03-16 22:34:32', 'resumenes-sin-nombre', 'Resúmenes sin nombre', NULL, NULL, 'Resúmenes sin nombre', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 10),
(181, 15, 2, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 16:11:28', 'herramientas', 'Herramientas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(182, 15, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 16:12:40', 'herramientas', 'Herramientas', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0),
(183, 64, 1, 0, 1, 0, 'Page', '2011-03-17 21:17:22', '2011-03-17 21:17:22', 'nuevapage', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 11),
(184, 65, 1, 0, 1, 0, 'AlertPage', '2011-03-17 21:17:28', '2011-03-17 21:17:28', 'new-alertpage', 'NuevaAlertPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 2, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 11),
(185, 66, 1, 0, 1, 0, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:17:51', 'nuevapage-2', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 64),
(186, 66, 2, 0, 1, 0, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:18:02', 'nuevapage-2', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 11),
(187, 66, 3, 0, 1, 0, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:18:03', 'nuevapage-2', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 11),
(188, 67, 1, 0, 1, 0, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:18:12', 'nuevapage-3', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 66),
(189, 67, 2, 0, 1, 0, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:18:16', 'nuevapage-3', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 66),
(190, 67, 3, 0, 1, 0, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:18:17', 'nuevapage-3', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 11),
(191, 68, 1, 0, 1, 0, 'Page', '2011-03-17 21:18:29', '2011-03-17 21:18:29', 'nuevapage-4', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 11),
(192, 69, 1, 0, 1, 0, 'Page', '2011-03-17 21:18:44', '2011-03-17 21:18:44', 'nuevapage-5', 'NuevaPage', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'New page', NULL, 'Inherit', 'Inherit', NULL, 11),
(193, 64, 2, 1, 1, 1, 'Page', '2011-03-17 21:17:22', '2011-03-17 21:19:03', 'temas', 'Temas', NULL, NULL, 'Temas', NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 11),
(194, 66, 4, 1, 1, 1, 'Page', '2011-03-17 21:17:51', '2011-03-17 21:19:32', 'revisiones-sistematicas', 'Revisiones sistemáticas', NULL, NULL, 'Revisiones sistemáticas', NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 11),
(195, 67, 4, 1, 1, 1, 'Page', '2011-03-17 21:18:12', '2011-03-17 21:19:54', 'estudios-metodicos', 'Estudios metódicos', NULL, NULL, 'Estudios metódicos', NULL, NULL, NULL, 1, 1, NULL, 0, 4, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 11),
(196, 68, 2, 1, 1, 1, 'Page', '2011-03-17 21:18:29', '2011-03-17 21:20:17', 'analisis-critico', 'Análisis crítico', NULL, NULL, 'Análisis crítico', NULL, NULL, NULL, 1, 1, NULL, 0, 5, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 11),
(197, 69, 2, 1, 1, 1, 'Page', '2011-03-17 21:18:44', '2011-03-17 21:20:42', 'opinion', 'Opinión', NULL, NULL, 'Opinión', NULL, NULL, NULL, 1, 1, NULL, 0, 6, 0, 0, 'Saved (new)', NULL, 'Inherit', 'Inherit', NULL, 11),
(198, 11, 2, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 21:22:09', 'publicaciones', 'Publicaciones', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 1, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(199, 11, 3, 1, 1, 1, 'RedirectorPage', '2011-03-04 19:36:54', '2011-03-17 21:22:22', 'publicaciones', 'Publicaciones', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 3, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 8),
(200, 7, 7, 1, 1, 1, 'HomePage', '2011-03-04 19:36:53', '2011-03-22 14:50:53', 'home', '﻿Inicio', NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, NULL, 0, 1, 0, 0, 'Saved (update)', NULL, 'Inherit', 'Inherit', NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SiteTree_ViewerGroups`
--

CREATE TABLE IF NOT EXISTS `SiteTree_ViewerGroups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `SiteTreeID` (`SiteTreeID`),
  KEY `GroupID` (`GroupID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `SiteTree_ViewerGroups`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `StaffMember`
--

CREATE TABLE IF NOT EXISTS `StaffMember` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('StaffMember') CHARACTER SET utf8 DEFAULT 'StaffMember',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Mail` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Phone` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  `HolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ImageID` (`ImageID`),
  KEY `HolderID` (`HolderID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `StaffMember`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Term`
--

CREATE TABLE IF NOT EXISTS `Term` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Term') CHARACTER SET utf8 DEFAULT 'Term',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` mediumtext CHARACTER SET utf8,
  `Definition` mediumtext CHARACTER SET utf8,
  `GlosaryID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `GlosaryID` (`GlosaryID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `Term`
--

INSERT INTO `Term` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Definition`, `GlosaryID`) VALUES
(1, 'Term', '2011-03-10 21:53:05', '2011-03-10 21:53:05', 'Abaniqueo', 'Acción, que contraviene el reglamento, de tensar o destensar una vela.', 18),
(2, 'Term', '2011-03-10 21:54:35', '2011-03-10 21:54:35', 'Abatimiento', 'Ángulo de desvío hacia sotavento del rumbo de la embarcación causado por el viento.', 18),
(3, 'Term', '2011-03-10 21:55:02', '2011-03-10 21:55:02', 'Back', 'Nombre con que se conoce la técnica para cruzar el ancho de un río; la piragua habrá de mantenerse al nivel del agua.', 18),
(4, 'Term', '2011-03-10 21:55:29', '2011-03-10 21:55:29', 'Balanceo', 'Movimiento del regatista; cambio ajustado de las velas o de la embarcación entera de banda a banda, prohibida por el reglamento.', 18),
(5, 'Term', '2011-03-10 21:56:38', '2011-03-10 21:56:38', 'Cabalgar sobre las olas', 'Deslizarse por la cara de la ola.', 18);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TesisFuente`
--

CREATE TABLE IF NOT EXISTS `TesisFuente` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('TesisFuente') CHARACTER SET utf8 DEFAULT 'TesisFuente',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Category` enum('Tesis de pregrado','Tesis de postgrado') CHARACTER SET utf8 DEFAULT 'Tesis de pregrado',
  `Tesistas` mediumtext CHARACTER SET utf8,
  `Nombre` mediumtext CHARACTER SET utf8,
  `Programa` enum('Ingeniería Civil Bioquímica','Ingeniería de Ejecución en Bioprocesos','Magíster en Ciencias de la Ingeniería con mención en Ingeniería Bioquímica','Doctorado en Ciencias de la Ingeniería con mención en Ingeniería Bioquímica') CHARACTER SET utf8 DEFAULT 'Ingeniería Civil Bioquímica',
  `Year` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Visibility` enum('Publico','Oculto') CHARACTER SET utf8 DEFAULT 'Publico',
  `MemberPageID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `MemberPageID` (`MemberPageID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `TesisFuente`
--

INSERT INTO `TesisFuente` (`ID`, `ClassName`, `Created`, `LastEdited`, `Category`, `Tesistas`, `Nombre`, `Programa`, `Year`, `Visibility`, `MemberPageID`) VALUES
(1, 'TesisFuente', '2011-03-14 15:40:27', '2011-03-14 15:40:41', 'Tesis de pregrado', 'Gaddsa', 'Hola soy una tésis', 'Ingeniería Civil Bioquímica', '2010', 'Publico', 53);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `UmbeProyecto`
--

CREATE TABLE IF NOT EXISTS `UmbeProyecto` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('UmbeProyecto') CHARACTER SET utf8 DEFAULT 'UmbeProyecto',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` mediumtext CHARACTER SET utf8,
  `Description` mediumtext CHARACTER SET utf8,
  `Responsable` mediumtext CHARACTER SET utf8,
  `Duracion` mediumtext CHARACTER SET utf8,
  `Financiador` mediumtext CHARACTER SET utf8,
  `HolderID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `HolderID` (`HolderID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `UmbeProyecto`
--

INSERT INTO `UmbeProyecto` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Description`, `Responsable`, `Duracion`, `Financiador`, `HolderID`) VALUES
(1, 'UmbeProyecto', '2011-03-16 20:16:39', '2011-03-16 20:16:39', 'Eficacia, costos y satisfacción usuaria de la hospitalización en domicilio como modelo de alta precoz desde el hospital, en pacientes de riesgo bajo y moderado', 'Este proyecto busca determinar la eficacia y costos de un sistema de hospitalización en domicilio (hed), como sistema de alta precoz desde un hospital público. Se pretende comparar la morbimortalidad y satisfacción usuaria de la hed en pacientes con riesgo moderado; comparar el uso de recursos de la hed con la convencional, en pacientes de riesgo moderado; evaluar la hed en pacientes de riesgo bajo, en términos de satisfacción usuaria y costos; e identificar aspectos claves que orienten la reproducibilidad de la hospitalización en domicilio en otros centros asistenciales.', 'Dr. Gabriel Rada', '18 meses (2008-2010)', 'Fondo Nacional de Investigación en Salud (FONIS). Quinto Concurso Nacional, Chile (2008)', 12),
(2, 'UmbeProyecto', '2011-03-16 20:17:59', '2011-03-16 20:17:59', 'Eficacia, costos y satisfacción usuaria de la hospitalización en domicilio como modelo de alta precoz desde el hospital, en pacientes de riesgo bajo y moderado', 'Este proyecto busca determinar la eficacia y costos de un sistema de hospitalización en domicilio (hed), como sistema de alta precoz desde un hospital público. Se pretende comparar la morbimortalidad y satisfacción usuaria de la hed en pacientes con riesgo moderado; comparar el uso de recursos de la hed con la convencional, en pacientes de riesgo moderado; evaluar la hed en pacientes de riesgo bajo, en términos de satisfacción usuaria y costos; e identificar aspectos claves que orienten la reproducibilidad de la hospitalización en domicilio en otros centros asistenciales', 'Dr. Gabriel Rada', '15 meses (2008-2010)', 'Don Francisco', 12);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `VirtualPage`
--

CREATE TABLE IF NOT EXISTS `VirtualPage` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `VirtualPage`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `VirtualPage_Live`
--

CREATE TABLE IF NOT EXISTS `VirtualPage_Live` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `VirtualPage_Live`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `VirtualPage_versions`
--

CREATE TABLE IF NOT EXISTS `VirtualPage_versions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`),
  KEY `RecordID` (`RecordID`),
  KEY `Version` (`Version`),
  KEY `CopyContentFromID` (`CopyContentFromID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `VirtualPage_versions`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Widget`
--

CREATE TABLE IF NOT EXISTS `Widget` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('Widget') CHARACTER SET utf8 DEFAULT 'Widget',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `ParentID` (`ParentID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `Widget`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `WidgetArea`
--

CREATE TABLE IF NOT EXISTS `WidgetArea` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ClassName` enum('WidgetArea') CHARACTER SET utf8 DEFAULT 'WidgetArea',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `ClassName` (`ClassName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `WidgetArea`
--

